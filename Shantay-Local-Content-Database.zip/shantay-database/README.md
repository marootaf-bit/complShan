# Shantay local content database — SQLite

This is the sanitized LOCAL content snapshot supplied with project-shantui-global, not a new export of the current live hosting database. Export packaged 2026-11-05.

Contents: pages, translations, fragments, settings and component localizations. The schema has been retained. users, requests, password_reset_tokens, sessions, cache, cache_locks, jobs, job_batches and failed_jobs are empty. Public dealership contact details in settings are intentionally retained. The export copy was vacuumed to remove free pages, and SQLite integrity_check returned ok. No hosting database was modified.

File: data/hosted-content.sqlite (actual SQLite database, not MySQL SQL).

Use with the separately supplied Shantay-Source-Local-Assets-No-Database.zip. Extract the source project first. For existing prepare_host_baseline.py, compress this SQLite file with gzip and place it at PROJECT/data/hosted-content.sqlite.gz, then follow the project's local setup guide. Alternatively, copy it to PROJECT/.cache/host-restore.sqlite for the existing read-only baseline router before runtime preparation. Do not overwrite another database without backing it up.

Example creating the compressed snapshot with Python (run from project root, after copying this package's data/hosted-content.sqlite there):

    python3 -c "import gzip,shutil; a=open('data/hosted-content.sqlite','rb'); b=gzip.open('data/hosted-content.sqlite.gz','wb'); shutil.copyfileobj(a,b); b.close(); a.close()"

Install PHP/Node dependencies separately. Fresh local runtime directories and an application key are also needed. There are no hosting login credentials/admin users in this snapshot; do not expect production credentials to work. Never overwrite production or execute destructive migrations/seeders against production.
