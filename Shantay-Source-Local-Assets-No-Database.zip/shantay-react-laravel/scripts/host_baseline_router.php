<?php
// LOCAL ONLY: hosted source unchanged; isolated, read-only preview configuration.
$root=dirname(__DIR__);
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
$readFragments=['/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp'];
if (!in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'],true) && !in_array($path,$readFragments,true)) {
    http_response_code(403); header('Content-Type: application/json'); echo '{"error":"read_only_local_baseline"}'; return;
}
$values=['APP_KEY'=>trim(file_get_contents($root.'/.cache/workspace.key')),'MANAGED_CONTENT_ENABLED'=>'false','APP_BASE_PATH'=>$root.'/backend','APP_ENV'=>'local','APP_DEBUG'=>'false','APP_URL'=>'http://localhost','DB_CONNECTION'=>'sqlite','DB_DATABASE'=>$root.'/.cache/host-restore.sqlite','DB_URL'=>'','CACHE_STORE'=>'array','SESSION_DRIVER'=>'array','MAIL_MAILER'=>'array','INQUIRY_EMAIL_ENABLED'=>'false','SHANTUI_TRANSLATION_PREVIEW'=>'true','SHANTUI_TEST_TRANSLATION_PREVIEW'=>'false','ADMIN_DEMO_ENABLED'=>'false','SHANTUI_MEDIA_ROOT'=>$root.'/.cache/host-media'];
foreach($values as $k=>$v){putenv($k.'='.$v);$_ENV[$k]=$v;$_SERVER[$k]=$v;}
$_SERVER['SCRIPT_NAME']='/index.php';$_SERVER['PHP_SELF']='/index.php';$_SERVER['SCRIPT_FILENAME']=$root.'/backend/public/index.php';unset($_SERVER['PATH_INFO']);
require $root.'/backend/vendor/autoload.php';
$app=require $root.'/backend/bootstrap/app.php';
$app->handleRequest(Illuminate\Http\Request::capture());
