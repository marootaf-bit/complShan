"""Read-only guard: existing public assets and hosted React artifacts must stay unchanged."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
files=json.loads((R/'reports/HOST-BASELINE-FILES.json').read_text())
protected=[f for f in files if f['path'].startswith(('public/','dist/'))]
fail=[]
for f in protected:
    p=R/f['path']
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:
        fail.append(f['path'])
report={'status':'failed' if fail else 'passed','protectedExistingFiles':len(protected),'changedFiles':fail,'scope':'All existing hosted public files and React bundles. New admin-only files are separate. Does not alone prove dynamic rendering parity.'}
(R/'reports/CATALOGUE-PUBLIC-ASSET-GUARD.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report));raise SystemExit(bool(fail))
