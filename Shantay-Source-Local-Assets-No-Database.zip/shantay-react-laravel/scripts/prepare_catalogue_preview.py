"""Prepare isolated LOCAL catalogue preview; never overwrite an existing preview DB."""
from pathlib import Path
import runpy,shutil,secrets,base64
R=Path(__file__).resolve().parents[1]
runpy.run_path(str(R/'scripts/prepare_host_baseline.py'))
db=R/'.cache/catalogue-preview.sqlite'
if not db.exists():shutil.copyfile(R/'.cache/host-restore.sqlite',db)
key=R/'.cache/catalogue-preview-key'
if not key.exists():
    key.write_text('base64:'+base64.b64encode(secrets.token_bytes(32)).decode())
    key.chmod(0o600)
(R/'.cache/CATALOGUE_PREVIEW_ONLY').write_text('Isolated local catalogue testing only.\n')
print('Local catalogue preview ready. Existing preview data preserved; no hosting access.')
