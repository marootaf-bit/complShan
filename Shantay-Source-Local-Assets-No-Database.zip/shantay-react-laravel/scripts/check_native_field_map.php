<?php
require __DIR__.'/../backend/vendor/autoload.php';
use App\Support\NativeFieldMap as Fields;
function verify($ok,$message){if(!$ok)throw new RuntimeException($message);}
$fixture='<html><head><title>Test &amp; title</title></head><body><header>Protected</header><table><tr><td>1</td><td>Engine</td></tr></table><img data-src="/real.jpg" src="/lazy.jpg" alt="Old"><picture><source srcset="/small.jpg 1x"><img src="/fallback.jpg"></picture><p>A &amp; B</p></body></html>';
$f=Fields::fields($fixture);verify(count(array_filter($f,fn($r)=>$r['value']==='1'))===1,'Single-digit specification retained');verify(!in_array('Protected',array_column($f,'value')),'Header excluded');verify(!in_array('/real.jpg',array_column($f,'value')),'data-src not confused with src');foreach($f as $r)if(in_array($r['value'],['/lazy.jpg','/fallback.jpg']))verify(!$r['editable'],'Complex media read-only');
verify(Fields::render($fixture,array_column($f,'value','id'))===$fixture,'Entity-preserving no-op');$field=array_values(array_filter($f,fn($r)=>$r['value']==='A & B'))[0];$expected=str_replace('<p>A &amp; B</p>','<p>&lt;img src=x onerror=alert(1)&gt;</p>',$fixture);verify(Fields::render($fixture,[$field['id']=>'<img src=x onerror=alert(1)>'])===$expected,'Plain text escaped, unrelated bytes untouched');

$attributeFixture="<img data-note=' src=\"/fake.jpg\"' src=\"/real.jpg\" onerror=\"this.alt='handler text'\" alt=\"Safe\">";$attributes=Fields::fields($attributeFixture);verify(array_column($attributes,'value')===['/real.jpg','Safe'],'Quoted unrelated attributes and handlers never become editable fields');
$pdo=new PDO('sqlite:'.__DIR__.'/../.cache/workspace.sqlite');$count=0;foreach($pdo->query('select base_html from managed_pages') as $row){$html=$row['base_html'];$fields=Fields::fields($html);verify(Fields::render($html,array_column($fields,'value','id'))===$html,'Imported document no-op mismatch');$count++;}
file_put_contents(__DIR__.'/../reports/NATIVE-FIELD-QA.json',json_encode(['status'=>'passed','imported_documents_noop_byte_identical'=>$count,'fixture_checks'=>7],JSON_PRETTY_PRINT));echo "$count imported page/fragment no-op checks passed.\n";
