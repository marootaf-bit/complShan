"""Existing-model transfer into an existing native family list; fixture rows restored, no inquiries/email."""
from pathlib import Path
import sqlite3,requests,json,hmac,hashlib,time,re
R=Path(__file__).resolve().parents[1];assert(R/'.cache/WORKSPACE_REPAIR_ONLY').exists();BASE='http://127.0.0.1:5186';c=sqlite3.connect(R/'.cache/workspace.sqlite');c.row_factory=sqlite3.Row
p=dict(c.execute("select * from managed_pages where locale='fa' and path='/product/pro-detail-5286.htm'").fetchone());e=dict(c.execute('select * from catalogue_entries where page_id=?',(p['id'],)).fetchone());root=dict(c.execute("select * from catalogue_groups where locale='fa' and parent_id is null and native_id='253'").fetchone());target=dict(c.execute("select g.* from catalogue_groups g join catalogue_cards c on c.group_id=g.id where g.locale='fa' and g.parent_id=? and c.html like '%link_box%' limit 1",(root['id'],)).fetchone());maxes={t:c.execute('select coalesce(max(id),0) from '+t).fetchone()[0] for t in ['managed_versions','managed_audit']};key=(R/'.cache/workspace.key').read_text();expiry=str(int(time.time())+3600);s=requests.Session();s.headers['X-Local-Workspace-Token']=expiry+'.'+hmac.new(key.encode(),expiry.encode(),hashlib.sha256).hexdigest();checks=[];completed=False
before_en=requests.get(BASE+p['path']+'?lang=en').content
before_source=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':'251','catId':'101'}).text
before_target=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id'],'catId':target['native_id']}).text
assert 'class="item_list"' in before_target
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name)
def call(action,data,method='POST'):
 r=s.request(method,BASE+'/api/admin/workspace/catalogue/items/'+str(e['id'])+action,json={'locale':'fa','kind':'products',**data});assert r.status_code==200,(r.status_code,r.text[:300]);return r.json()
try:
 item=call('',{'revision':p['revision'],'group_ids':[target['id']]},'PUT');item=call('/publish',{'revision':item['revision']});check('published transfer preserves original URL',item['path']==p['path']);source=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':'251','catId':'101'}).text;check('source family removes only transferred variant',p['path'] not in source and '/product/pro-detail-5015.htm' in source)
 destination=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id'],'catId':target['native_id']});check('existing transferred model appears in destination family frame',destination.status_code==200 and p['path'] in destination.text and 'entry_'+str(e['id']) in destination.text and 'class="item_list"' in destination.text)
 detail=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id'],'catId':'entry_'+str(e['id'])});check('destination native family click opens correct model list',detail.status_code==200 and detail.headers.get('X-Result-Count')=='1' and p['path'] in detail.text)
 rootlist=requests.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id']});check('destination root listing includes existing transferred record',rootlist.status_code==200 and p['path'] in rootlist.text)
 html=requests.get(BASE+p['path']+'?lang=fa').text;crumb=html[html.index('class="crumbs"'):html.index('class="crumbs"')+750];rootpath=c.execute('select path from managed_pages where id=?',(root['page_id'],)).fetchone()[0];check('detail breadcrumb follows published destination',rootpath in crumb and '/product/excavator.htm' not in crumb);check('transfer leaves English bytes unchanged',requests.get(BASE+p['path']+'?lang=en').content==before_en)
 count=re.search(r'var\s+count\s*=\s*(\d+)',destination.text);visible=len(re.findall(r'<li\b',destination.text));check('family count reflects actual rendered families',count and int(count[1])==visible)
 nav=s.post(BASE+'/ext/ajax.jsp?lang=fa',data={'flag':'getCat','channelId':root['native_id']});check('native hover contract uses original cnav class',nav.status_code==200 and 'class="cnav_li"' in nav.text and 'class="c_li_box"' in nav.text)
 nav=s.post(BASE+'/ext/ajax.jsp?lang=fa',data={'flag':'getPro','channelId':root['native_id'],'catId':target['native_id']});check('native hover models use original right-menu class',nav.status_code==200 and 'class="rnav_li"' in nav.text)
 completed=True
finally:
 for table,row in [('managed_pages',p),('catalogue_entries',e)]:
  keys=[k for k in row if k!='id'];c.execute('update '+table+' set '+','.join('"'+k+'"=?' for k in keys)+' where id=?',[row[k] for k in keys]+[row['id']])
 for table,n in maxes.items():c.execute('delete from '+table+' where id>?',(n,))
 c.commit();(R/'reports/NATIVE-TRANSFER-QA.json').write_text(json.dumps({'status':'passed' if completed else 'failed','checks':checks,'fixture_restored':True},indent=2))
print(json.dumps({'passed':len(checks),'fixture_restored':True}))
