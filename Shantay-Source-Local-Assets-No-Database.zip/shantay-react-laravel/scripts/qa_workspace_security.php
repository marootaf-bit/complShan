<?php
// Isolated migration probe and HTTP middleware checks. No public or inquiry writes.
require __DIR__.'/../backend/vendor/autoload.php';
$app=require __DIR__.'/../backend/bootstrap/app.php';$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use Illuminate\Support\Facades\{DB,Schema};use Illuminate\Http\Request;
$checks=[];function check($name,$ok){global $checks;if(!$ok)throw new RuntimeException($name);$checks[]=$name;}
config(['database.connections.probe'=>['driver'=>'sqlite','database'=>':memory:','prefix'=>'','foreign_key_constraints'=>true],'database.default'=>'probe']);Schema::create('preserved_probe',fn($t)=>$t->string('value'));DB::table('preserved_probe')->insert(['value'=>'keep']);$migration=require __DIR__.'/../backend/database/migrations/2026_11_04_000006_create_independent_content.php';$migration->up();check('additive tables created',Schema::hasTable('managed_pages')&&Schema::hasTable('managed_versions')&&Schema::hasTable('managed_audit'));$migration->down();check('rollback leaves unrelated data unchanged',DB::table('preserved_probe')->value('value')==='keep'&&!Schema::hasTable('managed_pages'));
config(['app.env'=>'production','app.url'=>'http://workspace.test','app.key'=>trim(file_get_contents(__DIR__.'/../.cache/workspace.key')),'shantui.managed_content_enabled'=>true]);$app->instance('env','production');$key=config('app.key');$expiry=(string)(time()+3600);$token=$expiry.'.'.hash_hmac('sha256',$expiry,$key);$kernel=$app->make(Illuminate\Contracts\Http\Kernel::class);
$call=function($method,$path,$cookies=[],$headers=[])use($kernel){$server=array_merge(['HTTP_HOST'=>'workspace.test','HTTP_ACCEPT'=>'application/json','CONTENT_TYPE'=>'application/json'],$headers);$r=Request::create($path,$method,[],$cookies,[],$server,'{}');return $kernel->handle($r);};
check('production middleware denies anonymous private preview',$call('GET','/api/admin/workspace/pages/1/preview?locale=fa')->getStatusCode()===401);
check('forged token denied',$call('GET','/api/admin/workspace/pages?locale=fa',['shantui_admin'=>'9999999999.forged'])->getStatusCode()===401);
check('production cross-origin mutation denied',$call('PUT','/api/admin/workspace/pages/1',['shantui_admin'=>$token],['HTTP_ORIGIN'=>'https://evil.example'])->getStatusCode()===403);
check('production cross-site mutation denied',$call('PUT','/api/admin/workspace/pages/1',['shantui_admin'=>$token],['HTTP_SEC_FETCH_SITE'=>'cross-site'])->getStatusCode()===403);
check('legacy shared editor write blocked in application',$call('PUT','/api/admin/setting',['shantui_admin'=>$token])->getStatusCode()===409);
file_put_contents(__DIR__.'/../reports/WORKSPACE-SECURITY-QA.json',json_encode(['status'=>'passed','checks'=>$checks,'limitations'=>'Legacy HMAC session has no user identity or per-user roles; not complete security acceptance.'],JSON_PRETTY_PRINT));echo count($checks)." isolated checks passed.\n";
