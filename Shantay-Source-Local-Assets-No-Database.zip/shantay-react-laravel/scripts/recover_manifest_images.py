"""One-time read-only recovery of missing, hash-verified images. No video/PDF export or runtime proxy."""
from pathlib import Path
import requests,json,hashlib,concurrent.futures,time
R=Path(__file__).resolve().parents[1];manifest=json.loads((R/'data/self-hosted-media.json').read_text());out=[]
def recover(item):
 path,entry=item
 if not entry.get('mime','').startswith('image/'):return None
 dest=R/'public'/path.lstrip('/')
 if '..' in Path(path).parts:return {'path':path,'status':'unsafe_path'}
 if dest.is_file():return {'path':path,'status':'existing_preserved'}
 try:
  r=requests.get('https://test.grandtire.af'+path,timeout=(8,25))
  if r.status_code!=200 or hashlib.sha256(r.content).hexdigest()!=entry['sha256']:return {'path':path,'status':'unverified','http':r.status_code}
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(r.content);return {'path':path,'status':'recovered','bytes':len(r.content)}
 except requests.RequestException:return {'path':path,'status':'network_failure'}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(recover,manifest.items()):
  if result:out.append(result)
  if len(out)%100==0:print('Processed images:',len(out),flush=True)
report={'scope':'Missing manifest images only; verified SHA-256; existing files preserved; no video/PDF export, host writes or runtime proxy.','results':out,'recovered':sum(x['status']=='recovered' for x in out),'recovered_bytes':sum(x.get('bytes',0) for x in out),'unresolved':[x for x in out if x['status'] not in ['recovered','existing_preserved']]};(R/'reports/IMAGE-RECOVERY-VERIFIED.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['results','unresolved']}),flush=True)
