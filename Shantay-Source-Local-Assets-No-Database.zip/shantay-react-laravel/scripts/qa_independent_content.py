"""Reversible tests against sentinel-guarded workspace only; no customer inquiries or email."""
from pathlib import Path
import sqlite3,requests,json,hashlib,hmac,time,subprocess,os
R=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:5186';checks=[]
assert (R/'.cache/WORKSPACE_REPAIR_ONLY').exists()
k=(R/'.cache/workspace.key').read_text();expiry=str(int(time.time())+3600);token=expiry+'.'+hmac.new(k.encode(),expiry.encode(),hashlib.sha256).hexdigest();s=requests.Session();s.headers['X-Local-Workspace-Token']=token
c=sqlite3.connect(R/'.cache/workspace.sqlite');c.row_factory=sqlite3.Row
original={};completed=False
tables=['pages','component_localizations','fragments','settings','users','requests','translations']
def digest(t):
 h=hashlib.sha256()
 for row in c.execute('select * from '+t+' order by 1,2'):h.update(json.dumps(tuple(row),ensure_ascii=False).encode())
 return h.hexdigest()
immutable={t:digest(t) for t in tables}
initial_audit=c.execute('select coalesce(max(id),0) from managed_audit').fetchone()[0];initial_versions=c.execute('select coalesce(max(id),0) from managed_versions').fetchone()[0]
def check(name,value):
 if not value:raise AssertionError(name)
 checks.append(name)
def get(id,locale='fa'):return s.get(BASE+f'/api/admin/workspace/pages/{id}?locale={locale}').json()
def put(p,changes,code=200):
 r=s.put(BASE+f'/api/admin/workspace/pages/{p["id"]}',json={'locale':p['locale'],'revision':p['revision'],'changes':changes});check('save HTTP '+str(code),r.status_code==code);return r.json()
def action(p,name,code=200):
 r=s.post(BASE+f'/api/admin/workspace/pages/{p["id"]}/'+name,json={'locale':p['locale'],'revision':p['revision']});check(name+' HTTP '+str(code),r.status_code==code);return r.json()
try:
 path='/product/pro-detail-5286.htm';ids={r['locale']:r['id'] for r in c.execute('select id,locale from managed_pages where path=?',(path,))}
 for id in ids.values():original[id]=dict(c.execute('select * from managed_pages where id=?',(id,)).fetchone())
 url=lambda lang:BASE+path+'?lang='+lang
 before={lang:requests.get(url(lang)).content for lang in ids}
 check('anonymous list denied',requests.get(BASE+'/api/admin/workspace/pages?locale=fa').status_code==401)
 check('anonymous draft preview denied',requests.get(BASE+f'/api/admin/workspace/pages/{ids["fa"]}/preview?locale=fa').status_code==401)
 check('anonymous mutation denied',requests.put(BASE+f'/api/admin/workspace/pages/{ids["fa"]}',json={}).status_code==401)
 check('locale required',s.get(BASE+'/api/admin/workspace/pages').status_code==422)
 check('wrong-locale ID hidden',s.get(BASE+f'/api/admin/workspace/pages/{ids["fa"]}?locale=en').status_code==404)
 p=get(ids['fa']);f=next(f for f in p['fields'] if f['type']=='text' and f['group']!='SEO' and f['editable'] and f['limit']>=5)
 marker='آزمون';p0=p.copy();p=put(p,[{'id':f['id'],'value':marker}]);check('draft persisted',marker in json.loads(c.execute('select draft_values from managed_pages where id=?',(p['id'],)).fetchone()[0]).values())
 check('draft not public',requests.get(url('fa')).content==before['fa'])
 preview=s.get(BASE+f'/api/admin/workspace/pages/{p["id"]}/preview?locale=fa');check('private preview contains saved change',preview.status_code==200 and marker in preview.text and 'no-store' in preview.headers['Cache-Control'])
 put(p0,[{'id':f['id'],'value':'STALE'}],409)
 check('stale save did not overwrite draft',next(x for x in get(p['id'])['fields'] if x['id']==f['id'])['value']==marker)
 put(p,[{'id':f['id'],'value':'x'*(f['limit']+1)}],422)
 image=next(x for x in p['fields'] if x['type']=='image' and x['editable'])
 put(p,[{'id':image['id'],'value':'/uploads/not-installed.png'}],422)
 put(p,[{'id':'unknown','value':'text'}],422)
 p=action(p,'publish');check('published Dari contains change',marker in requests.get(url('fa')).text)
 check('English HTML byte-identical after Dari publish',requests.get(url('en')).content==before['en'])
 version=p['versions'][0]['id'];p=action(p,'restore/'+str(version));check('restore is draft-only',marker in requests.get(url('fa')).text)
 p=action(p,'publish');check('restore and publish returns exact original bytes',requests.get(url('fa')).content==before['fa'])
 p=action(p,'unpublish');check('Dari unpublish returns 404',requests.get(url('fa')).status_code==404)
 check('English remains available',requests.get(url('en')).status_code==200 and requests.get(url('en')).content==before['en'])
 check('no fallback on missing Dari page',requests.get(url('fa')).status_code==404)
 p=action(p,'publish')
 # Reverse direction: independent English publication must not stale or rewrite Dari.
 en=get(ids['en'],'en');ef=next(x for x in en['fields'] if x['type']=='text' and x['group']!='SEO' and x['editable'] and x['limit']>=5)
 en=put(en,[{'id':ef['id'],'value':'QA-EN'}]);en=action(en,'publish')
 check('Dari unchanged after English source edit',requests.get(url('fa')).content==before['fa'])
 check('English update rendered',b'QA-EN' in requests.get(url('en')).content)
 link=next(x for x in p['fields'] if x['type']=='link')
 put(p,[{'id':link['id'],'value':'/api/site/render?path='+path+'&lang=en'}],422)
 long=next(x for x in p['fields'] if x['type']=='text' and x['editable'] and x['limit']>=40)
 payload='<img src=x onerror=QA_XSS>'
 p=put(p,[{'id':long['id'],'value':payload}]);html=s.get(BASE+f'/api/admin/workspace/pages/{p["id"]}/preview?locale=fa').text
 check('plain text cannot inject markup',payload not in html and '&lt;img src=x onerror=QA_XSS&gt;' in html)
 p=put(p,[{'id':long['id'],'value':long['value']}])
 env={**os.environ,'DB_CONNECTION':'sqlite','DB_DATABASE':str(R/'.cache/workspace.sqlite'),'DB_URL':'','APP_ENV':'local','MANAGED_CONTENT_ENABLED':'false','SHANTUI_TRANSLATION_PREVIEW':'true'}
 subprocess.run(['php','backend/artisan','content:import-current'],cwd=R,env=env,check=True,stdout=subprocess.DEVNULL)
 check('repeat import preserves published owner edits',b'QA-EN' in requests.get(url('en')).content)

 result=s.get(BASE+'/api/site/content-search',params={'lang':'en','keywords':'QA-EN'});check('search finds published same-language content',result.status_code==200 and any(x['path']==path for x in result.json()['data']))
 result=s.get(BASE+'/api/site/content-search',params={'lang':'fa','keywords':'QA-EN'});check('search does not merge English into Dari',result.status_code==200 and result.json()['total']==0)
 result=s.get(BASE+'/api/site/content-search',params={'lang':'fa','keywords':'شانتای','per_page':3,'page':2});check('search has real counts and pagination',result.status_code==200 and len(result.json()['data'])<=3 and result.json()['current_page']==2)
 check('legacy shared write endpoint disabled',s.put(BASE+'/api/admin/setting',json={'key':'QA','value':'bad'}).status_code==403) # launcher blocks legacy writes before app
 check('media inventory only installed files',len(s.get(BASE+'/api/admin/workspace/media').json())>0)
 check('no inquiry created',c.execute('select count(*) from requests').fetchone()[0]==0)
 completed=True
finally:
 c.execute('delete from managed_audit where id>?',(initial_audit,));c.execute('delete from managed_versions where id>?',(initial_versions,))
 for id,row in original.items():
  keys=[key for key in row if key!='id'];c.execute('update managed_pages set '+','.join('"'+x+'"=?' for x in keys)+' where id=?',[row[x] for x in keys]+[id])
 c.commit()
 for table,value in immutable.items():check('immutable source table '+table,digest(table)==value)
 report={'status':'passed' if completed else 'failed','passed':len(checks),'checks':checks,'fixture_restored':True,'scope':'Partial independent-page adapter only; not full catalogue/forms/security acceptance'}
 (R/'reports/INDEPENDENT-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'passed':len(checks),'fixture_restored':True}))
