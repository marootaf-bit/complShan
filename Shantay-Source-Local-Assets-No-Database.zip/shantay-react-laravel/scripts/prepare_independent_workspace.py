"""Absent-only preparation of the isolated workspace. Requires PHP/Composer dependencies already installed."""
from pathlib import Path
import sqlite3,secrets,base64,subprocess,os,json
R=Path(__file__).resolve().parents[1]
subprocess.run(['python3',str(R/'scripts/prepare_host_baseline.py')],cwd=R,check=True)
cache=R/'.cache';cache.mkdir(exist_ok=True)
source=cache/'host-restore.sqlite';baseline=cache/'repair-baseline/content.sqlite';working=cache/'workspace.sqlite'
for destination in [baseline,working]:
 if not destination.exists():
  destination.parent.mkdir(parents=True,exist_ok=True)
  with sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True) as src,sqlite3.connect(destination) as dst:src.backup(dst)
key=cache/'workspace.key'
if not key.exists():key.write_text('base64:'+base64.b64encode(secrets.token_bytes(32)).decode());key.chmod(0o600)
(cache/'WORKSPACE_REPAIR_ONLY').touch()
if not (R/'backend/vendor/autoload.php').exists():raise SystemExit('Install the locked Composer dependencies into backend/vendor (or the established cache symlink), then rerun. Existing databases have not been replaced.')
env={**os.environ,'APP_ENV':'local','APP_DEBUG':'false','APP_KEY':key.read_text(),'DB_CONNECTION':'sqlite','DB_DATABASE':str(working),'DB_URL':'','CACHE_STORE':'array','SESSION_DRIVER':'array','MAIL_MAILER':'array','INQUIRY_EMAIL_ENABLED':'false','SHANTUI_TRANSLATION_PREVIEW':'true','MANAGED_CONTENT_ENABLED':'false'}
for args in [['migrate','--force','--no-interaction'],['content:import-current'],['content:import-catalogue']]:subprocess.run(['php',str(R/'backend/artisan'),*args],cwd=R,env=env,check=True)
print('Isolated workspace ready. Existing records were preserved. No deployment was performed.')
