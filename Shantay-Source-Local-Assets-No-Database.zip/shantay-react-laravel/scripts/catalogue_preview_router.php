<?php
// LOCAL ONLY: isolated catalogue preview. Never deploy this router.
$root=dirname(__DIR__);
if(!is_file($root.'/.cache/CATALOGUE_PREVIEW_ONLY')){http_response_code(503);exit('Prepare isolated catalogue preview first.');}
$key=trim(file_get_contents($root.'/.cache/catalogue-preview-key'));
if(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/'){
 $expires=(string)(time()+4*3600);$token=$expires.'.'.hash_hmac('sha256',$expires,$key);setcookie('shantui_admin',$token,['path'=>'/','httponly'=>true,'samesite'=>'Lax']);header('Location: /admin/catalogue');exit;
}
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
// Preview iframes may block third-party cookies; accept a short-lived LOCAL token.
// This is deliberately outside production middleware and requires the local sentinel.
$previewToken=$_SERVER['HTTP_X_LOCAL_CATALOGUE_TOKEN']??'';
$parts=explode('.',$previewToken,2);
if(str_starts_with($path,'/api/admin/')&&count($parts)===2&&ctype_digit($parts[0])&&strlen($parts[0])<=12&&(int)$parts[0]>=time()&&hash_equals(hash_hmac('sha256',$parts[0],$key),$parts[1])){
 $_COOKIE['shantui_admin']=$previewToken;
}
if($path==='/admin/catalogue'&&in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'],true)){
 $expires=(string)(time()+4*3600);$token=$expires.'.'.hash_hmac('sha256',$expires,$key);
 $bootstrap='<script>(()=>{const token='.json_encode($token).';const original=window.fetch.bind(window);window.fetch=(input,options={})=>{const u=new URL(typeof input==="string"?input:input.url,location.href);if(u.origin===location.origin&&u.pathname.startsWith("/api/admin/")){const headers=new Headers(options.headers||(input instanceof Request?input.headers:{}));headers.set("X-Local-Catalogue-Token",token);options={...options,headers};}return original(input,options);};})();</script>';
 header('Content-Type: text/html; charset=UTF-8');header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');header('X-Catalogue-Preview: isolated-local-only');
 if($_SERVER['REQUEST_METHOD']!=='HEAD')echo str_replace('</head>',$bootstrap.'</head>',file_get_contents($root.'/public/admin/catalogue-editor.html'));
 exit;
}
$readFragments=['/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp'];
if (!in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'],true) && !in_array($path,$readFragments,true) && !($path==='/api/admin/upload'&&$_SERVER['REQUEST_METHOD']==='POST') && !(str_starts_with($path,'/api/admin/catalogue-editor/')&&in_array($_SERVER['REQUEST_METHOD'],['POST','PATCH'],true))) {
    http_response_code(403); header('Content-Type: application/json'); echo '{"error":"read_only_local_baseline"}'; return;
}
$values=['APP_BASE_PATH'=>$root.'/backend','APP_ENV'=>'local','APP_DEBUG'=>'false','APP_KEY'=>$key,'ADMIN_EMAIL'=>'local-preview@example.invalid','APP_URL'=>'http://localhost','DB_CONNECTION'=>'sqlite','DB_DATABASE'=>$root.'/.cache/catalogue-preview.sqlite','DB_URL'=>'','CACHE_STORE'=>'array','SESSION_DRIVER'=>'array','MAIL_MAILER'=>'array','INQUIRY_EMAIL_ENABLED'=>'false','SHANTUI_TRANSLATION_PREVIEW'=>'true','SHANTUI_TEST_TRANSLATION_PREVIEW'=>'false','ADMIN_DEMO_ENABLED'=>'false','SHANTUI_MEDIA_ROOT'=>$root.'/.cache/host-media'];
foreach($values as $k=>$v){putenv($k.'='.$v);$_ENV[$k]=$v;$_SERVER[$k]=$v;}
$_SERVER['SCRIPT_NAME']='/index.php';$_SERVER['PHP_SELF']='/index.php';$_SERVER['SCRIPT_FILENAME']=$root.'/backend/public/index.php';unset($_SERVER['PATH_INFO']);
require $root.'/backend/vendor/autoload.php';
$app=require $root.'/backend/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
config(['shantui.upload_root'=>$root.'/.cache/catalogue-media']);
if(str_starts_with($path,'/uploads/')){
 $mediaRoot=realpath($root.'/.cache/catalogue-media/uploads');$file=realpath($root.'/.cache/catalogue-media'.$path);
 if($mediaRoot&&$file&&str_starts_with($file,$mediaRoot.DIRECTORY_SEPARATOR)&&is_file($file)){
  header('Content-Type: '.mime_content_type($file));header('X-Content-Type-Options: nosniff');readfile($file);exit;
 }
}
header('X-Catalogue-Preview: isolated-local-only');
$app->handleRequest(Illuminate\Http\Request::capture());
