"""Reversible tests of the isolated native catalogue. No host, accounts or customer requests."""
from pathlib import Path
import requests,sqlite3,json,hmac,hashlib,time
R=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:5186';assert (R/'.cache/WORKSPACE_REPAIR_ONLY').exists();c=sqlite3.connect(R/'.cache/workspace.sqlite');c.row_factory=sqlite3.Row
k=(R/'.cache/workspace.key').read_text();exp=str(int(time.time())+3600);s=requests.Session();s.headers['X-Local-Workspace-Token']=exp+'.'+hmac.new(k.encode(),exp.encode(),hashlib.sha256).hexdigest();checks=[];completed=False
maxes={t:c.execute('select coalesce(max(id),0) from '+t).fetchone()[0] for t in ['managed_pages','managed_versions','managed_audit','catalogue_entries','catalogue_groups','catalogue_cards','catalogue_memberships']}
originals={t:[dict(r) for r in c.execute('select * from '+t)] for t in ['catalogue_entries','catalogue_groups']};page=c.execute("select * from managed_pages where path='/product/pro-detail-5286.htm' and locale='fa'").fetchone();original_page=dict(page);initial_fa=requests.get(BASE+'/product/pro-detail-5286.htm?lang=fa').content;initial_en=requests.get(BASE+'/product/pro-detail-5286.htm?lang=en').content
scope={'locale':'fa','kind':'products'}
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name)
def call(method,path,data=None,code=200,locale='fa',kind='products'):
 r=s.request(method,BASE+'/api/admin/workspace/catalogue'+path,params={'locale':locale,'kind':kind} if method=='GET' else None,json=({'locale':locale,'kind':kind,**data} if data is not None else None));
 if r.status_code!=code:print('UNEXPECTED',r.status_code,r.text[:700])
 check(method+' '+path+' '+str(code),r.status_code==code)
 return r.json()
def get(id,**kw):return call('GET','/items/'+str(id),**kw)
try:
 entry_id=c.execute('select id from catalogue_entries where page_id=?',(page['id'],)).fetchone()[0];item=get(entry_id);groups=call('GET','/groups');root=next(g for g in groups if g['id'] in item['group_ids'] and not g['parent_id']);template=next(g for g in groups if g['parent_id']==root['id']);media=s.get(BASE+'/api/admin/workspace/media').json();image=next(m['path'] for m in media if m['type']=='image' and m['path'].lower().endswith(('.jpg','.png','.webp')))
 check('anonymous catalogue denied',requests.get(BASE+'/api/admin/workspace/catalogue/items',params=scope).status_code==401)
 call('GET','/items/'+str(entry_id),locale='en',code=404)
 counterpart=c.execute('select e.id from catalogue_entries e join managed_pages p on p.id=e.page_id where p.locale="en" and p.path=?',(page['path'],)).fetchone()[0]
 call('PUT','/items/'+str(entry_id),{'revision':item['revision'],'group_ids':[next(g['id'] for g in call('GET','/groups',locale='en') if not g['parent_id'])]},code=404)
 # Optimistic structured field save, not HTML editing.
 original_name=item['content']['name'];item=call('PUT','/items/'+str(entry_id),{'revision':item['revision'],'group_ids':item['group_ids'],'name':'QA-210'})
 check('structured draft does not leak',requests.get(BASE+page['path']+'?lang=fa').content==initial_fa)
 call('PUT','/items/'+str(entry_id),{'revision':1,'group_ids':item['group_ids'],'name':'STALE'},code=409)
 item=call('POST','/items/'+str(entry_id)+'/publish',{'revision':item['revision']})
 check('structured name bound into public detail','QA-210' in requests.get(BASE+page['path']+'?lang=fa').text)
 check('structured name bound into native category cards','QA-210' in requests.get(BASE+'/product/excavator.htm?lang=fa').text)
 check('English unchanged by Dari structured publication',requests.get(BASE+'/product/pro-detail-5286.htm?lang=en').content==initial_en)
 item=call('PUT','/items/'+str(entry_id),{'revision':item['revision'],'group_ids':item['group_ids'],'name':original_name});item=call('POST','/items/'+str(entry_id)+'/publish',{'revision':item['revision']})
 check('published restore returns original bytes',requests.get(BASE+page['path']+'?lang=fa').content==initial_fa)
 # Independently create an actual child-category draft from an existing native template.
 group=call('POST','/groups',{'name':'آزمون','position':99,'published':True,'parent_id':root['id'],'template_group_id':template['id'],'image':image},code=200)
 check('new category begins unpublished',not group['published'])
 group=call('POST','/groups/'+str(group['id'])+'/publish',{'revision':group['revision']})
 check('published category appears in original native control','data-id="'+group['native_id']+'"' in requests.get(BASE+'/product/excavator.htm?lang=fa').text)
 nav=s.post(BASE+'/ext/ajax.jsp?lang=fa',data={'flag':'getCat','channelId':root['native_id']});check('native navbar uses canonical Dari categories',nav.status_code==200 and 'آزمون' in nav.text)
 # Duplicate explicitly into a new draft; donor content is never automatically approved.
 data={'template_id':entry_id,'name':'QA-NEW','image':image,'group_ids':[group['id']],'specs':[{'key':x['key'],'value':x['value']} for x in item['content']['specs']]}
 clone=call('POST','/items',data,code=201)
 check('new draft has an independent URL and no paired English row',clone['path']!=page['path'] and not c.execute('select id from managed_pages where locale="en" and path=?',(clone['path'],)).fetchone())
 check('new draft private',requests.get(BASE+clone['path']+'?lang=fa').status_code==404)
 call('POST','/items/'+str(clone['id'])+'/publish',{'revision':clone['revision']},code=422)
 clone=call('PUT','/items/'+str(clone['id']),{'revision':clone['revision'],'group_ids':[group['id']],'reviewed_template':True})
 clone=call('POST','/items/'+str(clone['id'])+'/publish',{'revision':clone['revision']})
 check('new published record reaches native detail','QA-NEW' in requests.get(BASE+clone['path']+'?lang=fa').text)
 check('new published record reaches native category list','QA-NEW' in requests.get(BASE+'/product/excavator.htm?lang=fa').text)
 result=requests.get(BASE+'/api/site/catalogue',params={**scope,'group_id':group['id'],'q':'QA-NEW'}).json();check('combined category/search/count',result['total']==1 and result['data'][0]['id']==clone['id'])
 spec=next(x for x in clone['content']['specs'] if x['value'].isdigit());params={**scope,'group_id':group['id'],'specs[0][label]':spec['label'],'specs[0][min]':int(spec['value'])+1};result=requests.get(BASE+'/api/site/catalogue',params=params).json();check('numeric specification filter really excludes records',result['total']==0)
 ajax=s.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id'],'catId':group['native_id'],'q':'QA-NEW'});check('native AJAX queries real new records',ajax.status_code==200 and 'QA-NEW' in ajax.text and ajax.headers.get('X-Result-Count')=='1')
 ajax=s.post(BASE+'/ext/ajax_proList.jsp?lang=fa',data={'flag':'getData','channelId':root['native_id'],'catId':group['native_id'],'attr01':spec['label'],'xz01':'999999~1000000'});check('native combined facet is not silently ignored',ajax.status_code==200 and 'QA-NEW' not in ajax.text and ajax.headers.get('X-Result-Count')=='0')
 call('POST','/groups/'+str(group['id'])+'/archive',{'revision':group['revision']},code=422)
 group=call('POST','/groups/'+str(group['id'])+'/archive',{'revision':group['revision'],'target_group_id':root['id']})
 clone=get(clone['id']);check('safe transfer preserves item and removes archived membership',root['id'] in clone['published_group_ids'] and group['id'] not in clone['published_group_ids'])
 check('archived category hidden from original native controls','data-id="'+group['native_id']+'"' not in requests.get(BASE+'/product/excavator.htm?lang=fa').text)
 clone=call('POST','/items/'+str(clone['id'])+'/archive',{'revision':clone['revision']});check('archived item not public',requests.get(BASE+clone['path']+'?lang=fa').status_code==404)
 clone=call('POST','/items/'+str(clone['id'])+'/restore',{'revision':clone['revision']});check('restore does not auto-publish',clone['status']=='draft' and requests.get(BASE+clone['path']+'?lang=fa').status_code==404)
 check('no customer inquiry created',c.execute('select count(*) from requests').fetchone()[0]==0)
 completed=True
except AssertionError as e:
 # A foreign category must be rejected; lookup hides wrong-language IDs as 404.
 raise
finally:
 # No destructive source resets: remove only new QA fixture IDs, restore only backed-up managed/catalogue rows.
 c.execute('delete from managed_audit where id>?',(maxes['managed_audit'],));c.execute('delete from managed_versions where id>?',(maxes['managed_versions'],));c.execute('delete from catalogue_cards where id>?',(maxes['catalogue_cards'],));c.execute('delete from catalogue_memberships where id>?',(maxes['catalogue_memberships'],));c.execute('delete from catalogue_entries where id>?',(maxes['catalogue_entries'],));c.execute('delete from catalogue_groups where id>?',(maxes['catalogue_groups'],));c.execute('delete from managed_pages where id>?',(maxes['managed_pages'],))
 for t,rows in originals.items():
  for row in rows:
   keys=[x for x in row if x!='id'];c.execute('update '+t+' set '+','.join('"'+x+'"=?' for x in keys)+' where id=?',[row[x] for x in keys]+[row['id']])
 keys=[x for x in original_page if x!='id'];c.execute('update managed_pages set '+','.join('"'+x+'"=?' for x in keys)+' where id=?',[original_page[x] for x in keys]+[original_page['id']]);c.commit();(R/'reports/LOCALE-CATALOGUE-QA.json').write_text(json.dumps({'status':'passed' if completed else 'failed','checks':checks,'fixtures_restored':True},indent=2))

print(json.dumps({"passed":len(checks),"fixtures_restored":True}))
