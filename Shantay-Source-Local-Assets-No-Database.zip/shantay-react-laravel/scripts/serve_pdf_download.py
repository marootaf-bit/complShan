"""Local download page exposing only the requested PDF, no project/source directory access."""
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import shutil
PDF=Path(__file__).resolve().parents[1]/'deliverables/site-review.pdf'
HTML='''<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>دانلود PDF سایت</title><body style="margin:0;background:#f3f5f7;font:18px/2 Tahoma,Arial;color:#203243"><main style="max-width:650px;margin:60px auto;padding:32px;background:white;border-radius:18px;text-align:center"><h1>PDF سایت آمادهٔ دانلود است</h1><p>۲۲ صفحه، شامل ۲۱ نمونهٔ کامل از صفحات سایت زنده در حالت دسکتاپ؛ بدون صفحهٔ داشبورد.</p><p><strong>نام فایل: <span dir="ltr">site-review.pdf</span></strong><br>حجم: حدود ۸٫۶ مگابایت</p><a download="site-review.pdf" href="/site-review.pdf" style="display:block;padding:18px;background:#f4c51d;color:#172636;font-weight:bold;text-decoration:none;border-radius:10px">⬇ دانلود فایل PDF</a><p><a href="/view.pdf" target="_blank" rel="noopener">بازکردن PDF در برگهٔ جداگانه</a></p><p style="font-size:14px;color:#667">پس از دانلود می‌توانید شمارهٔ صفحه و بخش‌های موردنظر را مشخص کنید.</p></main></body></html>'''.encode()
class Handler(BaseHTTPRequestHandler):
 def do_HEAD(self):self.send_content(False)
 def do_GET(self):self.send_content(True)
 def send_content(self,body):
  path=urlsplit(self.path).path
  if path=='/':
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(HTML)));self.end_headers()
   if body:self.wfile.write(HTML)
  elif path in ['/site-review.pdf','/view.pdf']:
   self.send_response(200);self.send_header('Content-Type','application/pdf');self.send_header('Content-Disposition',('attachment' if path=='/site-review.pdf' else 'inline')+'; filename="site-review.pdf"');self.send_header('Content-Length',str(PDF.stat().st_size));self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
   if body:
    with PDF.open('rb') as f:shutil.copyfileobj(f,self.wfile)
  else:self.send_error(404)
HTTPServer(('0.0.0.0',5184),Handler).serve_forever()
