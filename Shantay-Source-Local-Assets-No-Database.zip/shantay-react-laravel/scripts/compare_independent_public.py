"""Local public no-op comparisons; existing missing-language fallback differences are reported, not hidden."""
from pathlib import Path
import requests,json,hashlib,io
from PIL import Image,ImageChops
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];out=R/'reports/repair-visual';out.mkdir(exist_ok=True);results=[]
paths={'home':'/global/home.html','category':'/product/excavator.htm','product':'/product/pro-detail-5286.htm','parts':'/product/parts.htm','contact':'/about/contact-us.htm'}
with sync_playwright() as p:
 browser=p.chromium.launch(args=['--no-sandbox'])
 for name,path in paths.items():
  for lang in ['fa','en']:
   for width in [1440,393]:
    item={'page':name,'path':path,'locale':lang,'width':width};shots=[];responses=[];events=[]
    for label,port in [('before',5185),('after',5186)]:
     url=f'http://127.0.0.1:{port}{path}?lang={lang}';response=requests.get(url);responses.append(response.content);context=browser.new_context(viewport={'width':width,'height':1000},reduced_motion='reduce');page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.route('**/*',lambda route:route.continue_() if route.request.url.startswith(('http://127.0.0.1:','data:','blob:')) else route.abort());page.goto(url,wait_until='networkidle');page.evaluate('document.fonts.ready');page.wait_for_timeout(350)
     height=page.evaluate('document.documentElement.scrollHeight')
     for y in range(0,min(height,20000),800):page.evaluate('(y)=>window.scrollTo(0,y)',y);page.wait_for_timeout(45)
     page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(150);file=out/f'{name}-{lang}-{width}-{label}.png';page.screenshot(path=str(file),full_page=True,animations='disabled');shots.append(Image.open(file).convert('RGB'));events.append(errors);context.close()
    item['html_byte_identical']=responses[0]==responses[1];item['before_dimensions']=shots[0].size;item['after_dimensions']=shots[1].size;item['javascript_errors_before']=events[0];item['javascript_errors_after']=events[1]
    if shots[0].size==shots[1].size:
     diff=ImageChops.difference(*shots);item['pixel_identical']=not diff.getbbox();item['changed_pixels']=sum(1 for v in diff.getdata() if v!=(0,0,0))
    else:item['pixel_identical']=False;item['changed_pixels']=None
    results.append(item);print(name,lang,width,'HTML',item['html_byte_identical'],'pixels',item['pixel_identical'],flush=True)
 browser.close()
report={'scope':'Five sampled templates; animation/lazy-loading timing can affect pixel comparisons. Not an all-page or interaction acceptance test. Missing Dari AJAX content must not be replaced with English.','cases':results,'html_identical':sum(x['html_byte_identical'] for x in results),'pixel_identical':sum(x['pixel_identical'] for x in results)};(R/'reports/INDEPENDENT-VISUAL-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
