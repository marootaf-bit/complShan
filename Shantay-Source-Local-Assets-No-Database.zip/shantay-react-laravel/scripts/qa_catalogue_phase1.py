"""HTTP + real dashboard QA; writes ONLY sentinel-guarded isolated preview, restores registry."""
from pathlib import Path
import sqlite3,requests,json,hashlib,base64
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:5183';KEY='admin.catalogue.v1';checks=[]
assert (R/'.cache/CATALOGUE_PREVIEW_ONLY').exists()
s=requests.Session();r=s.get(BASE+'/');assert r.headers.get('X-Catalogue-Preview')=='isolated-local-only'
db=sqlite3.connect(R/'.cache/catalogue-preview.sqlite');old=db.execute('select value,updated_at from settings where key=?',(KEY,)).fetchone()
baseline_sha=hashlib.sha256((R/'.cache/host-restore.sqlite').read_bytes()).hexdigest()
immutable_tables=['pages','fragments','component_localizations','translations']
def table_hash(t):
 h=hashlib.sha256()
 for row in db.execute('select * from '+t+' order by 1,2'):h.update(json.dumps(row,ensure_ascii=False).encode())
 return h.hexdigest()
source_hashes={t:table_hash(t) for t in immutable_tables}
def check(name,value):
 assert value,name
 checks.append(name)
def get():
 r=s.get(BASE+'/api/admin/catalogue-editor');r.raise_for_status();return r.json()
def send(resource,data,method='POST',expected=201):
 r=s.request(method,BASE+'/api/admin/catalogue-editor/'+resource,json=data);check('HTTP '+str(expected)+' '+method+' '+resource,r.status_code==expected);return r.json()
def payload(name,kind='products'):return {'revision':get()['revision'],'kind':kind,'name_fa':name,'name_en':'LOCAL QA ONLY','published':True}
def restore():
 db.execute('delete from settings where key=?',(KEY,))
 if old:db.execute('insert into settings(key,value,updated_at) values(?,?,?)',(KEY,old[0],old[1]))
 db.commit()
errors=[];uploaded_path=None
try:
 initial=get();check('source records discovered, not recreated',len(initial['data']['items'])==494 and len(initial['data']['groups'])==19)
 check('admin-only phase explicitly marked',initial['public_connected'] is False)
 check('GET does not initialize or write registry',db.execute('select value,updated_at from settings where key=?',(KEY,)).fetchone()==old)
 check('API denies anonymous GET',requests.get(BASE+'/api/admin/catalogue-editor').status_code==401)
 check('API denies anonymous POST',requests.post(BASE+'/api/admin/catalogue-editor/groups',json={}).status_code==401)
 public_paths=['/','/global/home.html?lang=fa','/global/home.html?lang=en','/product/excavator.htm?lang=fa','/product/parts.htm?lang=fa','/product/pro-detail-5286.htm?lang=fa']
 before={p:s.get(BASE+p).content for p in public_paths}
 g=send('groups',payload('گروپ صرفاً آزمون محلی'));gid=g['saved_id'];check('persisted registry survives independent GET',get()['revision']==g['revision'])
 stale=payload('نسخهٔ قدیمی');stale['revision']=initial['revision'];send('groups',stale,expected=409)
 bad=payload('');send('groups',bad,expected=422)
 target=send('groups',payload('مقصد صرفاً آزمون محلی'));target_id=target['saved_id']
 part_group=send('groups',payload('گروپ قطعه صرفاً آزمون محلی','parts'))['saved_id']
 data=payload('مورد صرفاً آزمون محلی');data.update(group_ids=[gid],image='',description_fa='شرح آزمون، نه اطلاعات کسب‌وکار',description_en='',specs=[{'name':'مشخصهٔ آزمون','value':'مقدار آزمون'}])
 item=send('items',data);iid=item['saved_id'];saved=next(i for i in item['data']['items'] if i['id']==iid);check('photo optional and structured specs persist',saved['image']=='' and saved['specs'][0]['value']=='مقدار آزمون')
 bad=dict(data,revision=get()['revision'],group_ids=[part_group]);rev=get()['revision'];send('items',bad,expected=422);check('invalid operation leaves state unchanged',get()['revision']==rev)
 send('items',dict(data,revision=get()['revision'],group_ids=[gid,gid]),expected=422)
 send('items',dict(data,revision=get()['revision'],group_ids=[]),expected=422)
 send('items',dict(data,revision=get()['revision'],image='https://external.invalid/photo.jpg'),expected=422)
 send('items',dict(data,revision=get()['revision'],specs=[{'name':'ناقص'}]),expected=422)
 send('groups/'+gid,dict(payload('گروپ صرفاً آزمون محلی'),published=False),'PATCH',422)
 send('groups/'+gid+'/retire',{'revision':get()['revision']},expected=422)
 send('groups/'+gid+'/retire',{'revision':get()['revision'],'target_group_id':part_group},expected=422)
 check('failed retire preserves original membership',next(i for i in get()['data']['items'] if i['id']==iid)['group_ids']==[gid])
 second=next(g['id'] for g in initial['data']['groups'] if g['kind']=='products' and g['published'])
 send('items/'+iid,dict(data,revision=get()['revision'],group_ids=[gid,second]),'PATCH',200)
 moved=send('groups/'+gid+'/retire',{'revision':get()['revision'],'target_group_id':target_id},expected=200)
 check('atomic retirement preserves secondary memberships',next(i for i in moved['data']['items'] if i['id']==iid)['group_ids']==[second,target_id] and not next(g for g in moved['data']['groups'] if g['id']==gid)['published'])
 check('retirement never deletes children',len(moved['data']['items'])==495 and moved['transferred']==1)
 send('items',dict(data,revision=get()['revision']),expected=422)
 original=next(i for i in initial['data']['items'] if i['kind']=='products')
 edit=dict(original,revision=get()['revision'],name_fa='نام ویرایش‌شده فقط آزمون',path='/tampered.htm',id='tampered')
 updated=send('items/'+original['id'],edit,'PATCH',200);row=next(i for i in updated['data']['items'] if i['id']==original['id']);check('canonical ID and source path immutable',row['path']==original['path'] and row['id']==original['id'])
 send('items/'+original['id'],dict(edit,revision=get()['revision'],kind='parts'),'PATCH',422)
 with sync_playwright() as p:
  browser=p.chromium.launch();page=browser.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(BASE+'/',wait_until='networkidle');page.locator('#add').wait_for(state='visible');page.wait_for_function("!document.querySelector('#add').disabled")
  check('dashboard populated from real local API',page.locator('#productCount').inner_text().isdigit())
  page.click('#groupsTab');page.click('#add');page.fill('[name=name_fa]','گروپ فرم آزمایشی');page.click('#save');page.locator('#editor').wait_for(state='hidden')
  ui_gid=next(g['id'] for g in get()['data']['groups'] if g['name_fa']=='گروپ فرم آزمایشی')
  page.click('#itemsTab');page.click('#add');page.fill('[name=name_fa]','محصول فرم آزمایشی');page.locator('#groupChoices label').filter(has_text='گروپ فرم آزمایشی').locator('input').check();page.click('#addSpec');page.fill('[data-spec=name]','نام آزمون');page.fill('[data-spec=value]','مقدار آزمون');page.click('#save');page.locator('#editor').wait_for(state='hidden')
  check('real form creates item with correct group',any(i['name_fa']=='محصول فرم آزمایشی' and ui_gid in i['group_ids'] for i in get()['data']['items']))
  page.fill('#search','محصول فرم آزمایشی');check('search filters records',page.locator('.record').count()==1)
  page.locator('.record button').first.click();check('spec values reopen correctly',page.locator('[data-spec=value]').input_value()=='مقدار آزمون');page.locator('#editor .close').first.click()
  page.fill('#search','');page.click('[data-kind=parts]');page.click('#add');check('part form excludes product groups',page.locator('#groupChoices').inner_text().find('گروپ فرم آزمایشی')==-1)
  page.fill('[name=name_fa]','قطعه فرم آزمایشی');page.locator('#groupChoices label').filter(has_text='گروپ قطعه صرفاً آزمون محلی').locator('input').check()
  # Tiny synthetic test image, never a business photo. Stored outside project public files.
  png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=')
  page.locator('#photoUpload').set_input_files({'name':'LOCAL-QA-ONLY.png','mimeType':'image/png','buffer':png})
  page.wait_for_function("document.querySelector('[name=image]').value.startsWith('/uploads/')&&!document.querySelector('#save').disabled")
  uploaded_path=page.locator('[name=image]').input_value()
  check('real image upload isolated outside source public tree',(R/'.cache/catalogue-media'/uploaded_path.lstrip('/')).is_file() and not (R/'public'/uploaded_path.lstrip('/')).exists())
  check('uploaded image can be read locally',s.get(BASE+uploaded_path).status_code==200)
  page.click('#chooseMedia');page.fill('#mediaSearch',uploaded_path.split('/')[-1]);page.locator('.media-item').wait_for();page.locator('.media-item').click()
  check('media picker selects existing uploaded photo',page.locator('[name=image]').input_value()==uploaded_path)
  page.click('#save');page.locator('#editor').wait_for(state='hidden')
  check('real form creates independent part',any(i['kind']=='parts' and i['name_fa']=='قطعه فرم آزمایشی' for i in get()['data']['items']))
  page.screenshot(path=str(R/'reports/CATALOGUE-PHASE1-DESKTOP.png'));page.set_viewport_size({'width':393,'height':950});page.screenshot(path=str(R/'reports/CATALOGUE-PHASE1-MOBILE.png'));check('mobile dashboard no horizontal overflow',not page.evaluate('document.documentElement.scrollWidth>innerWidth'))
  check('no JS page errors',not errors);browser.close()
 unassigned=next(g for g in initial['data']['groups'] if g['id']=='unassigned-products')
 prior_count=len(get()['data']['items']);bulk=send('groups/'+unassigned['id']+'/retire',{'revision':get()['revision'],'target_group_id':target_id},expected=200)
 check('unassigned source records can transfer without deletion',bulk['transferred']==64 and len(bulk['data']['items'])==prior_count and not any(unassigned['id'] in i['group_ids'] for i in bulk['data']['items']))
 for path in public_paths:check('public response unchanged WITH saved catalogue '+path,s.get(BASE+path).content==before[path])
 for t,h in source_hashes.items():check('canonical source table unchanged '+t,table_hash(t)==h)
 check('baseline database never changed',baseline_sha==hashlib.sha256((R/'.cache/host-restore.sqlite').read_bytes()).hexdigest())
 report={'status':'passed','checks':checks,'checkCount':len(checks),'pageErrors':errors,'publicConnected':False,'sourceDatabaseUnchanged':True,'registryRestored':True}
except Exception as e:
 report={'status':'failed','checks':checks,'checkCount':len(checks),'error':str(e),'registryRestored':True};raise
finally:
 restore();
 if uploaded_path:(R/'.cache/catalogue-media'/uploaded_path.lstrip('/')).unlink(missing_ok=True)
 (R/'reports/CATALOGUE-PHASE1-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'status':report['status'],'checks':len(checks),'pageErrors':errors}))
