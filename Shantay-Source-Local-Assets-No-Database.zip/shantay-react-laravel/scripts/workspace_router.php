<?php
// LOCAL DEVELOPMENT ONLY. Never deploy this launcher or the key/sentinel.
$root=dirname(__DIR__);
if(!is_file($root.'/.cache/WORKSPACE_REPAIR_ONLY')){http_response_code(503);exit('Prepare the isolated workspace first.');}
if(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/'&&$_SERVER['REQUEST_METHOD']==='GET'&&!isset($_GET['site'])){header('Location: /admin');exit;}
$key=trim(file_get_contents($root.'/.cache/workspace.key'));
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
$readFragments=['/ext/ajax.jsp','/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp'];
$token=$_SERVER['HTTP_X_LOCAL_WORKSPACE_TOKEN']??'';$parts=explode('.',$token,2);
if(str_starts_with($path,'/api/admin/')&&count($parts)===2&&ctype_digit($parts[0])&&strlen($parts[0])<=12&&(int)$parts[0]>=time()&&hash_equals(hash_hmac('sha256',$parts[0],$key),$parts[1]))$_COOKIE['shantui_admin']=$token;
if($path==='/admin'&&in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'])){
 $expires=(string)(time()+14400);$token=$expires.'.'.hash_hmac('sha256',$expires,$key);
 $script='<script>(()=>{const t='.json_encode($token).';const f=window.fetch.bind(window);window.fetch=(input,o={})=>{const u=new URL(typeof input==="string"?input:input.url,location.href);if(u.origin===location.origin&&u.pathname.startsWith("/api/admin/")){const h=new Headers(o.headers||(input instanceof Request?input.headers:{}));h.set("X-Local-Workspace-Token",t);o={...o,headers:h};}return f(input,o);};})();</script>';
 header('Content-Type: text/html; charset=UTF-8');header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow');
 if($_SERVER['REQUEST_METHOD']!=='HEAD')echo str_replace('</head>',$script.'</head>',file_get_contents($root.'/public/admin/workspace.html'));exit;
}
$allowed=in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'])||in_array($path,$readFragments)||str_starts_with($path,'/api/admin/workspace/')||$path==='/api/admin/upload'||$path==='/api/admin/logout'||$path==='/api/admin/login'||$path==='/api/requests';
if(!$allowed){http_response_code(403);header('Content-Type: application/json');exit('{"error":"workspace_write_not_enabled"}');}
$values=['APP_ENV'=>'local','APP_DEBUG'=>'false','APP_KEY'=>$key,'APP_URL'=>'http://localhost','DB_CONNECTION'=>'sqlite','DB_DATABASE'=>$root.'/.cache/workspace.sqlite','DB_URL'=>'','CACHE_STORE'=>'file','SESSION_DRIVER'=>'array','MAIL_MAILER'=>'array','INQUIRY_EMAIL_ENABLED'=>'false','MANAGED_CONTENT_ENABLED'=>'true','MANAGED_CATALOGUE_ENABLED'=>'true','MANAGED_INQUIRIES_ENABLED'=>'true','MANAGED_IDENTITY_ENABLED'=>'true','SHANTUI_TRANSLATION_PREVIEW'=>'true','ADMIN_DEMO_ENABLED'=>'false','SHANTUI_MEDIA_ROOT'=>$root.'/.cache/host-media'];
foreach($values as $k=>$v){putenv($k.'='.$v);$_ENV[$k]=$v;$_SERVER[$k]=$v;}
$_SERVER['SCRIPT_NAME']='/index.php';$_SERVER['PHP_SELF']='/index.php';$_SERVER['SCRIPT_FILENAME']=$root.'/backend/public/index.php';unset($_SERVER['PATH_INFO']);
require $root.'/backend/vendor/autoload.php';$app=require $root.'/backend/bootstrap/app.php';$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
config(['shantui.local_workspace_session'=>true,'shantui.upload_root'=>$root.'/.cache/workspace-media']);
if(str_starts_with($path,'/uploads/')){$r=realpath($root.'/.cache/workspace-media/uploads');$f=realpath($root.'/.cache/workspace-media'.$path);if($r&&$f&&str_starts_with($f,$r.DIRECTORY_SEPARATOR)&&is_file($f)){header('Content-Type: '.mime_content_type($f));header('X-Content-Type-Options: nosniff');readfile($f);exit;}}
$app->handleRequest(Illuminate\Http\Request::capture());
