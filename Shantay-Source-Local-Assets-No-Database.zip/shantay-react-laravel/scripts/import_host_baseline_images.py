"""One-time public GET image import. No runtime proxy, no hosting writes."""
from pathlib import Path
import requests,re,json
from urllib.parse import urljoin,urlsplit
from concurrent.futures import ThreadPoolExecutor
R=Path(__file__).resolve().parents[1];BASE='https://test.grandtire.af'
paths=['/global/home.html','/product/excavator.htm','/product/parts.htm','/about/about-us.htm','/about/contact-us.htm','/product/pro-detail-5286.htm'];assets=set()
for path in paths:
 for lang in ['fa','en']:
  r=requests.get(BASE+path,params={'lang':lang},timeout=40);r.raise_for_status()
  for value in re.findall(r'''(?:["'(=\s])((?:/upload/|/uploads/)[^\s"'<>);]+)''',r.text):
   p=urlsplit(value).path
   if re.search(r'\.(?:jpe?g|png|webp|gif|svg|ico)$',p,re.I) and '..' not in p:assets.add(p)
def fetch(p):
 dest=R/'public'/p.lstrip('/')
 # Fetch current hosted bytes even when older local files exist.
 r=requests.get(BASE+p,timeout=45)
 if r.status_code!=200 or not r.headers.get('content-type','').startswith('image/'):return {'path':p,'ok':False,'status':r.status_code}
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(r.content);return {'path':p,'ok':True,'bytes':len(r.content)}
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(fetch,sorted(assets)))
report={'oneTimePublicGetOnly':True,'runtimeProxy':False,'results':results,'files':sum(v['ok'] for v in results),'bytes':sum(v.get('bytes',0) for v in results)}
(R/'reports/HOST-BASELINE-IMAGES.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='results'}))
