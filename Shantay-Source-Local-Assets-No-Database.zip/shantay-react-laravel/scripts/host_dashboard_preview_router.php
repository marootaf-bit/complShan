<?php
// Local launcher for the hosted dashboard's existing demo mode; no application edits.
if (parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/') {
    header('Location: /admin?demo=1');
    exit;
}
return require __DIR__.'/host_baseline_router.php';
