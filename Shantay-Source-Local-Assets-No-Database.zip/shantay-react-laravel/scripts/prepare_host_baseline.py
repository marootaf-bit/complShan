"""Prepare local runtime only; no remote connections or business writes."""
from pathlib import Path
import gzip,shutil
R=Path(__file__).resolve().parents[1]
(R/'.cache').mkdir(exist_ok=True)
db=R/'.cache/host-restore.sqlite'
if not db.exists():
    with gzip.open(R/'data/hosted-content.sqlite.gz','rb') as a,db.open('xb') as b:
        shutil.copyfileobj(a,b)
for p in ['bootstrap/cache','storage/framework/cache/data','storage/framework/sessions','storage/framework/views','storage/logs','storage/app/private','storage/app/public']:
    (R/'backend'/p).mkdir(parents=True,exist_ok=True)
if not (R/'dist').exists() and not (R/'dist').is_symlink():
    (R/'dist').symlink_to('hosted-frontend',target_is_directory=True)
print('Local sanitized content and runtime directories ready; no existing database overwritten.')
