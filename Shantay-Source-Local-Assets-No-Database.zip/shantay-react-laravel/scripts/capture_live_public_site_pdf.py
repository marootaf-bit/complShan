"""Read-only desktop capture of ALL published public routes; dashboard is excluded, never deleted.
Remote concurrency <=2. Temporary browser asset cache avoids repeatedly loading the host.
"""
import asyncio,hashlib,io,json,math,re,time
from pathlib import Path
from urllib.parse import urlsplit
from PIL import Image
from playwright.async_api import async_playwright
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

R=Path(__file__).resolve().parents[1]
WORK=R/'.cache/live-public-pdf';OUT=R/'deliverables/Live-Site-Desktop-All-Pages'
for p in [WORK,WORK/'assets',WORK/'shots',OUT]:p.mkdir(parents=True,exist_ok=True)
BASE='https://test.grandtire.af';rows=[];results=[];pdfs=[];started=time.time();network_requests=0;blocked_writes=0
READ_POST={'/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp'}
asset_cache={};network_gate=asyncio.Semaphore(2)

def status(phase):
 data={'phase':phase,'totalRoutes':len(rows),'captured':len(results),'screenshots':sum(bool(r.get('images')) for r in results),'failures':[{k:r.get(k) for k in ['path','status','error']} for r in results if not r.get('images')],'pdfs':pdfs,'seconds':round(time.time()-started),'remoteRequests':network_requests,'blockedNonReadRequests':blocked_writes,'dashboardDeleted':False,'dashboardCaptured':False,'locale':'fa','viewport':'1440x1000','imageStorageWidth':1200}
 (OUT/'PROGRESS.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));return data

async def network(route):
 global network_requests,blocked_writes
 req=route.request;url=urlsplit(req.url);method=req.method
 if method not in ['GET','HEAD'] and not(method=='POST' and url.path in READ_POST and url.hostname=='test.grandtire.af'):
  blocked_writes+=1;await route.abort();return
 allowed=url.hostname=='test.grandtire.af' or (url.hostname or '').endswith(('.google.com','.gstatic.com')) or url.hostname in ['google.com','gstatic.com']
 if not allowed:await route.abort();return
 if req.resource_type=='media':
  # Video is represented by the site's existing poster, not downloaded as a movie.
  await route.abort();return
 cached=asset_cache.get(req.url) if method=='GET' else None
 if cached:
  await route.fulfill(status=200,headers=cached[0],path=str(cached[1]));return
 try:
  async with network_gate:
   network_requests+=1
   response=await route.fetch(timeout=45000,max_retries=1)
   headers=dict(response.headers);mime=headers.get('content-type','').split(';')[0]
   if method=='GET' and response.status==200 and (mime.startswith(('image/','font/')) or mime in ['text/css','application/javascript','text/javascript','application/font-woff','application/octet-stream'] and re.search(r'\.(css|js|woff2?|ttf|eot)(?:\?|$)',req.url,re.I)):
    body=await response.body();f=WORK/'assets'/hashlib.sha256(req.url.encode()).hexdigest();f.write_bytes(body)
    headers={k:v for k,v in headers.items() if k.lower() not in ['set-cookie','content-encoding','transfer-encoding','content-length']};asset_cache[req.url]=(headers,f)
    await route.fulfill(status=200,headers=headers,body=body)
   else:await route.fulfill(response=response)
 except Exception:
  try:await route.abort()
  except Exception:pass

async def capture(context,row):
 path=row['path'];url=BASE+path+'?lang=fa';page=await context.new_page();record={'path':path,'url':url,'title':row['title'],'images':[],'status':0,'capturedAtUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 try:
  response=await page.goto(url,wait_until='load',timeout=75000);record['status']=response.status if response else 0
  if record['status']!=200:raise RuntimeError('HTTP '+str(record['status']))
  await page.evaluate('document.fonts.ready')
  if await page.locator('a.refu').count():
   try:await page.locator('a.refu').first.click(timeout=1000)
   except Exception:pass
  await page.wait_for_timeout(200)
  height=await page.evaluate('document.documentElement.scrollHeight')
  for y in range(0,height,850):
   await page.evaluate('(y)=>window.scrollTo(0,y)',y);await page.wait_for_timeout(85)
  await page.wait_for_timeout(300)
  await page.evaluate("()=>{document.querySelectorAll('video').forEach(v=>v.pause());document.querySelectorAll('*').forEach(n=>n.swiper?.autoplay?.stop());scrollTo(0,0)}")
  await page.wait_for_timeout(200)
  record['height']=await page.evaluate('document.documentElement.scrollHeight')
  record['missingImages']=await page.evaluate("Array.from(document.images).filter(i=>i.getBoundingClientRect().width>0&&!i.naturalWidth).length")
  png=await page.screenshot(type='png',full_page=True,timeout=45000,animations='disabled')
  image=Image.open(io.BytesIO(png)).convert('RGB')
  if image.width>1200:image=image.resize((1200,round(image.height*1200/image.width)),Image.Resampling.LANCZOS)
  # Very tall pages are split only to stay within standard PDF page dimensions.
  for n,y in enumerate(range(0,image.height,18000)):
   piece=image.crop((0,y,image.width,min(y+18000,image.height)));f=WORK/'shots'/(hashlib.sha256(path.encode()).hexdigest()+f'-{n}.jpg');piece.save(f,'JPEG',quality=48,optimize=True)
   record['images'].append(str(f))
 except Exception as e:record['error']=str(e)[:500]
 finally:
  await page.close()
 return record

def make_pdf(filename,entries):
 target=OUT/filename;c=canvas.Canvas(str(target),pageCompression=1);c.setTitle('Live hosted website - all public desktop pages');c.setAuthor('Shantay website visual review')
 cover_pages=max(1,math.ceil(len(entries)/40))
 page_lookup={};page_number=cover_pages
 for entry in entries:
  count=max(1,len(entry['images']));page_lookup[entry['path']]=list(range(page_number+1,page_number+count+1));page_number+=count
 for start in range(0,max(1,len(entries)),40):
  c.setPageSize((720,900));c.setFont('Helvetica-Bold',16);c.drawString(30,860,'LIVE WEBSITE - DESKTOP REFERENCE');c.setFont('Helvetica',10);c.drawString(30,837,filename);c.drawString(30,818,'Source: https://test.grandtire.af | Dari | Browser viewport: 1440 x 1000')
  c.setFont('Helvetica',9);c.drawString(30,796,'Every screenshot includes the full page. Dashboard/login pages are excluded, not deleted.');c.drawString(30,780,'Videos use existing posters. Images are size-optimized. Tabs remain in their default state.')
  c.drawString(30,764,'Capture is read-only; no business forms or admin actions were submitted.')
  for n,entry in enumerate(entries[start:start+40]):
   line=f"{page_lookup[entry['path']][0]:>3}   {entry['path']}";c.drawString(30,735-n*16,line[:125])
  c.showPage()
 for entry in entries:
  for image_index,file in enumerate(entry['images'] or [None]):
   if file:
    im=Image.open(file);w,h=im.size;scale=720/w;ph=h*scale+64;c.setPageSize((720,ph));c.setFont('Helvetica',8);c.drawString(14,ph-18,entry['url'][:145]);c.drawString(14,ph-33,f"Desktop 1440px | full page | PDF page {page_lookup[entry['path']][image_index]} | segment {image_index+1}/{len(entry['images'])}");c.linkURL(entry['url'],(12,ph-24,708,ph-10),relative=0,thickness=0);c.drawImage(file,0,12,width=720,height=h*scale)
   else:
    c.setPageSize((720,900));c.setFont('Helvetica-Bold',16);c.drawString(30,850,'PAGE COULD NOT BE CAPTURED');c.setFont('Helvetica',10);c.drawString(30,820,entry['url'][:110]);c.drawString(30,800,str(entry.get('error','Unknown capture error'))[:110]);c.drawString(30,770,'This page is listed for transparency; it is not a successful screenshot.')
   c.showPage()
  entry['pdf']=filename;entry['pdfPages']=page_lookup[entry['path']]
 c.save()
 return {'file':filename,'routes':len(entries),'pdfPages':page_number,'successful':sum(bool(e['images']) for e in entries),'bytes':target.stat().st_size}

async def main():
 global rows
 async with async_playwright() as p:
  request=await p.request.new_context();response=await request.get(BASE+'/api/site/routes',timeout=45000);assert response.status==200;all_rows=await response.json();await request.dispose()
  rows=[r for r in all_rows if not re.search(r'^/(?:admin|login|dashboard)(?:/|\?|$)',r['path'])]
  parts=[r for r in rows if '/product/parts-detail-' in r['path']];products=[r for r in rows if '/product/pro-detail-' in r['path']];news=[r for r in rows if r['path'].startswith('/news/')];other=[r for r in rows if r not in parts and r not in products and r not in news];other.sort(key=lambda r:(r['path']!='/global/home.html',r['path']))
  batches=[('01-Main-Pages-Categories-Solutions.pdf',other),('02-Parts-All-Details.pdf',parts)]
  for i in range(0,len(products),60):batches.append((f'03-Products-{i//60+1:02}.pdf',products[i:i+60]))
  for i in range(0,len(news),50):batches.append((f'04-News-{i//50+1:02}.pdf',news[i:i+50]))
  (OUT/'ROUTES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('START '+str(len(rows))+' public routes; '+str(len(batches))+' PDF parts; remote concurrency 2',flush=True);status('capturing')
  browser=await p.chromium.launch();contexts=[await browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=1,service_workers='block') for _ in range(2)]
  for ctx in contexts:await ctx.route('**/*',network)
  for filename,batch in batches:
   queue=asyncio.Queue()
   for i,r in enumerate(batch):queue.put_nowait((i,r))
   captured={}
   async def worker(ctx):
    while not queue.empty():
     try:i,r=queue.get_nowait()
     except asyncio.QueueEmpty:return
     record=await capture(ctx,r)
     if not record['images']:
      await asyncio.sleep(1);record=await capture(ctx,r)
     captured[i]=record;results.append(record);queue.task_done();status('capturing')
     if len(results)%10==0:print('PROGRESS '+str(len(results))+'/'+str(len(rows))+' '+r['path'],flush=True)
   await asyncio.gather(*(worker(ctx) for ctx in contexts))
   entries=[captured[i] for i in range(len(batch))];part=make_pdf(filename,entries);pdfs.append(part)
   (OUT/'MANIFEST.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));status('capturing');print('PDF_READY '+filename+' '+str(part['successful'])+'/'+str(part['routes'])+' routes '+str(part['bytes'])+' bytes',flush=True)
   # The PDF is the deliverable; do not retain duplicate screenshot assets.
   for entry in entries:
    for f in entry['images']:Path(f).unlink(missing_ok=True)
  for ctx in contexts:await ctx.close()
  await browser.close()
 s=status('complete' if all(r['images'] for r in results) else 'complete_with_failures')
 c=canvas.Canvas(str(OUT/'00-READ-FIRST-INDEX.pdf'),pageCompression=1);c.setPageSize((720,900));c.setFont('Helvetica-Bold',18);c.drawString(30,855,'ALL PUBLIC PAGES - LIVE DESKTOP CAPTURE');c.setFont('Helvetica',11);c.drawString(30,825,'https://test.grandtire.af | Dari | Desktop viewport 1440 x 1000');c.drawString(30,803,f"Public routes: {len(rows)} | Successful screenshots: {s['screenshots']} | PDF parts: {len(pdfs)}")
 c.setFont('Helvetica',10);c.drawString(30,778,'Dashboard is still installed. It is excluded from this screenshot set, not deleted.');c.drawString(30,758,'Open each part listed below. Every part has a URL-to-PDF-page contents list.');c.drawString(30,738,'Use the PDF filename and PDF page number when marking dashboard requirements.');c.drawString(30,718,'Scope: default page states, top to bottom; not every carousel slide/tab interaction.');c.drawString(30,698,'Static screenshot images are optimized for size. Video playback is not embedded.');c.drawString(30,678,'No business writes, form submissions, account changes or deployment were performed.')
 for i,part in enumerate(pdfs):c.drawString(30,640-i*25,f"{part['file']}   |  {part['routes']} routes  |  {part['pdfPages']} PDF pages  |  {part['bytes']/1048576:.1f} MiB")
 c.showPage();c.save();(OUT/'MANIFEST.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('COMPLETE '+json.dumps(s),flush=True)

if __name__=='__main__':asyncio.run(main())
