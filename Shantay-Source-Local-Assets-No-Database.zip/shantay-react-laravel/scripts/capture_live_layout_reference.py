"""Normal-browser, read-only desktop screenshots: one representative per layout family.
No route.fetch/response rewriting: preserve normal stylesheet and font loading.
"""
from pathlib import Path
import json,time,math
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab import rl_config
rl_config.useA85=0
R=Path(__file__).resolve().parents[1];W=R/'.cache/live-layout-reference';W.mkdir(exist_ok=True);BASE='https://test.grandtire.af'
entries=[
 ('Homepage','/global/home.html'),
 ('About - introduction','/about/about-us.htm'),
 ('About - business strengths','/about/business-strength.htm'),
 ('About - group profile','/about/group.htm'),
 ('About - timeline','/about/history.htm'),
 ('Contact, offices and map','/about/contact-us.htm'),
 ('Video centre','/about/video_center.htm'),
 ('Product category and filters','/product/excavator.htm'),
 ('Product detail - standard','/product/pro-detail-5286.htm'),
 ('Parts list and groups','/product/parts.htm'),
 ('Part detail','/product/parts-detail-14.htm'),
 ('Solutions overview','/solution/solution.htm'),
 ('Solution detail','/solution/solution-detail-3443.htm'),
 ('Service inquiry form','/service/inquiry.htm'),
 ('Parts support','/service/parts-support.htm'),
 ('Service support','/service/service-support.htm'),
 ('News overview','/news/news-center.htm'),
 ('News article','/news/activitiynews-detail-2527.htm'),
 ('Search','/site/search.htm'),
 ('Sitemap','/site/sitemap.htm'),
 ('Privacy information','/site/Privacy.htm'),
]
read_post={'/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp'}
records=[];blocked=[]
def route(reqroute):
 q=reqroute.request;path=urlsplit(q.url).path
 if q.method in ['GET','HEAD'] or (q.method=='POST' and path in read_post and urlsplit(q.url).hostname=='test.grandtire.af'):reqroute.continue_()
 else:blocked.append({'url':q.url,'method':q.method});reqroute.abort()

with sync_playwright() as p:
 browser=p.chromium.launch();context=browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=1)
 context.route('**/*',route)
 for index,(label,path) in enumerate(entries):
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   response=page.goto(BASE+path+'?lang=fa',wait_until='networkidle',timeout=70000);assert response.status==200, str(response.status)
   page.evaluate('document.fonts.ready')
   if page.locator('a.refu').count():
    try:page.locator('a.refu').first.click(timeout=1500)
    except Exception:pass
   page.wait_for_timeout(400)
   # Explicitly verify the public design is styled, rather than a raw DOM capture.
   css=page.evaluate("({sheets:document.styleSheets.length,font:getComputedStyle(document.body).fontFamily,links:Array.from(document.querySelectorAll('link[rel=stylesheet]')).map(n=>({url:n.href,loaded:!!n.sheet}))})")
   assert css['sheets']>3, 'Insufficient stylesheets'
   important=[x for x in css['links'] if '/resources/web/css/' in x['url'] or '/global/local-global-shell.css' in x['url']]
   assert important and all(x['loaded'] for x in important),'Core stylesheet missing'
   h=page.evaluate('document.documentElement.scrollHeight')
   for y in range(0,h,800):page.evaluate('(y)=>scrollTo(0,y)',y);page.wait_for_timeout(140)
   page.wait_for_timeout(800);page.evaluate("()=>{document.querySelectorAll('video').forEach(v=>v.pause());document.querySelectorAll('*').forEach(n=>n.swiper?.autoplay?.stop());scrollTo(0,0)}");page.wait_for_timeout(500)
   file=W/f'{index+1:02}.png';page.screenshot(path=str(file),full_page=True,animations='disabled',timeout=45000)
   record={'label':label,'path':path,'url':BASE+path+'?lang=fa','status':response.status,'height':page.evaluate('document.documentElement.scrollHeight'),'css':css,'pageErrors':errors,'file':str(file)};records.append(record)
   print('CAPTURED '+str(index+1)+'/'+str(len(entries))+' '+path+' height='+str(record['height']),flush=True)
  finally:page.close()
 context.close();browser.close()

out=R/'deliverables/Shantay-Live-Desktop-Page-Types.pdf';c=canvas.Canvas(str(out),pageCompression=1);c.setTitle('Live Shantay website - distinct desktop page layouts');c.setAuthor('Shantay visual review')
# Contents page; each screenshot keeps its full source resolution and colour.
pdf_page=2
for record in records:
 im=Image.open(record['file']);record['segments']=math.ceil(im.height/18000);record['pdfPages']=list(range(pdf_page,pdf_page+record['segments']));pdf_page+=record['segments']
c.setPageSize((800,1050));c.setFont('Helvetica-Bold',19);c.drawString(28,1010,'LIVE WEBSITE - DISTINCT DESKTOP PAGE TYPES');c.setFont('Helvetica',10);c.drawString(28,985,'Source: https://test.grandtire.af | Dari | Desktop viewport 1440 x 1000');c.drawString(28,966,'One full-page sample for each selected layout family. Repeated products/parts/news omitted.');c.drawString(28,947,'Dashboard remains installed; dashboard and login screens are NOT photographed.');c.drawString(28,928,'Screenshots are from the live host, not the local preview. Site files/data were not changed.');c.drawString(28,909,'Screenshots preserve full pixel resolution. Videos are paused; similar tabs are not repeated.');c.drawString(28,890,'For annotations, refer to the PDF page number and the labelled section below.')
c.setFont('Helvetica',9)
for i,record in enumerate(records):
 y=855-i*31;c.drawString(28,y,f"{record['pdfPages'][0]:>2}   {record['label']}");c.setFont('Helvetica',8);c.drawString(53,y-12,record['path']);c.setFont('Helvetica',9)
c.showPage()
for record in records:
 image=Image.open(record['file']).convert('RGB')
 for n,y in enumerate(range(0,image.height,18000)):
  part=image.crop((0,y,image.width,min(image.height,y+18000)));w,h=part.size;scale=800/w;ph=h*scale+66;c.setPageSize((800,ph));c.setFont('Helvetica-Bold',10);c.drawString(14,ph-17,f"Page {record['pdfPages'][n]} - {record['label']}");c.setFont('Helvetica',8);c.drawString(14,ph-33,record['url']);c.drawString(14,ph-47,'Live host | desktop 1440px | full-page screenshot'+(f" | segment {n+1}/{record['segments']}" if record['segments']>1 else ''));c.linkURL(record['url'],(12,ph-38,788,ph-25),relative=0,thickness=0)
  from reportlab.lib.utils import ImageReader
  c.drawImage(ImageReader(part),0,10,width=800,height=h*scale);c.showPage()
c.save()
report={'status':'passed','routeCount':len(records),'pdfPages':pdf_page-1,'source':BASE,'locale':'fa','viewport':'1440x1000','styleLoadingVerified':True,'remoteBusinessWrites':0,'dashboardDeleted':False,'dashboardIncluded':False,'scope':'Representative distinct public layouts, top-to-bottom; repeated products, parts, articles and similar tab states omitted per owner instruction. Not every URL or interactive state.','blockedRequests':blocked,'entries':[{k:v for k,v in r.items() if k!='file'} for r in records],'output':str(out),'bytes':out.stat().st_size}
(R/'reports/LIVE-LAYOUT-REFERENCE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('COMPLETE '+json.dumps({k:report[k] for k in ['routeCount','pdfPages','bytes','output']}),flush=True)
