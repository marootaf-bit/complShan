"""Read-only regression: direct dashboard entry without auth cookies; no form saves or DB writes."""
from pathlib import Path
import json,requests
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:5183';checks=[];errors=[]
assert (R/'.cache/CATALOGUE_PREVIEW_ONLY').exists()
def check(name,condition):
 assert condition,name
 checks.append(name)
with sync_playwright() as p:
 browser=p.chromium.launch()
 for width in [393,1440]:
  context=browser.new_context(viewport={'width':width,'height':950});context.add_init_script("const nativeFetch=window.fetch.bind(window);window.fetch=(u,o={})=>nativeFetch(u,{...o,credentials:'omit'});");page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(BASE+'/admin/catalogue',wait_until='networkidle');page.wait_for_function("!document.querySelector('#add').disabled")
  check('direct entry loads without auth cookies '+str(width),not any(c['name']=='shantui_admin' for c in context.cookies()))
  for kind in ['products','parts']:
   page.click('[data-kind='+kind+']')
   for view in ['items','groups']:
    page.click('#'+view+'Tab');page.click('#add')
    check('add opens '+kind+' '+view+' '+str(width),page.locator('#editor').evaluate('(n)=>n.open'))
    if view=='groups':check('item-only fields hidden in group form '+str(width)+' '+kind,not page.locator('[name=description_fa]').is_visible())
    page.locator('#editor .close').first.click()
  context.clear_cookies();page.click('#reload');page.wait_for_function("document.querySelector('#message').textContent.includes('آماده')")
  check('reload works with no cookies '+str(width),not page.locator('#add').is_disabled())
  context.close()
 browser.close()
check('unsigned direct API remains protected',requests.get(BASE+'/api/admin/catalogue-editor').status_code==401)
check('forged preview token rejected',requests.get(BASE+'/api/admin/catalogue-editor',headers={'X-Local-Catalogue-Token':'9999999999.invalid'}).status_code==401)
check('no JavaScript errors',not errors)
report={'status':'passed','checkCount':len(checks),'checks':checks,'pageErrors':errors,'businessWrites':0,'scope':'Direct-entry add dialogs for products, parts and both group tabs at 393/1440, without auth cookies. No record saves.'}
(R/'reports/CATALOGUE-ADD-BUTTON-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report))
