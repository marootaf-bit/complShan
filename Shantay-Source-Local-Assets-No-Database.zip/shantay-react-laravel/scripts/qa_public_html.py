"""Read-only exhaustive local native-page comparison; excludes declared nonvisual inquiry binding only."""
from pathlib import Path
import requests,sqlite3,json,re
R=Path(__file__).resolve().parents[1];c=sqlite3.connect(R/'.cache/workspace.sqlite');cases=c.execute("select locale,path from managed_pages where status='published' and deleted_at is null and kind!='fragment' order by locale,path").fetchall();bad=[];matched=0;s=requests.Session()
for locale,path in cases:
 a=s.get('http://127.0.0.1:5185'+path,params={'lang':locale},timeout=20);b=s.get('http://127.0.0.1:5186'+path,params={'lang':locale},timeout=20);html=re.sub(r'<script src="/global/inquiry-context.js"></script>','',b.text)
 if a.status_code==b.status_code==200 and a.text==html:matched+=1
 else:bad.append({'locale':locale,'path':path,'before':a.status_code,'after':b.status_code})
r={'scope':'All currently published native locale pages against read-only local source baseline; nonvisual inquiry script excluded, no CSS/markup normalization','tested':len(cases),'matched':matched,'mismatches':bad};(R/'reports/ACTIVE-FLAGS-PUBLIC-HTML-QA.json').write_text(json.dumps(r,indent=2));print(json.dumps(r));assert not bad
