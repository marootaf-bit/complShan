import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';
// Media and catalogue requests are served ONLY by our Laravel backend.
// The importer is a separate one-time installation tool, never a runtime proxy.
const apiProxy={target:'http://127.0.0.1:5175',changeOrigin:true};
const proxy=Object.fromEntries(['/api','/admin','/authCodeServlet','/core','/ext','/solution/solution.jsp','/resources','/upload','/uploads'].map(k=>[k,apiProxy]));
function cmsRoutes(){
 const handle=(req,res,next)=>{
  if(['GET','HEAD'].includes(req.method)&&req.url&&!req.url.startsWith('/admin')){
   try{const u=new URL(req.url,'http://vite.local');const pathname=decodeURIComponent(u.pathname);if(/^\/(?:backend|database|storage|vendor|data|reports|scripts|deploy|deliverables|\.cache|\.git)(?:\/|$)/i.test(pathname)||/^\/@fs\/.*\/(?:backend|database|storage|data|reports|scripts|deploy|deliverables|\.cache|\.git)(?:\/|$)/i.test(pathname)||/^\/\.(?!well-known\/)/.test(pathname)){res.statusCode=404;res.setHeader('Cache-Control','no-store');return res.end('Not found')}if(/^\/case(?:\/|$)/.test(u.pathname)){res.statusCode=404;res.setHeader('Content-Type','text/plain; charset=utf-8');return res.end('This route was removed.')}if(/\.(?:html?|htm)$/i.test(u.pathname)){if(fs.existsSync(path.resolve('public','.'+u.pathname)))return next();const q=new URLSearchParams(u.search);q.set('path',u.pathname);req.url='/api/site/render?'+q.toString()}}
   catch{}
  }
  next()
 };
 return {name:'cms-dynamic-pages',configureServer(server){server.middlewares.use(handle)},configurePreviewServer(server){server.middlewares.use(handle)}}
}
const adminRoute={name:'admin-route',configureServer(server){server.middlewares.use((req,res,next)=>{if(req.url==='/admin'||req.url==='/admin/')req.url='/admin/index.html';next()})},configurePreviewServer(server){server.middlewares.use((req,res,next)=>{if(req.url==='/admin'||req.url==='/admin/')req.url='/admin/index.html';next()})}};
export default defineConfig({
  plugins:[react(),cmsRoutes(),adminRoute],
  server:{host:'0.0.0.0',allowedHosts:true,proxy,fs:{strict:true,allow:['src','public','node_modules','index.html'].map(p=>path.resolve(p)),deny:['**/.env','**/.env.*','**/*.{crt,pem,key}','**/.git/**','**/backend/**','**/data/**','**/reports/**','**/.cache/**']},watch:{ignored:['**/backend/**','**/data/**','**/reports/**']}}, 
  preview:{host:'0.0.0.0',allowedHosts:true,proxy},
  build:{copyPublicDir:false}
});
