# Shantay Afghanistan — phase 1 catalogue administration

**Current:** local product/parts administration implemented on the restored hosted baseline. No public rendering integration or deployment. See [phase 1 scope and QA](reports/CATALOGUE-PHASE1.md). The existing 182 public assets/bundle files remain unchanged; 55 local HTTP/UI checks pass.

## Restored hosted baseline

The active local project has been reset to the application currently deployed at **https://test.grandtire.af**, by the owner's explicit request. No remote files, credentials, database records, or accounts were changed.

**Current status and restart instructions:** [راهنمای نسخهٔ مبنا](README-LOCAL-DARI.md).

- 242 hosted application/frontend/manifest files downloaded over verified TLS FTPS and SHA-256 verified.
- Editable React source rebuilt: generated HTML, active JS and CSS match the deployed artifacts byte-for-byte.
- Five sampled HTTP responses match the host byte-for-byte.
- Rejected Studio/native-catalogue implementation and obsolete audit claims are no longer in the active source tree.
- Local preview uses a sanitized content database and blocks business writes. It does not use real hosting accounts.
- Large media library is not fully mirrored; 99 public images were imported once for sampled pages. No runtime remote proxy.
- The owner approved phase 1 product/parts administration. Review is required before public integration or further scopes; deployment remains unauthorized.

Runtime compiled artifacts are stored in `hosted-frontend/` (`dist` is a symlink) so the workspace can preserve the actual hosted bundle. Local-only preview tooling lives in `scripts/`, separate from the unchanged hosted application code.

The existing files under `deliverables/` are historical deliverables, not a certification of the current baseline. See current evidence in `reports/HOST-BASELINE-*.json`.
