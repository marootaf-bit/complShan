New inquiry stored in your own website backend.
Request ID: {{ $requestId }}

@foreach($payload as $key => $value)
{{ $key }}: {{ $value }}
@endforeach

Manage this request in the website dashboard. This notification does not confirm price, availability or warranty.
