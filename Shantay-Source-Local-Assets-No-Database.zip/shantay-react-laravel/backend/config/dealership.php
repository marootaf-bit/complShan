<?php
return [
 'fields'=>[
  'dealer.enabled'=>['فعال بودن هویت نمایندگی','1'],
  'dealer.name_fa'=>['نام فارسی شرکت','شانتای افغانستان'],
  'dealer.name_en'=>['نام انگلیسی شرکت','Shantay Afghanistan'],
  'dealer.logo'=>['لوگوی شرکت','/global/dealer/company-logo.png'],
  'dealer.phone'=>['شمارهٔ تماس','0705078335'],
  'dealer.whatsapp'=>['شمارهٔ واتساپ با کود کشور','93705078335'],
  'dealer.email'=>['ایمیل','alisinarajabi08@gmail.com'],
  'dealer.address_fa'=>['آدرس فارسی','افغانستان، بلخ، شهر مزار شریف'],
  'dealer.address_en'=>['آدرس انگلیسی','Mazar-e-Sharif, Balkh, Afghanistan'],
  'dealer.tagline_fa'=>['شعار بنر','نمایندگی رسمی شانتای در افغانستان'],
  'dealer.tagline_en'=>['شعار بنر انگلیسی','Official Shantui dealership in Afghanistan'],
  'dealer.intro_fa'=>['معرفی نمایندگی','شانتای افغانستان، نمایندگی رسمی شرکت شانتای در افغانستان است. دفتر نمایندگی در ولایت بلخ، شهر مزار شریف قرار دارد. برای انتخاب ماشین‌آلات، معلومات مدل‌ها، استعلام قطعات و دریافت قیمت با تیم نمایندگی در تماس باشید. تولید ماشین‌آلات، مشخصات فنی و دستاوردهای صنعتیِ معرفی‌شده مربوط به شرکت سازندهٔ شانتای است؛ ما نمایندگی آن در افغانستان هستیم.'],
  'dealer.intro_en'=>['معرفی انگلیسی','Shantay Afghanistan is the official Shantui dealership in Afghanistan, with its office in Mazar-e-Sharif, Balkh. Contact our local team for machinery selection, model information, parts inquiries and quotations. Manufacturing, technical specifications and industrial achievements presented on this website belong to Shantui, the manufacturer; we are its Afghanistan dealership.'],
  'dealer.products_fa'=>['متن دامنهٔ محصولات','کاتالوگ ماشین‌آلات و قطعات شانتای را بررسی کنید و برای انتخاب مدل یا شناسایی قطعه با نمایندگی رسمی در افغانستان تماس بگیرید. قیمت، موجودی، شرایط عرضه و زمان تحویل هر درخواست جداگانه تأیید می‌شود.'],
  'dealer.products_en'=>['دامنهٔ محصولات انگلیسی','Explore the Shantui machinery and parts catalogue and contact the official Afghanistan dealership for model selection and parts identification. Pricing, availability, supply terms and delivery are confirmed for each inquiry.'],
  'dealer.process_fa'=>['روش همکاری','مدل ماشین، نوع پروژه و نیاز خود را با ما شریک کنید. برای دریافت معلومات و درخواست قیمت از فرم سایت، تماس تلفنی یا واتساپ استفاده کنید. تصاویر ماشین‌آلات و مشخصات فنی از منابع سازنده‌اند؛ آن‌ها عکس پروژه یا دفتر نمایندگی ما معرفی نمی‌شوند.'],
  'dealer.process_en'=>['روش همکاری انگلیسی','Share your preferred model and project requirements through the inquiry form, telephone or WhatsApp. Machinery photography and technical specifications come from manufacturer references, not from claimed local projects or facilities.'],
  'dealer.image_note_fa'=>['توضیح تصاویر مرجع','تصاویر سایت از رسانه‌های مرجع سازنده‌اند؛ این تصاویر، دفتر یا پروژهٔ محلی نمایندگی معرفی نمی‌شوند.'],
  'dealer.image_note_en'=>['توضیح تصاویر مرجع انگلیسی','Site images are manufacturer media references, not photographs of the local dealership office or its projects.'],
  'dealer.history_fa'=>['آرشیو تاریخچهٔ نمایندگی — فعلاً نمایش ندارد','متن نمونهٔ قابل‌ویرایش: در این بخش، تاریخ آغاز فعالیت شانتای افغانستان، مراحل توسعه و رویدادهای واقعی شرکت خود را درج کنید. سال تأسیس و تاریخ شروع نمایندگی هنوز ثبت نشده‌اند.'],
  'dealer.history_en'=>['آرشیو تاریخچهٔ نمایندگی انگلیسی — فعلاً نمایش ندارد','Editable sample: add the actual founding date, dealership start date and milestones of Shantay Afghanistan here. No founding year or historical achievements have been verified.'],
  'dealer.services_fa'=>['معلومات محصولات و ارتباط با دفتر','برای معلومات مدل‌ها، مشخصات ماشین‌آلات و درخواست قیمت با دفتر شانتای افغانستان تماس بگیرید. نام مدل، نوع پروژه و نیاز خود را با ما شریک کنید. شرایط عرضه، تحویل و هرگونه پشتیبانی یا ضمانت باید برای همان درخواست از دفتر تأیید شود؛ این صفحه وعدهٔ موجودی آماده یا خدمت تأییدنشده نیست.'],
  'dealer.services_en'=>['معلومات محصولات و ارتباط با دفتر انگلیسی','Contact Shantay Afghanistan for model information, machinery specifications and quotations. Share your preferred model and project requirements. Supply, delivery and any support or warranty terms must be confirmed by the office for your request; this page does not promise ready stock or unconfirmed services.'],
  'dealer.hours_fa'=>['راهنمای هماهنگی ساعات کاری','پیش از مراجعه، ساعات کاری را تلفنی با دفتر هماهنگ کنید.'],
  'dealer.hours_en'=>['راهنمای ساعات کاری انگلیسی','Please telephone the office to confirm opening hours before visiting.'],
  'dealer.privacy_fa'=>['حریم خصوصی — دیموی قابل بازبینی','حریم خصوصی {{company}} — متن نمونهٔ قابل‌ویرایش

این متن نمونه برای تکمیل سیاست واقعی شرکت است و نیاز به بازبینی پیش از انتشار نهایی دارد.

معلومات درج‌شده در فرم برای بررسی درخواست و ارتباط با متقاضی دریافت می‌شود. لطفاً معلومات غیرضروری و حساس را ارسال نکنید.

برای پرسش دربارهٔ معلومات خود، با {{email}} تماس بگیرید.

مدت نگهداری معلومات، شرایط حذف و جزئیات مسئولیت شرکت باید توسط مدیر تکمیل شود.'],
  'dealer.privacy_en'=>['حریم خصوصی انگلیسی — دیمو','{{company}} privacy — editable sample

This sample must be reviewed and completed before release.

Inquiry form details are collected to review requests and contact applicants. Do not send unnecessary sensitive information.

Contact {{email}} about your information.

The administrator must complete retention, deletion and responsibility details.'],
  'dealer.manufacturer_enabled'=>['نمایش معرفی، توانمندی‌ها، تاریخچه و ویدیوهای سازنده','1'],
  'dealer.manufacturer_note_fa'=>['توضیح تفکیک محتوای سازنده','این معلومات و رسانه‌ها از محتوای مرجع شرکت سازندهٔ شانتای‌اند؛ تاریخچه، توانمندی‌ها، خبرها و نمونه‌های کاربرد این بخش، سابقه یا پروژهٔ انجام‌شدهٔ نمایندگی افغانستان معرفی نمی‌شوند.'],
  'dealer.manufacturer_note_en'=>['توضیح محتوای سازنده انگلیسی','This is reference content from the Shantui manufacturer. Its history, capabilities, news and application examples are not presented as the history, capabilities or completed projects of the Afghanistan dealership.'],
  'dealer.parts_intro_fa'=>['معرفی بخش قطعات','برای استعلام قطعات شانتای، نام مدل ماشین، کد قطعه یا تصویر واضح آن را با دفتر مزار شریف شریک کنید. سازگاری، قیمت و موجودی هر قطعه باید پس از بررسی درخواست تأیید شود.'],
  'dealer.parts_intro_en'=>['Parts introduction','For Shantui parts inquiries, share the machine model, part number or a clear photograph with our Mazar-e-Sharif office. Compatibility, price and availability must be confirmed for each request.'],
  'dealer.parts_identification_fa'=>['راهنمای شناسایی قطعه','در صورت موجودبودن، شمارهٔ سریال ماشین و کد درج‌شده روی قطعه را ارسال کنید. معلومات کامل‌تر به بررسی درخواست کمک می‌کند؛ جایگزینی قطعه باید پس از تأیید سازگاری انجام شود.'],
  'dealer.parts_identification_en'=>['Part identification','If available, provide the machine serial number and the code marked on the part. Complete details help review the request; a replacement must be confirmed as compatible.'],
  'dealer.parts_terms_fa'=>['شرایط استعلام قطعات','برای قیمت، موجودی، شرایط پرداخت، تحویل و هرگونه ضمانت قطعه با دفتر نمایندگی هماهنگ کنید. نمایش قطعات در کاتالوگ به معنی موجودی آماده یا ضمانت تأییدشده نیست.'],
  'dealer.parts_terms_en'=>['Parts inquiry terms','Contact the dealership to confirm pricing, availability, payment, delivery and any warranty terms. Catalogue inclusion does not promise ready stock or a confirmed warranty.'],
  'dealer.parts_enabled'=>['نمایش قطعات و استعلام از نمایندگی','1'],
  'dealer.news_enabled'=>['نمایش اخبار سازنده، نه خبرهای شرکت شما','1'],
  'dealer.social.facebook'=>['Facebook — لینک دیمو','https://example.com/#shantay-afghanistan-facebook'],
  'dealer.social.instagram'=>['Instagram — لینک دیمو','https://example.com/#shantay-afghanistan-instagram'],
  'dealer.social.youtube'=>['YouTube — لینک دیمو','https://example.com/#shantay-afghanistan-youtube'],
  'dealer.social.telegram'=>['Telegram — لینک دیمو','https://example.com/#shantay-afghanistan-telegram'],
  'dealer.social.tiktok'=>['TikTok — لینک دیمو','https://example.com/#shantay-afghanistan-tiktok'],
  'dealer.social.linkedin'=>['LinkedIn — لینک دیمو','https://example.com/#shantay-afghanistan-linkedin'],
  'dealer.social.x'=>['X — لینک دیمو','https://example.com/#shantay-afghanistan-x'],
  'dealer.social.pinterest'=>['Pinterest — لینک دیمو','https://example.com/#shantay-afghanistan-pinterest'],
  'dealer.social.snapchat'=>['Snapchat — لینک دیمو','https://example.com/#shantay-afghanistan-snapchat'],
 ],
];
