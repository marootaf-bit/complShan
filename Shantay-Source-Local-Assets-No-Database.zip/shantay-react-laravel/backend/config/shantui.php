<?php

return [
'managed_identity_enabled'=>env('MANAGED_IDENTITY_ENABLED',false),'managed_inquiries_enabled'=>env('MANAGED_INQUIRIES_ENABLED',false),'managed_catalogue_enabled'=>env('MANAGED_CATALOGUE_ENABLED',false),'local_workspace_session'=>false,
    'managed_content_enabled' => env('MANAGED_CONTENT_ENABLED', false),
    'admin_demo_enabled' => env('ADMIN_DEMO_ENABLED', false),
    'release_content_approved' => env('RELEASE_CONTENT_APPROVED', false),
    'media_root' => env('SHANTUI_MEDIA_ROOT', storage_path('app/site-media')),
    'inquiry_email_enabled' => env('INQUIRY_EMAIL_ENABLED', false),
    'inquiry_outbox_schedule_enabled'=>env('INQUIRY_OUTBOX_SCHEDULE_ENABLED',false),
    'inquiry_email_to' => env('INQUIRY_EMAIL_TO', ''),
    'translation_preview' => env('SHANTUI_TRANSLATION_PREVIEW', false),
    // Explicit owner-authorized review on the TEST host only; never approval.
    'test_translation_preview' => env('SHANTUI_TEST_TRANSLATION_PREVIEW', false),
    'admin_email' => env('ADMIN_EMAIL', ''),
    'admin_password' => env('ADMIN_PASSWORD', ''),
];
