<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias(['admin.api' => App\Http\Middleware\AdminApiAuth::class, 'forms.validate' => App\Http\Middleware\ValidateAdminForms::class]);
        $middleware->append(App\Http\Middleware\ResolveSiteLocale::class);
        $middleware->append(App\Http\Middleware\AdminEnglish::class);
        $middleware->append(App\Http\Middleware\SiteSecurity::class);
        $middleware->trimStrings(except: ['html', 'fa_html', 'changes.*.value']);
        $middleware->validateCsrfTokens(except: ['ext/*']);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn (\Illuminate\Http\Request $request, \Throwable $e) => $request->is('api/*') || $request->expectsJson());
    })->create();
