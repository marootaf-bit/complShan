<?php
namespace App\Mail;
use Illuminate\Mail\Mailable;

class InquiryReceived extends Mailable
{
 public function __construct(public int $requestId, public array $payload) {}
 public function build(): self
 {
  return $this->subject('Shantay Afghanistan — inquiry #'.$this->requestId)->text('mail.inquiry');
 }
}
