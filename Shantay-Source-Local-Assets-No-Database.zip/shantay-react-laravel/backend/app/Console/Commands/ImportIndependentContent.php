<?php
namespace App\Console\Commands;
use App\Models\ManagedPage;
use App\Http\Controllers\SiteApiController;
use App\Support\{SiteLocale,ManagedPublishing,DisplayReview,LocalMedia};
use Illuminate\Console\Command;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
final class ImportIndependentContent extends Command {
 protected $signature='content:import-current {--limit=0}';
 protected $description='Idempotently snapshot currently available language-specific public content; no translation, fallback or source rewrites.';
 public function handle():int {
  if(!app()->environment('local','testing')){$this->error('Run this import only against an explicitly prepared local/staging database.');return 1;}
  config(['shantui.importing_content'=>true]);$added=0;$skipped=0;$missing=[];$pages=DB::table('pages')->orderBy('path');if($this->option('limit'))$pages->limit((int)$this->option('limit'));
  foreach($pages->cursor() as $source)foreach(['en','fa'] as $locale){
   if(ManagedPage::withTrashed()->where('locale',$locale)->where('path',$source->path)->exists()){$skipped++;continue;}
   app()->setLocale($locale==='fa'?'fa-AF':'en');$request=Request::create('/api/site/render','GET',['path'=>$source->path,'lang'=>$locale]);$response=app(SiteApiController::class)->render($request);
   if($response->getStatusCode()!==200||$locale==='fa'&&$response->headers->get('X-Content-Locale')!=='fa-AF'){$missing[]=['locale'=>$locale,'path'=>$source->path,'reason'=>'No currently available independent content'];continue;}
   $html=$response->getContent();preg_match('~<title[^>]*>(.*?)</title>~is',$html,$title);$name=html_entity_decode(strip_tags($title[1]??$source->title),ENT_QUOTES|ENT_HTML5,'UTF-8');
   $path=$source->path;$kind=str_contains($path,'/parts-detail-')?'part':(str_contains($path,'/pro-detail-')||str_contains($path,'/product/detail/')?'product':(str_starts_with($path,'/news/')&&str_contains($path,'detail-')?'news':($path==='/product/parts.htm'?'parts-category':(str_starts_with($path,'/product/')?'category':'page'))));
   ManagedPage::create(['locale'=>$locale,'path'=>$path,'title'=>$name,'kind'=>$kind,'base_html'=>$html,'search_text'=>ManagedPublishing::searchText($html),'source_status'=>$response->headers->get('X-Translation-Status'),'source_sha256'=>hash('sha256',$html),'status'=>'published','draft_values'=>[],'published_values'=>[]]);$added++;
  }
  if(!$this->option('limit'))foreach(DB::table('fragments')->orderBy('id')->cursor() as $f)foreach(['en','fa'] as $locale){
   $path='fragment:'.$f->id;if(ManagedPage::withTrashed()->where('locale',$locale)->where('path',$path)->exists()){$skipped++;continue;}
   $html=$f->html;$status='source';if($locale==='fa'){$l=DB::table('component_localizations')->where('component_type','fragment')->where('component_key',(string)$f->id)->where('locale','fa')->first();if(!$l||!in_array($l->status,['approved','draft','needs_review'])){$missing[]=['locale'=>$locale,'path'=>$path,'reason'=>'No independent locale record'];continue;}$html=$l->html;$status=trim($html)===''?'empty_source':$l->status;}
   $html=LocalMedia::html(DisplayReview::fragment($html,$locale==='fa'));ManagedPage::create(['locale'=>$locale,'path'=>$path,'title'=>$f->kind.' / '.$f->flag,'kind'=>'fragment','base_html'=>$html,'search_text'=>'','source_status'=>$status,'source_sha256'=>hash('sha256',$html),'status'=>'published','draft_values'=>[],'published_values'=>[]]);$added++;
  }
  config(['shantui.importing_content'=>false]);$report=['inserted'=>$added,'existingPreserved'=>$skipped,'missing'=>$missing,'counts'=>ManagedPage::select('locale','kind',DB::raw('count(*) as records'))->groupBy('locale','kind')->get()->toArray()];
  file_put_contents(base_path('../reports/INDEPENDENT-IMPORT.json'),json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));$this->line(json_encode(['inserted'=>$added,'existingPreserved'=>$skipped,'missing'=>count($missing)]));return 0;
 }
}
