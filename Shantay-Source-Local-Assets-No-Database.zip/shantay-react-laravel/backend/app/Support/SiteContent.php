<?php
namespace App\Support;

use DOMDocument;
use DOMElement;
use DOMXPath;
use Illuminate\Support\Facades\DB;

/** Structured CMS on the existing settings store: no schema/reset or source catalogue changes. */
final class SiteContent
{
 public static function defaults(string $kind,array $s): array {
  if($kind==='branches')return [['id'=>'mazar-office','name_fa'=>'دفتر مزار شریف','name_en'=>'Mazar-e-Sharif office','address_fa'=>$s['dealer.address_fa']??'افغانستان، بلخ، شهر مزار شریف','address_en'=>$s['dealer.address_en']??'Mazar-e-Sharif, Balkh, Afghanistan','phone'=>$s['dealer.phone']??'0705078335','email'=>$s['dealer.email']??'alisinarajabi08@gmail.com','whatsapp'=>$s['dealer.whatsapp']??'93705078335','latitude'=>null,'longitude'=>null,'published'=>true]];
  if($kind==='navigation')return array_map(fn($r)=>['id'=>$r[0],'path'=>$r[1],'label_fa'=>$r[2],'label_en'=>$r[3],'published'=>true],[['home','/global/home.html','خانه','Home'],['products','/product/excavator.htm','محصولات','Products'],['parts','/product/parts.htm','قطعات','Parts'],['solutions','/solution/solution.htm','راهکارها','Solutions'],['service','/service/service-support.htm','خدمات و پشتیبانی','Service'],['news','/news/news-center.htm','اخبار و رویدادها','News'],['about','/about/about-us.htm','دربارهٔ ما','About us'],['contact','/about/contact-us.htm','تماس با ما','Contact us']]);
  return [];
 }
 public static function collection(string $kind,?array $s=null): array {
  $s??=DB::table('settings')->where(fn($q)=>$q->where('key','like','dealer.%')->orWhere('key','cms.'.$kind))->pluck('value','key')->all();$value=json_decode($s['cms.'.$kind]??'null',true);
  return is_array($value)?$value:self::defaults($kind,$s);
 }
 public static function revision(array $value): string{return hash('sha256',json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
 public static function store(string $key,array $value): void {DB::table('settings')->updateOrInsert(['key'=>$key],['value'=>json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'updated_at'=>now()->toIso8601String()]);}
 public static function dom(string $html): array {
  $d=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);$d->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NOERROR|LIBXML_NOWARNING);$d->encoding='UTF-8';libxml_clear_errors();libxml_use_internal_errors($old);
  foreach(iterator_to_array($d->childNodes) as $n)if($n->nodeType===XML_PI_NODE)$d->removeChild($n);
  // Some inherited templates put their page initializer after </html>. libxml may
  // create a second root; serializing documentElement alone must not discard it.
  $root=$d->documentElement;
  if($root){
   $body=$root->getElementsByTagName('body')->item(0);
   if(!$body){$body=$d->createElement('body');$root->appendChild($body);}
   foreach(iterator_to_array($d->childNodes) as $extra){
    if($extra===$root||$extra->nodeType===XML_DOCUMENT_TYPE_NODE||$extra->nodeType===XML_PI_NODE)continue;
    if($extra instanceof DOMElement && strtolower($extra->tagName)==='html'){
     foreach(iterator_to_array($extra->childNodes) as $child){
      if($child instanceof DOMElement && in_array(strtolower($child->tagName),['body','head'],true))foreach(iterator_to_array($child->childNodes) as $nested)$body->appendChild($nested);
      else $body->appendChild($child);
     }
     $d->removeChild($extra);
    }elseif($extra instanceof DOMElement)$body->appendChild($extra);
   }
  }

  return [$d,new DOMXPath($d)];
 }
 public static function icon(string $name): string {
  $paths=['phone'=>'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 10a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2z','pin'=>'M21 10c0 7-9 12-9 12S3 17 3 10a9 9 0 1 1 18 0z M15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0','mail'=>'M3 5h18v14H3z M3 5l9 8 9-8','chat'=>'M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z'];
  return '<svg class="cms-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'.($paths[$name]??$paths['pin']).'"/></svg>';
 }
 public static function form(bool $fa,string $origin,string $branchId=''): string {
  $t=fn($a,$b)=>$fa?$a:$b;
  return '<div class="cms-message"><div><span class="cms-eyebrow">'.$t('ارتباط با نمایندگی','CONTACT THE DEALERSHIP').'</span><h2>'.$t('با ما در تماس باشید','Let’s talk').'</h2><p>'.$t('برای دریافت معلومات، نام و راه تماس خود را بنویسید. تیم نمایندگی درخواست شما را بررسی می‌کند.','Leave your contact details and message for our dealership team.').'</p></div><form class="cms-contact-form" data-origin="'.e($origin).'" novalidate>'.($branchId!==''?'<input type="hidden" name="branch_id" value="'.e($branchId).'">':'').'<div class="cms-form-grid"><label>'.$t('نام شما','Your name').'<input name="name" maxlength="120" required autocomplete="name"></label><label>'.$t('شمارهٔ تماس','Telephone').'<input name="phone" dir="ltr" maxlength="25" autocomplete="tel"></label><label>'.$t('ایمیل','Email').'<input name="email" type="email" dir="ltr" maxlength="180" autocomplete="email"></label><label>'.$t('موضوع','Subject').'<input name="subject" maxlength="160"></label></div><label>'.$t('پیام شما','Your message').'<textarea name="message" rows="5" maxlength="5000" required></textarea></label><label class="cms-honeypot" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label><p class="cms-form-help">'.$t('حداقل تلفن یا ایمیل معتبر لازم است. معلومات حساس ارسال نکنید.','A valid telephone or email is required. Do not send sensitive information.').'</p><label class="cms-consent"><input type="checkbox" name="consent" required> '.$t('با استفاده از معلومات تماس برای پاسخ به این درخواست موافقم.','I agree to the use of my contact information to respond to this request.').' <a href="/site/Privacy.htm?lang='.($fa?'fa':'en').'">'.$t('حریم خصوصی','Privacy').'</a></label><button type="submit" class="cms-primary">'.$t('ارسال پیام','Send message').'</button><p class="cms-form-status" role="status" aria-live="polite"></p></form></div>';
 }
 public static function contacts(array $s,bool $fa): string {
  $l=$fa?'fa':'en';$t=fn($a,$b)=>$fa?$a:$b;$branches=array_values(array_filter(self::collection('branches',$s),fn($b)=>$b['published']??false));
  $html='<div class="cms-contact-intro"><span class="cms-eyebrow">'.$t('نمایندگی رسمی شانتای در افغانستان','OFFICIAL SHANTUI DEALERSHIP IN AFGHANISTAN').'</span><h1>'.$t('تماس با ما و دفترهای نمایندگی','Contact our dealership offices').'</h1><p>'.$t('دفتر مورد نظر را انتخاب کنید؛ معلومات تماس و نقشهٔ همان دفتر نمایش داده می‌شود.','Select an office to view its contact details and map.').'</p></div><div class="cms-branches">';
  foreach($branches as $i=>$b){
   $exact=isset($b['latitude'],$b['longitude']);$query=$exact?$b['latitude'].','.$b['longitude']:($b['address_en']?:$b['address_fa']);$map='https://maps.google.com/maps?'.http_build_query(['q'=>$query,'output'=>'embed']);$directions='https://www.google.com/maps/search/?'.http_build_query(['api'=>1,'query'=>$query]);
   $phone=preg_replace('/[^+0-9]/','',$b['phone']??'');if(str_starts_with($phone,'0'))$phone='+93'.substr($phone,1);
   $html.='<article class="cms-branch" data-branch="'.e($b['id']).'"'.($i?' hidden':'').'><div class="cms-branch-details"><span class="cms-eyebrow">'.$t('دفتر نمایندگی','DEALERSHIP OFFICE').'</span><h2>'.e($b['name_'.$l]?:$b['name_fa']).'</h2><div class="cms-contact-line">'.self::icon('pin').'<div><strong>'.$t('نشانی','Address').'</strong><p>'.e($b['address_'.$l]?:$b['address_fa']).'</p></div></div>';
   foreach([['phone',$t('تلفن','Telephone'),'tel:'.$phone,$b['phone']??''],['mail',$t('ایمیل','Email'),'mailto:'.($b['email']??''),$b['email']??''],['chat',$t('واتساپ','WhatsApp'),'https://wa.me/'.preg_replace('/\D/','',$b['whatsapp']??''),$b['whatsapp']??'']] as [$ico,$label,$href,$value])if($value!=='')$html.='<div class="cms-contact-line">'.self::icon($ico).'<div><strong>'.$label.'</strong><a dir="ltr" href="'.e($href).'">'.e($value).'</a></div></div>';
   $html.='<p class="cms-hours">'.e($s['dealer.hours_'.$l]??$t('پیش از مراجعه، ساعات کاری را تلفنی هماهنگ کنید.','Telephone the office to confirm opening hours before visiting.')).'</p><a class="cms-map-link" href="'.e($directions).'" target="_blank" rel="noopener noreferrer">'.$t('بازکردن در Google Maps','Open in Google Maps').'</a></div><div class="cms-map"><iframe data-owned-map="1" src="'.e($map).'" title="'.e($t('نقشهٔ ','Map: ').($b['name_'.$l]?:$b['name_fa'])).'" loading="lazy" referrerpolicy="no-referrer" allowfullscreen></iframe><p>'.($exact?$t('موقعیت ثبت‌شده توسط مدیر نمایندگی','Location supplied by dealership administrator'):$t('نقشهٔ محدودهٔ نشانی است؛ محل دقیق دفتر هنوز ثبت نشده. پیش از مراجعه تلفنی هماهنگ کنید.','This shows the address area, not a verified office pin. Call before visiting.')).' '.$t('نقشه توسط Google ارائه می‌شود.','Map provided by Google.').'</p></div></article>';
  }
  $html.='</div>';
  if(count($branches)>1){$opts='';foreach($branches as $b)$opts.='<option value="'.e($b['id']).'">'.e($b['name_'.$l]?:$b['name_fa']).'</option>';$html='<label class="cms-branch-picker">'.$t('انتخاب دفتر / شعبه','Choose an office').'<select id="cmsBranchPicker">'.$opts.'</select></label>'.$html;}
  if(!$branches)$html.='<p class="cms-empty">'.$t('دفتر فعالی برای نمایش ثبت نشده است.','No offices are currently published.').'</p>';
  return '<div class="cms-contact-page">'.$html.self::form($fa,'/about/contact-us.htm',$branches[0]['id']??'').'</div>';
 }
 public static function news(array $s,bool $fa): string {
  $l=$fa?'fa':'en';$t=fn($a,$b)=>$fa?$a:$b;$items=array_values(array_filter(self::collection('news',$s),fn($n)=>($n['published']??false)&&($n['date']??'')<=now('Asia/Kabul')->toDateString()));
  $h='<div class="cms-news-controls" role="group" aria-label="'.$t('منبع خبر','News source').'"><button class="is-active" data-news-filter="all">'.$t('همهٔ خبرها','All news').'</button><button data-news-filter="local">'.$t('خبرهای نمایندگی افغانستان','Afghanistan dealership').'</button><button data-news-filter="manufacturer">'.$t('خبرهای شرکت سازنده','Manufacturer').'</button></div><div class="cms-owned-news"><h2>'.$t('خبرها و رویدادهای نمایندگی افغانستان','Afghanistan dealership news and events').'</h2><div class="cms-news-grid">';
  foreach($items as $n){$title=$n['title_'.$l]?:$n['title_fa'];$body=$n['body_'.$l]?:$n['body_fa'];$summary=$n['summary_'.$l]?:$n['summary_fa'];$h.='<article class="cms-news-card" id="local-news-'.e($n['id']).'">';if($n['image']??'')$h.='<img loading="lazy" src="'.e($n['image']).'" alt="'.e($title).'">';$h.='<div class="cms-news-card-body"><span class="cms-news-source">'.$t('خبر نمایندگی افغانستان','Afghanistan dealership news').'</span><time datetime="'.e($n['date']).'">'.e($n['date']).'</time><h3>'.e($title).'</h3><p>'.nl2br(e($summary)).'</p><details><summary>'.$t('ادامهٔ خبر','Read story').'</summary><div class="cms-news-body">'.nl2br(e($body)).'</div></details></div></article>';}
  if(!$items)$h.='<p class="cms-empty">'.$t('هنوز خبری از نمایندگی منتشر نشده است. خبرها و رویدادهای تازهٔ نمایندگی در این بخش قرار می‌گیرند.','No dealership news has been published yet.').'</p>';
  return $h.'</div></div>';
 }
 public static function apply(string $html,string $path,array $s,bool $fa): string {
  [$d,$x]=self::dom($html);$class=fn($c)=>"contains(concat(' ',normalize-space(@class),' '),' $c ')";
  $insert=function(DOMElement $target,string $markup,bool $prepend=false)use($d){[$temp,$tx]=self::dom('<html><body><div id="cms-import">'.$markup.'</div></body></html>');$wrapper=$tx->query('//*[@id="cms-import"]')->item(0);$nodes=iterator_to_array($wrapper->childNodes);if($prepend)$nodes=array_reverse($nodes);foreach($nodes as $node){$new=$d->importNode($node,true);if($prepend)$target->insertBefore($new,$target->firstChild);else $target->appendChild($new);}};
  // Dedicated contact layout replaces only the existing main content; header/footer/routes stay intact.
  if($path==='/about/contact-us.htm'){$main=$x->query('//section['.$class('channel_content').']')->item(0);if($main){while($main->firstChild)$main->removeChild($main->firstChild);$insert($main,self::contacts($s,$fa));}}
  if($path==='/about/about-us.htm'){$main=$x->query('//section['.$class('channel_content').']')->item(0);if($main)$insert($main,'<div class="cms-about-contact">'.self::form($fa,$path).'</div>');}
  if(in_array($path,['/news/news-center.htm','/news/shantui-news.htm'],true)){
   $main=$x->query('//section['.$class('channel_content').']')->item(0);
   if($main){foreach(iterator_to_array($main->childNodes) as $child)if($child instanceof DOMElement)$child->setAttribute('data-cms-manufacturer','1');$insert($main,'<div class="wrap cms-news-shell">'.self::news($s,$fa).'</div>',true);}
   foreach($x->query('//title') as $n)$n->textContent=($fa?'اخبار و رویدادها | ':'News and events | ').($s['dealer.name_'.($fa?'fa':'en')]??'Shantay Afghanistan');
  }
  if($path==='/global/home.html'){
   foreach($x->query('//*['.$class('ipart05').']//*['.$class('title').']') as $title)$title->textContent=$fa?'اخبار و رویدادها':'News and events';
   $published=array_filter(self::collection('news',$s),fn($n)=>($n['published']??false)&&($n['date']??'')<=now('Asia/Kabul')->toDateString());
   if($published){$host=$x->query('//*['.$class('ipart05').']/*['.$class('wrap').']')->item(0);if($host){$copy=$s;$copy['cms.news']=json_encode(array_slice(array_values($published),0,3));$news=self::news($copy,$fa);$news=preg_replace('~<div class="cms-news-controls".*?</div>~s','',$news);$insert($host,$news,true);}}
  }
  foreach($x->query('//a[@href="/news/news-center.htm"]') as $a){foreach($x->query('.//text()[normalize-space(.)!="" and not(ancestor::*[contains(@class,"iconfont")])]',$a) as $n){$n->textContent=$fa?'اخبار و رویدادها':'News and events';break;}}
  foreach($x->query('//li['.$class('mnav_li').']') as $li){if($x->query('.//a[@href="/news/news-center.htm"]',$li)->length){$root=$x->query('./div['.$class('li_box').']/a',$li)->item(0);if($root)$root->textContent=$fa?'اخبار و رویدادها':'News and events';}}
  // Label/visibility/order of existing top-level menus; submenu markup is preserved.
  if(isset($s['cms.navigation'])){
   $nav=self::collection('navigation',$s);$byPath=[];foreach($nav as $n)$byPath[$n['path']]=$n;
   foreach($x->query('//*['.$class('inav').']/ul | //*['.$class('mnav_bott').']/ul') as $ul){$original=[];$all=[];foreach(iterator_to_array($ul->childNodes) as $li)if($li instanceof DOMElement){$a=$x->query('./a[@href] | ./div['.$class('li_box').']/a[@href]',$li)->item(0);if($a){$key=$a->getAttribute('href');if(str_starts_with($key,'javascript:'))$key=$x->query('.//div['.$class('m_secNav').']//a[starts-with(@href,"/")]',$li)->item(0)?->getAttribute('href')??$key;$original[$key]=[$li,$a];$all[]=$li;}}
    foreach($all as $li)$ul->removeChild($li);
    foreach($nav as $n){if(!($n['published']??false))continue;if(isset($original[$n['path']]))[$li,$a]=$original[$n['path']];else{$li=$d->createElement('li');$li->setAttribute('class',str_contains($ul->parentNode->getAttribute('class'),'mnav')?'mnav_li':'nav_li');$a=$d->createElement('a');$a->setAttribute('class','inav_a');$a->setAttribute('href',$n['path']);if(str_contains($ul->parentNode->getAttribute('class'),'mnav')){$box=$d->createElement('div');$box->setAttribute('class','li_box');$box->appendChild($a);$li->appendChild($box);}else $li->appendChild($a);} $a->textContent=$n[$fa?'label_fa':'label_en']?:$n['label_fa'];$ul->appendChild($li);}
   }
  }
  $head=$x->query('//head')->item(0);if($head){$css=$d->createElement('link');$css->setAttribute('rel','stylesheet');$css->setAttribute('href','/global/site-content.css');$head->appendChild($css);}
  $body=$x->query('//body')->item(0);if($body){$validation=$d->createElement('script');$validation->setAttribute('src','/global/form-validation.js');$body->insertBefore($validation,$body->firstChild);$js=$d->createElement('script');$js->setAttribute('src','/global/site-content.js');$body->appendChild($js);}
  if($fa)DisplayReview::decorate($d,new DOMXPath($d));
  CompactFooter::decorate($d,new DOMXPath($d),$s,$fa,self::collection('navigation',$s));
  return '<!doctype html>'."\n".$d->saveHTML($d->documentElement);
 }
 public static function overrideKey(string $path,string $locale): string{return 'cms.page.'.hash('sha256',$path.'|'.$locale);}
 public static function overrides(string $path,string $locale): array {return json_decode(DB::table('settings')->where('key',self::overrideKey($path,$locale))->value('value')??'[]',true)?:[];}
 public static function applyOverrides(string $html,string $path,string $locale): string {
  $edits=self::overrides($path,$locale);if(!$edits)return $html;[$d,$x]=self::dom($html);
  foreach($edits as $e){$node=$x->query($e['xpath'])->item(0);if(!$node)continue;if($e['kind']==='text'&&$node->nodeType===XML_TEXT_NODE)$node->nodeValue=$e['value'];elseif($node instanceof DOMElement){if($e['kind']==='visible'){if($e['value']==='0'){$node->setAttribute('hidden','hidden');$node->setAttribute('style',$node->getAttribute('style').';display:none!important');}}elseif($e['kind']==='description')$node->setAttribute('content',$e['value']);
    elseif($e['kind']==='background')$node->setAttribute('style',$node->getAttribute('style').';background-image:url("'.$e['value'].'")!important');
    elseif(in_array($e['kind'],['src','href','alt','title','placeholder','poster'],true)){$node->setAttribute($e['kind'],$e['value']);if($e['kind']==='src'&&strtolower($node->tagName)==='img'){$node->removeAttribute('srcset');foreach(['data-src','data-smalsrc','data-original'] as $attr)if($node->hasAttribute($attr))$node->setAttribute($attr,$e['value']);}}}}
  foreach($edits as $e){if($e['kind']==='description')foreach($x->query('//meta[@property="og:description"]') as $meta)$meta->setAttribute('content',$e['value']);if($e['kind']==='text'&&str_contains($e['xpath'],'/head/title'))foreach($x->query('//meta[@property="og:title"]') as $meta)$meta->setAttribute('content',$x->query('//title')->item(0)?->textContent??'');}
  return '<!doctype html>'."\n".$d->saveHTML($d->documentElement);
 }
 public static function nodes(string $html): array {
  [$d,$x]=self::dom($html);$rows=[];
  foreach($x->query('//body//text()[normalize-space(.)!="" and not(ancestor::script) and not(ancestor::style) and not(ancestor::noscript)] | //title/text()') as $n){$p=$n->parentNode;if($p instanceof DOMElement && str_contains($p->getAttribute('class'),'iconfont'))continue;$value=trim($n->textContent);if(mb_strlen($value)<2)continue;$rows[]=['xpath'=>$n->getNodePath(),'kind'=>'text','value'=>$n->textContent,'label'=>mb_substr($value,0,90)];}
  foreach($x->query('//body//*[@src or @href or @alt or @title or @placeholder or @poster]') as $n){if(in_array(strtolower($n->tagName),['script','link','iframe'],true))continue;foreach(['src','href','alt','title','placeholder','poster'] as $attr)if($n->hasAttribute($attr))$rows[]=['xpath'=>$n->getNodePath(),'kind'=>$attr,'value'=>$n->getAttribute($attr),'tag'=>strtolower($n->tagName),'label'=>$n->tagName.' · '.$attr.' · '.mb_substr($n->getAttribute($attr),0,70)];}
  foreach($x->query('//meta[@name="description"]') as $n)$rows[]=['xpath'=>$n->getNodePath(),'kind'=>'description','value'=>$n->getAttribute('content'),'label'=>'SEO description'];
  foreach($x->query('//body//*[@style]') as $n)if(preg_match('~background-image\s*:\s*url\(["\']?([^"\')]+)~i',$n->getAttribute('style'),$match))$rows[]=['xpath'=>$n->getNodePath(),'kind'=>'background','value'=>$match[1],'label'=>'Background image: '.mb_substr($match[1],0,70)];
  foreach($x->query('//section[contains(@class,"channel_content")]/*[self::div or self::section] | //div[contains(@class,"cms-message") or contains(@class,"cms-owned-news") or contains(@class,"cms-contact-intro") or contains(@class,"cms-branches")]') as $n)$rows[]=['xpath'=>$n->getNodePath(),'kind'=>'visible','value'=>$n->hasAttribute('hidden')?'0':'1','label'=>'نمایش بخش: '.$n->getAttribute('class')];
  return array_slice($rows,0,2500);
 }
}
