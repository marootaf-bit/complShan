<?php

namespace App\Support;

use Illuminate\Http\Request;

final class SiteLocale
{
    public const DARI = 'fa-AF';
    public const ENGLISH = 'en';

    public static function normalize(?string $value): ?string
    {
        $locale = strtolower(str_replace('_', '-', trim((string) $value)));
        if ($locale === 'en' || str_starts_with($locale, 'en-')) return self::ENGLISH;
        if ($locale === 'fa' || str_starts_with($locale, 'fa-') || $locale === 'prs' || str_starts_with($locale, 'prs-')) return self::DARI;
        return null;
    }

    public static function resolve(Request $request): string
    {
        foreach ([$request->query('lang'), $request->cookie('shantui_lang')] as $candidate) {
            $normalized = self::normalize(is_string($candidate) ? $candidate : null);
            if ($normalized !== null) return $normalized;
        }

        // Explicit choices win; an English browser alone does not override this Dari-first site.
        return self::DARI;
    }

    public static function storageCode(string $locale): string
    {
        return self::normalize($locale) === self::DARI ? 'fa' : 'en';
    }

    public static function direction(string $locale): string
    {
        return self::normalize($locale) === self::DARI ? 'rtl' : 'ltr';
    }
}
