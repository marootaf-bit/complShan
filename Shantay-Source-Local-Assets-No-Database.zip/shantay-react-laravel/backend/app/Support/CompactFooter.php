<?php
namespace App\Support;

use DOMDocument;
use DOMElement;
use DOMXPath;

/** Compact, settings-driven footer and locally embedded brand icons. No data writes. */
final class CompactFooter
{
    public const NETWORKS = ['facebook'=>'Facebook','instagram'=>'Instagram','youtube'=>'YouTube','telegram'=>'Telegram','tiktok'=>'TikTok','linkedin'=>'LinkedIn','x'=>'X','pinterest'=>'Pinterest','snapchat'=>'Snapchat','whatsapp'=>'WhatsApp'];

    public static function network(string $url): ?string
    {
        if (strtolower((string) parse_url($url, PHP_URL_SCHEME)) !== 'https') return null;
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $domains = ['facebook'=>['facebook.com','fb.com','fb.me'],'instagram'=>['instagram.com'],'youtube'=>['youtube.com','youtu.be'],'telegram'=>['t.me','telegram.me'],'tiktok'=>['tiktok.com'],'linkedin'=>['linkedin.com'],'x'=>['x.com','twitter.com'],'pinterest'=>['pinterest.com','pin.it'],'snapchat'=>['snapchat.com'],'whatsapp'=>['wa.me','whatsapp.com']];
        foreach ($domains as $network=>$hosts) foreach ($hosts as $domain) if ($host === $domain || str_ends_with($host, '.'.$domain)) return $network;
        return null;
    }

    public static function icon(DOMDocument $doc, string $network, string $class='cf-brand-icon'): ?DOMElement
    {
        static $icons;
        $icons ??= json_decode(file_get_contents(dirname(__DIR__,2).'/resources/social-icons.json'), true);
        if (!isset($icons[$network])) return null;
        $svg = $doc->createElementNS('http://www.w3.org/2000/svg','svg');
        foreach (['viewBox'=>$icons[$network]['viewBox'],'class'=>$class,'width'=>'20','height'=>'20','fill'=>'currentColor','aria-hidden'=>'true','focusable'=>'false'] as $key=>$value) $svg->setAttribute($key,$value);
        foreach ($icons[$network]['paths'] as $data) { $path=$doc->createElementNS('http://www.w3.org/2000/svg','path'); $path->setAttribute('d',$data); $svg->appendChild($path); }
        return $svg;
    }

    public static function decorate(DOMDocument $doc, DOMXPath $xpath, array $settings, bool $fa, array $navigation): void
    {
        if (!$xpath->query('//body[@data-dealership="true"]')->length) return;
        $defaults = function_exists('config') ? config('dealership.fields', []) : [];
        $get = fn(string $key): string => (string) ($settings['dealer.'.$key] ?? $defaults['dealer.'.$key][1] ?? '');
        $lang = $fa ? 'fa' : 'en';
        $label = fn($a,$b) => $fa ? $a : $b;
        $route = fn($path) => $path.'?lang='.$lang;
        $make = function(string $tag,string $class='',?string $text=null) use($doc): DOMElement {
            $node=$doc->createElement($tag); if($class!=='')$node->setAttribute('class',$class); if($text!==null)$node->appendChild($doc->createTextNode($text)); return $node;
        };
        $link = function(string $href,string $text,string $class='') use($make): DOMElement {
            $a=$make('a',$class,$text);$a->setAttribute('href',$href);return $a;
        };
        // Five inherited news documents omit a footer entirely. Give them the
        // same footer without changing their article or page initializer.
        if (!$xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," footer ")]')->length) {
            $footer=$make('footer','footer pageFooter');
            $body=$xpath->query('//body')->item(0);
            $dock=$xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," m_footer ")]')->item(0);
            if($dock && $dock->parentNode===$body)$body->insertBefore($footer,$dock);else $body->appendChild($footer);
        }
        foreach (iterator_to_array($xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," footer ")]')) as $footer) {
            if ($footer->getAttribute('data-compact-footer') === 'true') continue;
            // Retain any inherited page initializer rather than deleting it with the old sitemap.
            $scripts=$doc->createDocumentFragment();
            foreach(iterator_to_array($xpath->query('.//script | .//noscript',$footer)) as $script)$scripts->appendChild($script);
            while($footer->firstChild)$footer->removeChild($footer->firstChild);
            $footer->setAttribute('class',trim($footer->getAttribute('class').' cf-footer'));
            $footer->setAttribute('data-compact-footer','true');$footer->setAttribute('role','contentinfo');
            $shell=$make('div','cf-shell');$main=$make('div','cf-main');
            $brand=$make('div','cf-brand');$identity=$make('div','cf-identity');
            $logo=$get('logo');
            if (preg_match('~^(?:/(?!/)|https://)~i',$logo)) {
                $home=$link($route('/global/home.html'),'','cf-logo');$home->setAttribute('aria-label',$get('name_'.$lang));
                $img=$make('img');$img->setAttribute('src',$logo);$img->setAttribute('alt',$get('name_'.$lang));$img->setAttribute('width','138');$img->setAttribute('height','32');$img->setAttribute('loading','lazy');$home->appendChild($img);$identity->appendChild($home);
            } else $identity->appendChild($make('strong','cf-name',$get('name_'.$lang)));
            $brand->appendChild($identity);
            $socials=$make('div','cf-socials');$socials->setAttribute('aria-label',$label('شبکه‌های اجتماعی','Social networks'));
            foreach(self::NETWORKS as $network=>$name) {
                $digits=preg_replace('/\D/','',$get('whatsapp'));
                $url=$network==='whatsapp' ? (strlen($digits)>=7?'https://wa.me/'.$digits:'') : $get('social.'.$network);
                if (self::network($url)!==$network) continue;
                $a=$link($url,$name,'dealer-social');$a->setAttribute('aria-label',$name);$a->setAttribute('title',$name);$a->setAttribute('target','_blank');$a->setAttribute('rel','noopener noreferrer');$socials->appendChild($a);
            }
            if($socials->hasChildNodes())$brand->appendChild($socials);
            $main->appendChild($brand);
            $nav=$make('nav','cf-nav');$nav->setAttribute('aria-label',$label('دسترسی سریع در پایین صفحه','Footer navigation'));
            foreach($navigation as $item) {
                $path=(string)($item['path']??'');if(!($item['published']??false)||!str_starts_with($path,'/')||str_starts_with($path,'//')||Dealership::unavailable($path,$settings))continue;
                $text=(string)(($item['label_'.$lang]??'')?:($item['label_fa']??''));
                if($text!=='')$nav->appendChild($link($route($path),$text));
            }
            if($nav->hasChildNodes())$main->appendChild($nav);
            $contact=$make('div','cf-contact');
            $phone=$get('phone');$digits=preg_replace('/\D/','',$phone);$tel=str_starts_with($digits,'0')?'+93'.substr($digits,1):'+'.$digits;
            if($digits!==''){$a=$link('tel:'.$tel,$phone,'cf-phone');$a->setAttribute('dir','ltr');$a->setAttribute('aria-label',$label('تماس تلفنی: ','Telephone: ').$phone);$contact->appendChild($a);}
            $email=$get('email');if(filter_var($email,FILTER_VALIDATE_EMAIL)){$a=$link('mailto:'.$email,$email,'cf-email');$a->setAttribute('dir','ltr');$contact->appendChild($a);}
            $address=$get('address_'.$lang);if($address!=='')$contact->appendChild($link($route('/about/contact-us.htm'),$address,'cf-address'));
            $main->appendChild($contact);$shell->appendChild($main);
            $bottom=$make('div','cf-bottom');$bottom->appendChild($make('small','cf-copyright','© '.date('Y').' '.$get('name_'.$lang)));
            $legal=$make('div','cf-legal');foreach([['/site/Privacy.htm',$label('حریم خصوصی','Privacy')],['/site/sitemap.htm',$label('نقشهٔ سایت','Sitemap')],['/site/search.htm',$label('جستجو','Search')]] as [$path,$text])$legal->appendChild($link($route($path),$text));
            $bottom->appendChild($legal);$shell->appendChild($bottom);$footer->appendChild($shell);if($scripts->hasChildNodes())$footer->appendChild($scripts);
        }
        // Existing links retain destinations, visible CTA copy and behaviour.
        foreach(iterator_to_array($xpath->query('//a[@href]')) as $a) {
            $network=self::network($a->getAttribute('href'));if(!$network||$a->hasAttribute('data-social-icon'))continue;
            $name=self::NETWORKS[$network];$a->setAttribute('data-social-icon',$network);
            if(!$a->hasAttribute('aria-label'))$a->setAttribute('aria-label',trim($a->textContent)?:$name);
            if(!$a->hasAttribute('title'))$a->setAttribute('title',$name);
            $classes=' '.$a->getAttribute('class').' ';
            if(str_contains($classes,' dealer-social ')) {
                while($a->firstChild)$a->removeChild($a->firstChild);
                $a->appendChild(self::icon($doc,$network));$a->appendChild($make('span','cf-sr-only',$name));
                continue;
            }
            $host=$a->parentNode;
            while($host instanceof DOMElement && !str_contains(' '.$host->getAttribute('class').' ',' cms-contact-line '))$host=$host->parentNode;
            if($host instanceof DOMElement) {
                $old=$xpath->query('./*[local-name()="svg"]',$host)->item(0);
                if($old){$old->parentNode->replaceChild(self::icon($doc,$network,'cms-icon cf-brand-icon'),$old);continue;}
            }
            $box=$xpath->query('.//*[contains(concat(" ",normalize-space(@class)," ")," icon ")]',$a)->item(0);
            if($box){while($box->firstChild)$box->removeChild($box->firstChild);$box->appendChild(self::icon($doc,$network));}
            else {$a->insertBefore(self::icon($doc,$network,'cf-inline-icon'),$a->firstChild);$a->setAttribute('class',trim($a->getAttribute('class').' cf-social-action'));}
        }
        $head=$xpath->query('//head')->item(0);
        if($head&&!$xpath->query('//link[contains(@href,"/global/footer-compact.css")]')->length){$css=$make('link');$css->setAttribute('rel','stylesheet');$css->setAttribute('href','/global/footer-compact.css?v=20261103-footer1');$head->appendChild($css);}
    }
}
