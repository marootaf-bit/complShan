<?php
namespace App\Support;

final class PageRuntime
{
    /** Some imported canonical pages omitted their shared initializer entirely.
     * Restore only a missing initializer; never replace authored content or DB.
     */
    public static function ensure(string $html, string $path): string
    {
        if (!str_contains($html, '/resources/modules/seajs/sea.js') || preg_match('~seajs\s*\.\s*use\s*\([\"\']js/~', $html)) return $html;
        $module = str_starts_with($path, '/product/') && !str_contains($path, 'detail') && $path !== '/product/parts.htm'
            ? 'js/pro_list' : 'js/common';
        $script = '<script>seajs.use("'.$module.'");</script>';
        return preg_replace('~</body>~i', $script.'</body>', $html, 1) ?? $html;
    }
}
