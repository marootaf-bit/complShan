<?php
namespace App\Support;

use DOMDocument;
use DOMElement;
use DOMXPath;

/** Render-time, settings-driven adaptation. The original pages/catalogue are not rewritten. */
final class Dealership
{
    public static function enabled(array $s): bool { return ($s['dealer.enabled'] ?? '0') === '1'; }
    public static function removed(string $path): bool { return str_starts_with($path, '/case/') || in_array($path, ['/about/talent-recruitment.htm','/about/social-responsibility.htm','/service/overseas-branches.htm']); }
    public static function unavailable(string $path, array $s): bool
    {
        if (self::removed($path)) return true;
        if (!self::enabled($s)) return false;
        if (($s['dealer.parts_enabled'] ?? '0') !== '1' && preg_match('~/(?:spare-parts|parts-support|parts)(?:[/.]|-|$)~i', $path)) return true;
        if (($s['dealer.news_enabled'] ?? '0') !== '1' && str_starts_with($path, '/news/')) return true;
        if ($path === '/service/overseas-branches.htm') return true;
        if (($s['dealer.manufacturer_enabled'] ?? '1') !== '1' && in_array($path, ['/about/group.htm','/about/business-strength.htm','/about/history.htm','/about/video_center.htm'])) return true;
        return in_array($path, ['/about/social-responsibility.htm','/about/talent-recruitment.htm']);
    }
    public static function apply(string $html, string $path, array $s, bool $fa): string
    {
        if (!self::enabled($s)) return $html;
        $defaults = config('dealership.fields', []);
        $get = fn(string $k): string => (string)($s['dealer.'.$k] ?? $defaults['dealer.'.$k][1] ?? '');
        $lang = $fa ? 'fa' : 'en';
        $name = $get('name_'.$lang);
        $identity=$fa?'نمایندگی رسمی شانتای در افغانستان':'Official Shantui dealership in Afghanistan';
        $contact = '/about/contact-us.htm';
        $phone = $get('phone');
        $digits = preg_replace('/\D/', '', $phone);
        $tel = str_starts_with($digits, '0') ? '+93'.substr($digits, 1) : '+'.$digits;
        $wa = 'https://wa.me/'.preg_replace('/\D/', '', $get('whatsapp'));
        $email = $get('email');
        $map = 'https://www.google.com/maps/search/?api=1&query='.rawurlencode($get('address_'.$lang));
        $d = new DOMDocument('1.0','UTF-8');
        $old = libxml_use_internal_errors(true);
        $d->loadHTML('<?xml encoding="UTF-8">'.$html, LIBXML_NOERROR|LIBXML_NOWARNING);
        libxml_clear_errors();libxml_use_internal_errors($old);
        foreach (iterator_to_array($d->childNodes) as $n) if ($n->nodeType === XML_PI_NODE) $d->removeChild($n);
        $x = new DOMXPath($d);
        $c = fn(string $class): string => "contains(concat(' ',normalize-space(@class),' '),' ".$class." ')";
        $all = fn(string $query): array => iterator_to_array($x->query($query));
        $text = function(string $query, string $value) use ($all): void { foreach ($all($query) as $n) $n->textContent = $value; };
        $remove = function(string $query) use ($all): void { foreach ($all($query) as $n) $n->parentNode?->removeChild($n); };
        $href = function(string $query, string $url) use ($all): void { foreach ($all($query) as $n) $n->setAttribute('href',$url); };
        $safe = fn(string $url): bool => (bool)preg_match('~^(?:/(?!/)|https://)~i', $url);

        // Remove obsolete country/distribution widgets, not product families or catalogue records.
        $remove('//*['.$c('location_choose').' or '.$c('h_lan').' or '.$c('lnb').']');
        $remove('//*['.$c('footer').']//*['.$c('company').']');
        foreach ($all('//a[@href]') as $a) {
            $url = $a->getAttribute('href');$p = parse_url($url,PHP_URL_PATH) ?: '';
            if (self::unavailable($p,$s) && !str_contains($p,'overseas-branches')) {
                $parent=$a->parentNode;
                if ($parent instanceof DOMElement && in_array(strtolower($parent->tagName),['li','dd','dt'])) $parent->parentNode?->removeChild($parent);
                else $a->parentNode?->removeChild($a);
                continue;
            }
            if (str_contains($p,'overseas-branches') || str_contains($p,'distributor')) {
                $a->setAttribute('href',$contact);
                foreach (iterator_to_array($x->query('.//*['.$c('t').' or '.$c('txt').']',$a)) as $t) $t->textContent=$fa?'تماس با نمایندگی':'Contact our office';
                $labelNodes=$x->query('.//text()[normalize-space(.)!="" and not(ancestor::*['.$c('iconfont').'])]',$a);
                if($labelNodes->length)$labelNodes->item(0)->textContent=$fa?'تماس با نمایندگی':'Contact our office';
            }
        }
        if ($get('parts_enabled') !== '1') {
            foreach($all('//a[normalize-space(.)="Spare Parts" or normalize-space(.)="قطعات یدکی" or normalize-space(.)="پرزه‌جات"]') as $a){
                $target=$a;
                for($p=$a->parentNode;$p instanceof DOMElement;$p=$p->parentNode){$classes=' '.$p->getAttribute('class').' ';if(str_contains($classes,' swiper-slide ')){$target=$p;break;}if($p->tagName==='li'){$target=$p;break;}}
                $target->parentNode?->removeChild($target);
            }
        }
        $remove('//a[contains(@href,"?distributor") or contains(@href,"&distributor")]');
        // Corporate-only tracking IDs must not collect visits on a dealership preview/site.
        foreach ($all('//script|//noscript') as $script) {
            // The original footer combines CNZZ tracking and page initialization in ONE script.
            // Strip only the tracking IIFE; removing the whole script breaks AJAX lists and menus.
            if(!$script->getAttribute('src') && str_contains($script->textContent,'cnzz.com')){
                $clean=preg_replace('~var\s+_czc\s*=\s*_czc\s*\|\|\s*\[\];\s*\(function\s*\(\)\s*\{.*?cnzz\.com.*?\}\)\(\);~s','',$script->textContent);
                $script->textContent=$clean;
            }
            $source=$script->getAttribute('src').' '.$script->textContent;
            if (preg_match('~googletagmanager|google-analytics|cnzz\.com|GTM-WM976TMM|analytics\.icm\.com\.cn|maps\.googleapis\.com~i',$source)) $script->parentNode?->removeChild($script);
        }
        foreach ($all('//*['.$c('h_logo').' or '.$c('f_logo').']//img') as $img) {
            if ($safe($get('logo'))) $img->setAttribute('src',$get('logo'));
            $img->setAttribute('alt',$name);$img->removeAttribute('srcset');
        }
        foreach ($all('//*['.$c('h_logo').']/a') as $a) {
            $a->setAttribute('href','/global/home.html');$a->setAttribute('title',$name);
            $span=$d->createElement('span');$span->setAttribute('class','dealer-brand-name');$span->textContent=$name;$a->appendChild($span);
        }
        $text('//*['.$c('footer').']//*['.$c('b_center').']','© '.date('Y').' '.$name);
        $remove('//*['.$c('footer').']//*['.$c('b_right').']');
        $text('//*['.$c('footer').']//*['.$c('r_top').']//*['.$c('t').']',$get('address_'.$lang));
        $text('//*['.$c('header').']//a[contains(@href,"about-us")]',$fa?'دربارهٔ ما':'About us');
        $text('//*['.$c('footer').']//a[contains(@href,"about-us")]',$fa?'دربارهٔ ما':'About us');
        // Remove unsupported parts and recruitment inquiry tabs together with their corresponding forms.
        if ($get('parts_enabled') !== '1') {
            $remove('//*['.$c('checkbox').']//*[@data-name="part"]');
            $remove('//*['.$c('inquiry2').']//*['.$c('form2').']');
        }
        $remove('//*['.$c('checkbox').']//*[@data-name="distributor"]');
        $remove('//*['.$c('inquiry2').']//*['.$c('form3').']');
        // Global email/tel links are never presented as local contact channels.
        foreach ($all('//a[starts-with(@href,"tel:")]') as $a) {$a->setAttribute('href','tel:'.$tel);$a->textContent=$phone;$a->setAttribute('dir','ltr');}
        foreach ($all('//a[starts-with(@href,"mailto:")]') as $a) {$a->setAttribute('href','mailto:'.$email);$a->textContent=$email;$a->setAttribute('dir','ltr');}
        foreach ($all('//*['.$c('share_box').']') as $box) {
            while($box->firstChild)$box->removeChild($box->firstChild);
            $networks=['facebook'=>'Facebook','instagram'=>'Instagram','youtube'=>'YouTube','telegram'=>'Telegram','tiktok'=>'TikTok','linkedin'=>'LinkedIn','x'=>'X','pinterest'=>'Pinterest','snapchat'=>'Snapchat','whatsapp'=>'WhatsApp'];
            foreach($networks as $key=>$label){$url=$key==='whatsapp'?$wa:$get('social.'.$key);if(!$safe($url) || str_contains($url,'example.com'))continue;
                $a=$d->createElement('a');$a->setAttribute('href',$url);$a->setAttribute('target','_blank');$a->setAttribute('rel','noopener noreferrer');$a->setAttribute('class','dealer-social');$a->setAttribute('aria-label',$label);$a->textContent=$label;
                $demo=str_contains($url,'example.com');$a->setAttribute('title',$label.($demo?($fa?' — لینک نمونه؛ قابل‌ویرایش از داشبورد':' — demo link; edit in dashboard'):''));if($demo)$a->setAttribute('data-demo-link','true');$box->appendChild($a);
            }
        }
        if ($path==='/global/home.html') {
            $text('//*['.$c('ipart04').']//*['.$c('title').'][not('.$c('num_box').')]',$fa?'دربارهٔ '.$name:'About '.$name);
            $text('//*['.$c('ipart04').']//*['.$c('con').']',$get('intro_'.$lang).' '.$get('image_note_'.$lang));
            foreach($all('//*['.$c('ipart04').']//*['.$c('big_num').']') as $stats){while($stats->firstChild)$stats->removeChild($stats->firstChild);$stats->setAttribute('hidden','hidden');$stats->setAttribute('aria-hidden','true');}
            if ($get('news_enabled')!=='1') foreach($all('//*['.$c('ipart05').']') as $news){while($news->firstChild)$news->removeChild($news->firstChild);$news->setAttribute('data-dealer-disabled','true');}
            else $text('//*['.$c('ipart05').']//*['.$c('title').']',$fa?'اخبار و رویدادهای سازنده':'Manufacturer news and events');
            $text('//*['.$c('ipart03').']//*['.$c('title').']',$fa?'نمونه‌های کاربرد محصولات سازنده':'Manufacturer application references');
            foreach ($all('//*['.$c('ibanner').']//*['.$c('cover').']') as $cover) {
                $words=iterator_to_array($x->query('.//*['.$c('words').']',$cover));
                if(isset($words[0]))$words[0]->textContent=$name;
                if(isset($words[1]))$words[1]->textContent=$get('tagline_'.$lang);
            }
            $text('//*['.$c('ipart02').']//*['.$c('title').']',$get('tagline_'.$lang));
            $text('//*['.$c('ipart02').']//*['.$c('left').']//*['.$c('con').']',$get('intro_'.$lang).' '.$get('image_note_'.$lang));
            $benefits=$fa?['تمام محصولات شانتای','استعلام مستقیم قیمت','ارتباط از طریق واتساپ','دفتر نمایندگی در مزار شریف','معلومات و مشخصات مدل‌ها','ثبت و پیگیری درخواست']:['Complete Shantui range','Direct quotations','WhatsApp contact','Mazar-e-Sharif office','Model information','Inquiry follow-up'];
            foreach($all('//*['.$c('ipart02').']//*['.$c('right').']//li//div['.$c('t').']') as $k=>$n) if(isset($benefits[$k])) $n->textContent=$benefits[$k];
        }
        // Improve existing conversion controls only; no new public sections.
        if($path==='/global/home.html'){
            foreach($all('//*['.$c('ibanner').']//*['.$c('cover').']//*['.$c('wrap').']') as $wrap){
                foreach(iterator_to_array($x->query('.//a['.$c('more_btn').']',$wrap)) as $button){
                    $button->setAttribute('href','/product/excavator.htm');$button->setAttribute('class','dealer-hero-action');
                    $button->textContent=$fa?'مشاهدهٔ محصولات':'Explore products';
                    $chat=$d->createElement('a');$chat->setAttribute('href',$wa.'?text='.rawurlencode($fa?'سلام، برای معلومات محصولات شانتای و دریافت قیمت با دفتر مزار شریف تماس می‌گیرم.':'Hello, I would like product information and a quotation from your Mazar-e-Sharif office.'));
                    $chat->setAttribute('class','dealer-hero-action dealer-hero-chat');$chat->setAttribute('target','_blank');$chat->setAttribute('rel','noopener noreferrer');$chat->textContent=$fa?'استعلام قیمت از واتساپ':'Request a quote on WhatsApp';$wrap->appendChild($chat);
                }
            }
        }
        if(str_starts_with($path,'/product/')){
            $model=trim($x->query('//*['.$c('pro_detail01').']//*['.$c('model').']')->item(0)?->textContent??'');
            if($model!==''){
                $message=$fa?'سلام، دربارهٔ مدل «'.$model.'» معلومات و قیمت می‌خواهم. نوع پروژهٔ من: ':'Hello, I would like information and a quotation for model '.$model.'. My project: ';
                foreach($all('//*['.$c('pro_detail01').' or '.$c('pro_detail02').']//*['.$c('btns_box').']//a') as $button){
                    if(str_contains($button->getAttribute('href'),'section5')){$nodes=$x->query('.//*['.$c('c').']',$button);foreach($nodes as $n)$n->textContent=$fa?'درخواست قیمت این مدل':'Request a quote for this model';}
                    elseif($button->getAttribute('href')===$contact){$button->setAttribute('href',$wa.'?text='.rawurlencode($message));$button->setAttribute('target','_blank');$button->setAttribute('rel','noopener noreferrer');foreach($x->query('.//*['.$c('c').']',$button) as $n)$n->textContent=$fa?'واتساپ دربارهٔ این مدل':'WhatsApp about this model';}
                }
                // Preserve the catalogue and all technical values; clarify supply in the existing lead text slot.
                $lead=$x->query('//*['.$c('pro_detail01').']//*['.$c('left').']/*['.$c('t').']')->item(0);
                if($lead){$lead->textContent.=$fa?' — قیمت و شرایط عرضه را از دفتر استعلام کنید.':' — Contact our office to confirm price and supply terms.';}
            }
        }
        if ($path==='/about/about-us.htm') {
            $text('//*['.$c('xc_banner').']//*['.$c('tit').']',$fa?'دربارهٔ نمایندگی':'About the dealership');
            $text('//*['.$c('xc_banner').']//a[@href="javascript:;"]',$fa?'معرفی نمایندگی افغانستان':'Afghanistan dealership');
            $items=$all('//*['.$c('about_us01').']//*['.$c('intro_box').']');
            $labels=$fa?[$name,'تمام محصولات شانتای','راه ارتباط و درخواست قیمت','تاریخچهٔ شرکت — متن نمونه']:['Shantay Afghanistan','The complete product range','Contact and quotations','Company history — sample'];
            $keys=['intro','products','process','manufacturer_note'];
            $labels[3]=$fa?'دربارهٔ شرکت سازنده':'About the manufacturer';
            foreach($items as $i=>$item){if(!isset($keys[$i]))continue;foreach(iterator_to_array($x->query('.//*['.$c('tit').']',$item)) as $n)$n->textContent=$labels[$i];foreach(iterator_to_array($x->query('.//*['.$c('con').']',$item)) as $n)$n->textContent=$get($keys[$i].'_'.$lang).($i===0?' '.$get('image_note_'.$lang):'');}
            foreach($all('//*['.$c('about_us01').']//img') as $img)$img->setAttribute('alt',$fa?'تصویر مرجع شرکت سازنده؛ نه دفتر نمایندگی':'Manufacturer reference image, not a dealership facility');
            $remove('//*['.$c('about_us02').']//a[contains(@href,"recruit")]');
        }
        if ($path==='/service/service-support.htm') {
            $text('//*['.$c('service01').']//*['.$c('infor').']//*['.$c('tit').']',$fa?'معلومات محصولات و ارتباط با نمایندگی':'Product information and dealership contact');
            $text('//*['.$c('service01').']//*['.$c('infor').']//*['.$c('con').']',$get('services_'.$lang));
            foreach($all('//*['.$c('service01').']//*['.$c('content').'] | //*['.$c('service02').']') as $section){while($section->firstChild)$section->removeChild($section->firstChild);$section->setAttribute('data-dealer-disabled','true');}
            // Worldwide 24/7, 180-country and 24/72-hour promises are manufacturer services, not verified local offers.
            foreach($all('//*['.$c('service03').' or '.$c('service04').']') as $section)$section->setAttribute('data-dealer-disabled','true');
            $text('//*['.$c('service05').']//*['.$c('tit').']',$fa?'با دفتر نمایندگی در مزار شریف تماس بگیرید':'Contact our Mazar-e-Sharif office');
        }
        if ($path==='/about/contact-us.htm') {
            $text('//*['.$c('new_contact_us01').']//*['.$c('left').']//*['.$c('title').']',$fa?'آدرس نمایندگی':'Dealership address');
            $text('//*['.$c('new_contact_us01').']//*['.$c('top').']/*['.$c('t').']',$get('address_'.$lang));
            foreach($all('//*['.$c('new_contact_us01').']//a['.$c('addr').']') as $a){$a->setAttribute('href',$map);$a->setAttribute('target','_blank');$a->setAttribute('rel','noopener');$a->setAttribute('class','dealer-map-link');$a->textContent=$fa?'دیدن موقعیت در سطح شهر':'View city location';}
            $text('//*['.$c('new_contact_us01').']//*['.$c('item01').']//*['.$c('w').']',$fa?'تماس مستقیم':'Telephone');
            $text('//*['.$c('new_contact_us01').']//*['.$c('item02').']//*['.$c('w').']','WhatsApp');
            $text('//*['.$c('new_contact_us01').']//*['.$c('item02').']//a',$phone);$href('//*['.$c('new_contact_us01').']//*['.$c('item02').']//a',$wa);
            $text('//*['.$c('new_contact_us01').']//*['.$c('right').']//*['.$c('title').']',$fa?'ارتباط با '.$name:'Contact '.$name);
            $lis=$all('//*['.$c('new_contact_us01').']//*['.$c('bott_box').']//li');foreach(array_slice($lis,1) as $n)$n->parentNode?->removeChild($n);
            if(isset($lis[0])){$texts=iterator_to_array($x->query('./div',$lis[0]));$vals=[$name,$get('hours_'.$lang),$phone,$email];foreach($texts as $k=>$n)if(isset($vals[$k])){$n->textContent=$vals[$k];if($k===2||$k===3){$n->textContent='';$a=$d->createElement('a');$a->setAttribute('href',$k===2?'tel:'.$tel:'mailto:'.$email);$a->textContent=$vals[$k];$a->setAttribute('dir','ltr');$n->appendChild($a);}}}
            $remove('//*['.$c('tc3').' or '.$c('tc_bg3').']');
        }
        if($get('parts_enabled')==='1' && in_array($path,['/product/parts.htm','/service/parts-support.htm'])){
            $page=$fa?'قطعات شانتای و استعلام از نمایندگی':'Shantui parts and dealership inquiries';
            $text('//*['.$c('xc_banner').']//*['.$c('tit').']',$page);
            if($path==='/product/parts.htm'){
                $text('//*['.$c('pjsm01').']',$fa?'استعلام قطعات شانتای':'Shantui parts inquiries');
                $text('//*['.$c('pjsm02').']',$get('parts_intro_'.$lang).' '.$phone.' — '.$email);
                foreach($all('//*['.$c('pjsm02').']') as $node){$a=$d->createElement('a');$a->setAttribute('href',$wa.'?text='.rawurlencode($fa?'سلام، برای قطعات ماشین شانتای معلومات و قیمت می‌خواهم.':'Hello, I need information and pricing for Shantui parts.'));$a->setAttribute('target','_blank');$a->setAttribute('rel','noopener noreferrer');$a->textContent=$fa?' — استعلام قطعات در واتساپ':' — Ask about parts on WhatsApp';$node->appendChild($a);}
            }else{
                $labels=$fa?['استعلام قطعات شانتای','معلومات موردنیاز برای شناسایی قطعه','شرایط عرضه و هماهنگی با دفتر']:['Shantui parts inquiries','Information needed to identify a part','Supply terms and office coordination'];
                $keys=['parts_intro','parts_identification','parts_terms'];
                foreach($all('//*['.$c('parts1').']//li['.$c('li_').']') as $i=>$row){if(!isset($keys[$i]))continue;foreach($x->query('.//*['.$c('tit').']',$row) as $n)$n->textContent=$labels[$i];foreach($x->query('.//*['.$c('con').']',$row) as $n)$n->textContent=$get($keys[$i].'_'.$lang).' '.$get('image_note_'.$lang);}
                foreach($all('//*['.$c('parts2').']') as $section)$section->setAttribute('data-dealer-disabled','true');
            }
        }
        if($get('parts_enabled')==='1' && str_starts_with($path,'/product/parts-detail-')){
            $text('//*['.$c('pjsm01').']',$fa?'استعلام این قطعه از شانتای افغانستان':'Ask Shantay Afghanistan about this part');
            $text('//*['.$c('pjsm02').']',$get('parts_terms_'.$lang).' '.$phone.' — '.$email);
            foreach($all('//*['.$c('pjsm02').']') as $node){$a=$d->createElement('a');$a->setAttribute('href',$wa);$a->setAttribute('target','_blank');$a->setAttribute('rel','noopener noreferrer');$a->textContent=$fa?' — استعلام در واتساپ':' — Ask on WhatsApp';$node->appendChild($a);}
            foreach($all('//*['.$c('parts_detail01').']//*['.$c('words').']/*['.$c('tit').']') as $node){$note=$d->createElement('p');$note->setAttribute('class','dealer-source-note');$note->textContent=$fa?'مشخصات زیر از کاتالوگ سازنده‌اند؛ قیمت، سازگاری، موجودی و ضمانت باید جداگانه با نمایندگی تأیید شوند.':'Specifications below are manufacturer catalogue references; price, compatibility, stock and warranty require separate confirmation with the dealership.';$node->insertBefore($note,$node->firstChild);}
        }
        if ($path==='/site/Privacy.htm') {
            $ps=$all('//section['.$c('channel_content').']//p');
            $policy=preg_split('/\n\s*\n/',str_replace(['{{company}}','{{email}}'],[$name,$email],$get('privacy_'.$lang)));
            foreach($ps as $k=>$p){if(isset($policy[$k]))$p->textContent=$policy[$k];else $p->parentNode?->removeChild($p);}
        }
        foreach($all('//*['.$c('xc_banner').']//a[contains(@href,"about-us")]') as $a)$a->textContent=$fa?'دربارهٔ ما':'About us';
        // Existing title/breadcrumb slots identify this company, never the Chinese parent as the dealer.
        if(in_array($path,['/about/about-us.htm','/about/contact-us.htm','/service/service-support.htm'])){
            $page=match($path){'/about/contact-us.htm'=>$fa?'تماس با ما':'Contact us','/about/history.htm'=>$fa?'تاریخچهٔ ما':'Our history','/service/service-support.htm'=>$fa?'خدمات و پشتیبانی':'Services and support',default=>$fa?'دربارهٔ ما':'About us'};
            $text('//*['.$c('xc_banner').']//*['.$c('title').' or '.$c('tit').']',$page);
        }
        // Restore manufacturer resources inside the existing navigation/template, with explicit provenance.
        $resourceLabels = $fa ? [
            '/about/group.htm'=>'معرفی گروه سازنده', '/about/business-strength.htm'=>'توانمندی‌های سازنده',
            '/about/history.htm'=>'تاریخچهٔ شرکت سازنده', '/about/video_center.htm'=>'ویدیوهای سازنده',
            '/news/news-center.htm'=>'اخبار سازنده', '/news/shantui-news.htm'=>'اخبار شرکت سازنده',
            '/news/brand-activities.htm'=>'رویدادهای سازنده',
        ] : [
            '/about/group.htm'=>'Manufacturer group', '/about/business-strength.htm'=>'Manufacturer capabilities',
            '/about/history.htm'=>'Manufacturer history', '/about/video_center.htm'=>'Manufacturer videos',
            '/news/news-center.htm'=>'Manufacturer news', '/news/shantui-news.htm'=>'Shantui manufacturer news',
            '/news/brand-activities.htm'=>'Manufacturer events',
        ];
        foreach($resourceLabels as $target=>$label) foreach($all('//a[@href="'.$target.'"]') as $a){
            $nodes=$x->query('.//text()[normalize-space(.)!="" and not(ancestor::*['.$c('iconfont').'])]',$a);
            if($nodes->length) $nodes->item(0)->textContent=$label;
            $a->setAttribute('title',$label);
        }
        foreach($all('//*['.$c('mnav_li').']') as $item){
            $root=$x->query('./div['.$c('li_box').']/a',$item)->item(0);
            if(!$root)continue;
            if($x->query('.//a[@href="/about/about-us.htm"]',$item)->length)$root->textContent=$fa?'دربارهٔ ما':'About us';
            if($x->query('.//a[@href="/news/news-center.htm"]',$item)->length)$root->textContent=$fa?'اخبار سازنده':'Manufacturer news';
        }
        // Contact uses the existing desktop/mobile menu containers; keep the submenu shortcut too.
        foreach($all('//*['.$c('inav').']/ul | //*['.$c('mnav_bott').']/ul') as $menu){
            if($x->query('./li/a[@href="'.$contact.'"] | ./li/div['.$c('li_box').']/a[@href="'.$contact.'"]',$menu)->length)continue;
            $mobile=$menu->parentNode instanceof DOMElement && str_contains($menu->parentNode->getAttribute('class'),'mnav_bott');
            $li=$d->createElement('li');$li->setAttribute('class',$mobile?'mnav_li dealer-contact-nav':'nav_li dealer-contact-nav');
            $a=$d->createElement('a');$a->setAttribute('href',$contact);$a->textContent=$fa?'تماس با ما':'Contact us';
            if($mobile){$box=$d->createElement('div');$box->setAttribute('class','li_box');$box->appendChild($a);$li->appendChild($box);}
            else{$a->setAttribute('class','inav_a');$li->appendChild($a);}
            $menu->appendChild($li);
        }
        $isManufacturer = isset($resourceLabels[$path]) || str_starts_with($path,'/news/') || str_starts_with($path,'/case/');
        if($isManufacturer){
            if(isset($resourceLabels[$path])){
                $page=$resourceLabels[$path];
                $text('//*['.$c('xc_banner').']//*['.$c('tit').']',$page);
            }
            // A short attribution INSIDE the existing content, not an additional public section.
            $host=$x->query('//section['.$c('channel_content').']//div['.$c('wrap').']')->item(0);
            if($host){$note=$d->createElement('p');$note->setAttribute('class','dealer-source-note');$note->textContent=$get('manufacturer_note_'.$lang);$host->insertBefore($note,$host->firstChild);}
        }
        foreach($all('//link[@rel="canonical"]') as $canonical)$canonical->setAttribute('href',$path);
        foreach($all('//meta[@property="og:site_name"]') as $meta)$meta->setAttribute('content',$name.' — '.$identity);
        foreach($all('//meta[@property="og:url"]') as $meta)$meta->setAttribute('content',$path);
        foreach($all('//title') as $title){$source=trim($title->textContent);$source=preg_replace('~[-|]\s*(?:Shantui Construction Machinery|شرکت ماشین‌آلات ساختمانی شانتویی).*~iu','',$source);if(isset($page))$source=$page;if($path==='/service/inquiry.htm')$source=$fa?'درخواست قیمت و تماس':'Quotations and contact';$title->textContent=in_array($path,['/global/home.html','/about/about-us.htm'])?$name.' | '.$identity:$source.' | '.$name.' — '.$identity;}
        foreach($all('//meta[@name="description"]') as $meta)if(in_array($path,['/global/home.html','/about/about-us.htm']))$meta->setAttribute('content',$get('intro_'.$lang).' '.$get('image_note_'.$lang));
        foreach($all('//meta[@property="og:title"]') as $meta)$meta->setAttribute('content',$x->query('//title')->item(0)?->textContent??$name);
        // Explicit Home and Parts links in every existing navigation surface.
        foreach($all('//*['.$c('inav').']/ul | //*['.$c('mnav_bott').']/ul') as $menu){
            $mobile=$menu->parentNode instanceof DOMElement && str_contains($menu->parentNode->getAttribute('class'),'mnav_bott');
            foreach(['/global/home.html'=>($fa?'خانه':'Home'),'/product/parts.htm'=>($fa?'قطعات':'Parts')] as $url=>$label){
                if($url==='/product/parts.htm' && $get('parts_enabled')!=='1')continue;
                if($x->query('./li/a[@href="'.$url.'"] | ./li/div['.$c('li_box').']/a[@href="'.$url.'"]',$menu)->length)continue;
                $li=$d->createElement('li');$li->setAttribute('class',($mobile?'mnav_li':'nav_li').' dealer-direct-nav');
                $a=$d->createElement('a');$a->setAttribute('href',$url);$a->textContent=$label;
                if($mobile){$box=$d->createElement('div');$box->setAttribute('class','li_box');$box->appendChild($a);$li->appendChild($box);}
                else{$a->setAttribute('class','inav_a');$li->appendChild($a);}
                if($url==='/global/home.html')$menu->insertBefore($li,$menu->firstChild);
                else{$product=$x->query('./li['.$c($mobile?'m_pro_down':'pro_nav').']',$menu)->item(0);$menu->insertBefore($li,$product?->nextSibling);}
            }
        }
        foreach($all('//*['.$c('m_footer').']//ul') as $menu){
            foreach($all('//*['.$c('m_footer').']//a[@href="/" or @href="/global/home.html"]') as $a){$a->setAttribute('href','/global/home.html');foreach($x->query('.//*['.$c('txt').']',$a) as $label)$label->textContent=$fa?'خانه':'Home';}
            if($get('parts_enabled')==='1' && !$x->query('./li/a[@href="/product/parts.htm"]',$menu)->length){
                $li=$d->createElement('li');$li->setAttribute('class','li dealer-parts-tab');$a=$d->createElement('a');$a->setAttribute('href','/product/parts.htm');
                $icon=$d->createElement('div');$icon->setAttribute('class','icon dealer-parts-icon');$icon->setAttribute('aria-hidden','true');$icon->textContent='⚙';$a->appendChild($icon);
                $label=$d->createElement('div');$label->setAttribute('class','txt');$label->textContent=$fa?'قطعات':'Parts';$a->appendChild($label);$li->appendChild($a);
                $product=$x->query('./li/a[@href="/product/excavator.htm"]',$menu)->item(0)?->parentNode;$menu->insertBefore($li,$product?->nextSibling);
            }
            $menu->setAttribute('style','--dealer-tab-count:'.$x->query('./li/a',$menu)->length);
            foreach($x->query('./li/a',$menu) as $a){
                $url=$a->getAttribute('href');$active=$path===$url || ($url==='/global/home.html' && $path==='/') || ($url==='/product/excavator.htm' && str_starts_with($path,'/product/') && $path!=='/product/parts.htm') || ($url==='/solution/solution.htm' && str_starts_with($path,'/solution/')) || ($url==='/service/service-support.htm' && str_starts_with($path,'/service/'));
                $li=$a->parentNode;$classes=trim(preg_replace('/\bcur\b/','',$li->getAttribute('class')));$li->setAttribute('class',$classes.($active?' cur':''));if($active)$a->setAttribute('aria-current','page');else $a->removeAttribute('aria-current');
            }
        }
        // All inquiry forms submit to our own backend, not the manufacturer's legacy JSP.
        foreach($all('//form[contains(@action,"/core/control/")]') as $form){
            $originalAction=$form->getAttribute('action');
            foreach(FormValidation::contract()['legacyActions'] as $suffix=>$kind)if(str_ends_with($originalAction,$suffix)){$form->setAttribute('data-validation-kind',$kind);break;}
            $form->setAttribute('action','/api/requests');$form->setAttribute('method','post');$form->setAttribute('data-local-inquiry','true');
            foreach(iterator_to_array($x->query('.//*['.$c('item_yzm').' or '.$c('inp_yzm').']',$form)) as $captcha)$captcha->parentNode?->removeChild($captcha);
            foreach(iterator_to_array($x->query('.//input[@name="rand"] | .//img[contains(@src,"authCodeServlet")]',$form)) as $captcha)$captcha->parentNode?->removeChild($captcha);
            foreach(iterator_to_array($x->query('.//*['.$c('infor').']/*['.$c('tip').']',$form)) as $marketing)$marketing->parentNode?->removeChild($marketing);
            foreach($x->query('.//*['.$c('infor').']/*['.$c('tit').']',$form) as $label)$label->textContent=$fa?'ثبت درخواست در همین سایت':'Submit your inquiry to this website';
        }
        // Locale-specific artwork: original English images and source records are untouched.
        if ($fa) {
            $artFile=base_path('../public/global/dealer/fa-artwork/routes.json');
            $art=is_file($artFile)?json_decode(file_get_contents($artFile),true):[];
            $swap=function($img,$url) {
                $img->setAttribute('src',$url);
                $mobile=str_replace('.jpg','-mobile.jpg',$url);
                $img->setAttribute('srcset',$mobile.' 768w, '.$url.' 1920w');
                $img->setAttribute('sizes','100vw');
                foreach(['data-src','data-smalsrc','data-original'] as $attr)$img->removeAttribute($attr);
                $img->setAttribute('data-fa-artwork','true');
            };
            if(isset($art[$path])) foreach($all('//*['.$c('xc_banner').']/img[1]') as $img)$swap($img,$art[$path]);
            if($path==='/global/home.html' && isset($art['_home'])) {
                foreach($all('//*['.$c('ibanner').']//*['.$c('img').']/video') as $video) {
                    $img=$d->createElement('img');$img->setAttribute('alt','تصویر مرجع ماشین‌آلات سازنده');$swap($img,$art['_home']);$video->parentNode->replaceChild($img,$video);
                }
                foreach($all('//*['.$c('ibanner').']//img['.$c('iban_img').']') as $img)$swap($img,$art['_home']);
                foreach($all('//*['.$c('ipart04').']/*['.$c('bg').']/img') as $img)$swap($img,$art['_about']);
            }
            if($path==='/about/business-strength.htm' && isset($art['_strength'])) {
                foreach($all('//*['.$c('strength04').']//video') as $video)$video->parentNode->removeChild($video);
                foreach($all('//*['.$c('strength04').']//img['.$c('bg_img').']') as $img)$swap($img,$art['_strength']);
            }
        }
        foreach($all('//body') as $body)$body->setAttribute('data-dealership','true');
        return $d->saveHTML();
    }
}
