<?php
namespace App\Support;
use Illuminate\Support\Facades\DB;

final class ReleaseCheck
{
 public static function run(): array
 {
  $checks=[];
  $checks['owner_content_approval']=(bool)config('shantui.release_content_approved',false);
  $checks['production_environment']=app()->environment('production');
  $checks['production_admin_demo_off']=!config('shantui.admin_demo_enabled',false);
  $checks['debug_off']=!config('app.debug');
  $checks['https_url']=str_starts_with(config('app.url'),'https://') && !str_contains(config('app.url'),'.invalid');
  $checks['application_key_configured']=\App\Http\Middleware\AdminApiAuth::keyConfigured();
  $checks['admin_credentials_configured']=filter_var(config('shantui.admin_email'),FILTER_VALIDATE_EMAIL)!==false && strlen((string)config('shantui.admin_password'))>=14 && config('shantui.admin_password')!=='ChangeThis-2026!';
  $checks['database_integrity']=DB::selectOne('PRAGMA integrity_check')->integrity_check==='ok';
  $checks['secure_session_cookie']=(bool)config('session.secure');
  $pending=DB::table('component_localizations')->where('locale','fa')->where('status','!=','approved')->count();
  $checks['human_translation_approval_complete']=$pending===0;
  $uiPending=0;$csv=base_path('../reports/i18n-fixed-copy-review-2026-11-01.csv');
  if(is_file($csv)){$f=fopen($csv,'r');$header=fgetcsv($f,0,',','"','\\');$index=array_search('review_status',$header,true);while(($row=fgetcsv($f,0,',','"','\\'))!==false)if(($row[$index]??'')!=='approved')$uiPending++;fclose($f);}else $uiPending=-1;
  $checks['ui_catalogue_review_complete']=$uiPending===0;
  $checks['translation_preview_off']=!config('shantui.translation_preview') && !config('shantui.test_translation_preview');
  $inventoryFile=base_path('../reports/SELF-HOSTED-INVENTORY.json');$manifestFile=base_path('../data/self-hosted-media.json');
  $inventory=is_file($inventoryFile)?json_decode(file_get_contents($inventoryFile),true):[];
  $manifest=is_file($manifestFile)?json_decode(file_get_contents($manifestFile),true):[];$missing=[];
  foreach($inventory['paths']??[] as $path){
   if(is_file(base_path('../public').$path))continue;
   $entry=$manifest[$path]??null;
   if(!$entry || !is_file(rtrim(config('shantui.media_root'),'/').'/'.$entry['file']))$missing[]=$path;
  }
  $externalPlayers=array_values(array_filter($inventory['external']??[],fn($u)=>str_contains($u,'youtube.com') || str_contains($u,'v.qq.com')));
  $checks['local_video_replacements_supplied']=count($externalPlayers)===0;
  $checks['all_inventory_assets_installed']=!empty($inventory['paths']) && count($missing)===0;
  $checks['email_transport_configured']=config('shantui.inquiry_email_enabled') && filter_var(config('shantui.inquiry_email_to'),FILTER_VALIDATE_EMAIL) && !in_array(config('mail.default'),['array','log']);
  $checks['no_runtime_origin_proxy']=!str_contains(file_get_contents(base_path('../vite.config.js')),'fetch(');
  return ['ready'=>!in_array(false,$checks,true),'checks'=>$checks,'pendingUiReviewRows'=>$uiPending,'externalPlayerSourcesWithoutLocalFile'=>count($externalPlayers),'pendingTranslationComponents'=>$pending,'missingMediaCount'=>count($missing),'missingMediaSample'=>array_slice($missing,0,15),'notVerifiedAutomatically'=>['Human review of legal text and manufacturer-media usage permission','Real-host TLS, file permissions and SMTP delivery','Domain/DNS and durable-media installation']];
 }
}
