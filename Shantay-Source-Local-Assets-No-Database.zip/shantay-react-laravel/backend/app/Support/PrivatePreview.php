<?php
namespace App\Support;
final class PrivatePreview{
 public static function html(string $html):string{$guard=<<<'JS'
<meta http-equiv="Content-Security-Policy" content="form-action 'none'; object-src 'none'; base-uri 'self'"><script>(()=>{document.addEventListener('submit',e=>{e.preventDefault();e.stopImmediatePropagation();},true);HTMLFormElement.prototype.submit=function(){throw Error('Submissions are disabled in private preview')};HTMLFormElement.prototype.requestSubmit=function(){throw Error('Submissions are disabled in private preview')};const reads=new Set(['/ext/ajax.jsp','/ext/ajax_proList.jsp','/ext/ajax_partsList.jsp','/ext/ajax_news.jsp','/ext/ajax_index.jsp','/ext/ajax_video.jsp','/ext/ajax_solution.jsp']);const allowed=(m,u)=>['GET','HEAD','OPTIONS'].includes(String(m).toUpperCase())||reads.has(new URL(u,location.href).pathname);const f=window.fetch.bind(window);window.fetch=(i,o={})=>allowed(o.method||(i instanceof Request?i.method:'GET'),typeof i==='string'?i:i.url)?f(i,o):Promise.reject(Error('Submissions are disabled in private preview'));const open=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u,...rest){if(!allowed(m,u))throw Error('Submissions are disabled in private preview');return open.call(this,m,u,...rest)};if(navigator.sendBeacon)navigator.sendBeacon=()=>false;})();</script>
JS;
 return preg_replace('~<head\b[^>]*>~i','$0'.$guard,$html,1);}
}
