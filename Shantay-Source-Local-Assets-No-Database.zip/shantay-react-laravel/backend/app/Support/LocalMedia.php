<?php
namespace App\Support;

final class LocalMedia
{
    public static function response(string $path)
    {
        if (str_contains($path, "\0") || preg_match('~(^|/)\.\.?(?:/|$)~', $path)) abort(404);
        $manifestFile=config('shantui.media_manifest',base_path('../data/self-hosted-media.json'));
        $manifest=is_file($manifestFile)?json_decode(file_get_contents($manifestFile),true):[];
        $entry=$manifest['/'.ltrim($path,'/')]??null;
        if (!$entry || !isset($entry['file'])) abort(404);
        $root=realpath((string)config('shantui.media_root'));
        $file=$root?realpath($root.DIRECTORY_SEPARATOR.$entry['file']):false;
        if (!$file || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)) abort(404);
        return response()->file($file,['Content-Type'=>$entry['mime'],'Cache-Control'=>'public, max-age=86400','X-Content-Type-Options'=>'nosniff']);
    }

    public static function html(string $html): string
    {
        // Later-imported parts pages omitted the shared locale/responsive shell.
        // Restore missing assets only on whole documents, before CMS/mobile styles;
        // never inject document-level resources into AJAX fragments or alter data.
        if (preg_match('~<head\b~i', $html) && stripos($html, '</head>') !== false) {
            $shell = '';
            if (!str_contains($html, '/global/local-global-shell.css')) $shell .= '<link rel="stylesheet" href="/global/local-global-shell.css">';
            if (!str_contains($html, '/global/local-global-shell.js')) $shell .= '<script defer src="/global/local-global-shell.js"></script>';
            if ($shell !== '') {
                $html = preg_replace('~(?=<link\b[^>]*href=["\']/global/(?:site-content|footer-compact)\.css)~i', $shell, $html, 1, $inserted);
                if (!$inserted) $html = preg_replace('~</head>~i', $shell.'</head>', $html, 1);
            }
        }
        // Progressive enhancement: the stylesheet is doubly scoped to mobile.
        // The script performs no DOM changes on desktop and restores on resize.
        if (stripos($html, '</head>') !== false && !str_contains($html, '/global/mobile-premium.css')) {
            $mobile = '<link rel="stylesheet" href="/global/mobile-premium.css?v=20261103-type2" media="(max-width:780px)">'
                .'<script defer src="/global/mobile-premium.js?v=20261103-type1"></script>';
            $html = preg_replace('~</head>~i', $mobile.'</head>', $html, 1);
        }
        // Version only our own shell assets; leave raw DB/source hashes untouched.
        $html = preg_replace('~((?:src|href)=["\'])(/global/local-global-shell\.(?:js|css))(["\'])~i', '$1$2?v=20261103-type1$3', $html);
        // Revalidate the three repaired component styles, not third-party URLs.
        $html = preg_replace('~(href=["\'])(/resources/(?:ui/ui|web/css/(?:style|responsive))\.css)(["\'])~i', '$1$2?v=20261103-type1$3', $html);
        $html = preg_replace('~(href=["\'])(/global/site-content\.css)(["\'])~i', '$1$2?v=20261103-type1$3', $html);
        // Version the module loader config too; legacy module-localStorage is disabled
        // there so fixes are not hidden by indefinitely cached module bodies.
        $html = preg_replace('~((?:src)=["\'])(/resources/web/seajs\.config\.js)(["\'])~i', '$1$2?v=20261103-type1$3', $html);
        // Preserve inline JS exactly except known external player URL prefixes.
        // Attribute regexes MUST NOT run inside JS strings that build HTML.
        $html=preg_replace('~(?:https?:)?//(?:www\.)?shantui-global\.com(/(?:upload|resources)/)~i','$1',$html);
        $html=str_replace(['https://www.youtube.com/embed/','https://v.qq.com/txp/iframe/player.html?vid='],['/global/local-video-unavailable.html?unused=','/global/local-video-unavailable.html?unused='],$html);
        $parts=preg_split('~(<script\b[^>]*>.*?</script>)~is',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
        foreach($parts as &$part){
            if(preg_match('~^<script\b~i',$part)){
                if(preg_match('~^<script\b[^>]*\bsrc=["\'](?:https?:)?//~i',$part))$part='';
                continue;
            }
            $part=preg_replace_callback('~<iframe\b[^>]*\bsrc=["\'](?:https?:)?//[^"\']*["\'][^>]*>.*?</iframe>~is',function($m){
                // Explicit owner-approved exception: Google Maps only, never external videos.
                if(preg_match('~\bdata-owned-map=["\']1["\']~',$m[0]) && preg_match('~\bsrc=["\']https://maps\.google\.com/maps\?[^"\']*["\']~',$m[0]))return $m[0];
                return '<div class="local-video-unavailable" role="status">ویدیوی محلی این بخش هنوز بارگذاری نشده است. / Local video is not yet available.</div>';
            },$part);
            $part=preg_replace('~(data-v|data-video)=["\'](?:https?:)?//[^"\']+["\']~i','$1="/global/local-video-unavailable.html"',$part);
            // The source incorrectly included an icon PNG as a stylesheet.
            $part=preg_replace('~<link\b(?=[^>]*rel=["\']stylesheet["\'])(?=[^>]*href=["\'][^"\']+\.(?:png|jpe?g|gif)["\'])[^>]*>~i','',$part);
        }
        unset($part);
        return implode('',$parts);
    }
}
