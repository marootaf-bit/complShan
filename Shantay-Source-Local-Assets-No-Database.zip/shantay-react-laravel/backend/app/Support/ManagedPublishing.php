<?php
namespace App\Support;
use App\Models\ManagedPage;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class ManagedPublishing {
 public static function page(int $id,string $locale): ManagedPage{return ManagedPage::where('locale',$locale)->findOrFail($id);}
 public static function html(ManagedPage $page,bool $draft=false): string {return NativeFieldMap::render($page->base_html,$draft?$page->draft_values:$page->published_values);}
 public static function fields(ManagedPage $page): array {
  return array_values(array_map(function($f)use($page){$f['value']=$page->draft_values[$f['id']]??$f['value'];unset($f['start'],$f['length'],$f['attribute']);return $f;},NativeFieldMap::fields($page->base_html)));
 }
 public static function searchText(string $html):string{return implode(' ',array_column(array_filter(NativeFieldMap::fields($html),fn($f)=>$f['type']==='text'),'value'));}
 public static function audit(ManagedPage $page,string $action,array $metadata=[]):void {
  DB::table('managed_audit')->insert(['page_id'=>$page->id,'locale'=>$page->locale,'action'=>$action,'actor'=>(config('shantui.managed_identity_enabled')?AdminIdentity::actor():((string)config('shantui.admin_email')?:'legacy-session')),'metadata'=>json_encode($metadata),'created_at'=>now(),'updated_at'=>now()]);
 }
 public static function update(ManagedPage $page,array $changes):void {
  $fields=NativeFieldMap::fields($page->base_html);$values=$page->draft_values;
  foreach($changes as $change){$id=$change['id'];$f=$fields[$id]??null;if(!$f)throw ValidationException::withMessages(['changes'=>['This field cannot be edited with the current template.']]);
   $value=$change['value']??'';
   if($value===$f['value']){unset($values[$id]);continue;}
   if(!$f['editable'])throw ValidationException::withMessages(['changes'=>['This responsive or long-content field needs a dedicated adapter.']]);
   if(mb_strlen($value)>$f['limit'])throw ValidationException::withMessages(['changes'=>["{$f['label']} exceeds the current template's {$f['limit']}-character content limit."]]);
   if(in_array($f['type'],['image','video'],true)){
    $ext=$f['type']==='image'?'png|jpe?g|webp|gif|svg':'mp4|webm';
    if(!preg_match('~^/(?!/)[a-zA-Z0-9/_%.\-]+\.(?:'.$ext.')$~i',$value)||str_contains(rawurldecode($value),'..'))throw ValidationException::withMessages(['changes'=>['Choose a valid existing local media file.']]);
    if(!WorkspaceMedia::resolve($value))throw ValidationException::withMessages(['changes'=>['This media file is not installed in the workspace. Upload or choose an available file.']]);
   }
   if($f['type']==='link'&&(!preg_match('~^(?:/(?!/)|https://|mailto:|tel:)~i',$value)||preg_match('/[\r\n<>"\']/', $value)))throw ValidationException::withMessages(['changes'=>['Choose a valid page or HTTPS/contact destination.']]);
   if($f['type']==='link'&&str_starts_with($value,'/')){
    $url=parse_url($value);parse_str($url['query']??'',$query);$target=$url['path']??'';
    if($target==='/api/site/render')$target=$query['path']??'';
    if($target==='/')$target='/global/home.html';
    if(isset($query['lang'])&&!in_array($query['lang'],[$page->locale,$page->locale==='fa'?'fa-AF':'en'],true))throw ValidationException::withMessages(['changes'=>['Choose a destination in the selected content language.']]);
    if(!ManagedPage::where('locale',$page->locale)->where('path',$target)->where('status','published')->exists())throw ValidationException::withMessages(['changes'=>['Choose an existing published page in the same content language.']]);
   }
   if($value===$f['value'])unset($values[$id]);else $values[$id]=$value;
  }
  $page->draft_values=$values;$page->revision++;$page->save();self::audit($page,'save_draft',['field_ids'=>array_column($changes,'id')]);
 }
 public static function publish(ManagedPage $page):void {
if(config('shantui.managed_catalogue_enabled')){$root=DB::table('catalogue_groups')->where('page_id',$page->id)->whereNull('parent_id')->first();if($root&&(!$root->published||$root->deleted_at))LocaleCatalogue::fail('category','Publish the category through its structured category editor first.');LocaleCatalogue::validatePublication($page);}
  DB::table('managed_versions')->insert(['page_id'=>$page->id,'revision'=>$page->revision,'values'=>json_encode($page->published_values,JSON_UNESCAPED_UNICODE),'action'=>'before_publish','actor'=>(config('shantui.managed_identity_enabled')?AdminIdentity::actor():((string)config('shantui.admin_email')?:'legacy-session')),'created_at'=>now(),'updated_at'=>now()]);
  foreach(NativeFieldMap::fields($page->base_html) as $f)if($f['group']==='SEO'&&str_starts_with($f['label'],'Page title'))$page->title=$page->draft_values[$f['id']]??$f['value'];
  $page->search_text=self::searchText(self::html($page,true));
  $page->published_values=$page->draft_values;$page->status='published';$page->revision++;$page->save();self::audit($page,'publish');if(config('shantui.managed_catalogue_enabled'))LocaleCatalogue::saved($page,true);
 }
}
