<?php
namespace App\Support;

use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/** One public, non-secret contract consumed by both PHP and the browser. */
final class FormValidation
{
 public static function contract(): array {static $contract;return $contract??=json_decode(file_get_contents(base_path('../public/global/validation-rules.json')),true,512,JSON_THROW_ON_ERROR);}
 public static function route(string $method,string $path): ?string {
  foreach(self::contract()['routes'] as $route=>$kind){[$m,$p]=explode(' ',$route,2);if($m===$method && preg_match('~^'.str_replace('\\*','[^/]+',preg_quote($p,'~')).'$~D',$path))return $kind;}return null;
 }
 public static function trim(string $value): string {return preg_replace('~^[\\x{0009}-\\x{000D}\\x{0020}\\x{00A0}\\x{1680}\\x{2000}-\\x{200A}\\x{2028}\\x{2029}\\x{202F}\\x{205F}\\x{3000}\\x{FEFF}]+|[\\x{0009}-\\x{000D}\\x{0020}\\x{00A0}\\x{1680}\\x{2000}-\\x{200A}\\x{2028}\\x{2029}\\x{202F}\\x{205F}\\x{3000}\\x{FEFF}]+$~u','',$value);}
 public static function errors(string $kind,array $payload): array {
  $contract=self::contract();$errors=[];
  $walk=function($rule,$value,string $path,bool $exists=true)use(&$walk,&$errors,$contract){
   if(isset($rule['ref']))$rule=array_merge($contract['forms'][$rule['ref']],$rule);
   $blank=$value===null || (is_string($value)&&self::trim($value)==='');
   $fail=function(string $code)use(&$errors,$path){$errors[$path?:'_form'][]=$code;};
   if(($rule['present']??false)&&!$exists){$fail('required');return;}
   if(!$exists||$blank){if(($rule['required']??false)||($exists&&($rule['nonEmpty']??false)))$fail('required');return;}
   if(isset($rule['accepted'])){if(!in_array($value,['yes','on',1,'1',true,'true'],true))$fail('accepted');return;}
   $type=$rule['type']??null;
   $valid=match($type){'string'=>is_string($value),'number'=>is_int($value)||is_float($value)||(is_string($value)&&is_numeric($value)),'integer'=>is_int($value)||(is_string($value)&&ctype_digit($value)),'boolean'=>is_bool($value),'array'=>is_array($value)&&array_is_list($value),'object'=>is_array($value)&&(!$value||!array_is_list($value)),default=>true};
   if(!$valid){$fail('type');return;}
   $v=is_string($value)&&!($rule['raw']??false)?self::trim($value):$value;
   $size=in_array($type,['number','integer'])?(float)$v:(is_string($v)?(int)(strlen(mb_convert_encoding($v,'UTF-16LE','UTF-8'))/2): (is_array($v)?count($v):0));
   if(isset($rule['min'])&&$size<$rule['min'])$fail('min');
   if(isset($rule['max'])&&$size>$rule['max'])$fail('max');
   if(isset($rule['enum'])&&!in_array($v,$rule['enum'],true))$fail('enum');
   if(($rule['noTraversal']??false)&&str_contains((string)$v,'..'))$fail('format');
   if(isset($rule['format'])&&is_string($v)){
    $f=$rule['format'];
    if($f==='date'){$d=\DateTimeImmutable::createFromFormat('!Y-m-d',$v);$ok=$d&&$d->format('Y-m-d')===$v;}
    else $ok=preg_match('~'.str_replace('~','\\~',$contract['formats'][$f]).'~iuD',$v)===1;
    if(!$ok)$fail('format');
   }
   if($type==='object'){
    foreach($rule['properties']??[] as $key=>$child)$walk($child,$v[$key]??null,$path===''?$key:$path.'.'.$key,array_key_exists($key,$v));
    if(($rule['unknown']??true)===false)foreach($v as $key=>$unused)if(!array_key_exists($key,$rule['properties']))$errors[$path.'.'.$key][]='unknown';
    foreach($rule['pairs']??[] as [$a,$b]){ $has=fn($k)=>isset($v[$k])&&$v[$k]!=='';if($has($a)!==$has($b))$errors[($path?$path.'.':'').$a][]='pair';}
    if(isset($rule['requireAny'])){ $has=false;foreach($rule['requireAny'] as $key)if(isset($v[$key])&&self::trim((string)$v[$key])!=='')$has=true;if(!$has)$errors[($path?$path.'.':'').$rule['requireAny'][0]][]='contact';}
   }
   if($type==='array'){
    foreach($v as $i=>$entry)if(isset($rule['items']))$walk($rule['items'],$entry,$path.'.'.$i);
    if(isset($rule['distinct'])){$keys=array_column($v,$rule['distinct']);if(count($keys)!==count(array_unique($keys)))$fail('distinct');}
   }
  };
  $walk($contract['forms'][$kind],$payload,'');
  if($kind==='setting'&&isset($payload['key'])&&str_starts_with($payload['key'],'dealer.')){
   $nested=self::errors('profile_fields',[$payload['key']=>$payload['value']??'']);foreach($nested as $key=>$codes)$errors['value']=$codes;
  }
  if($kind==='visual')foreach(is_array($payload['changes']??null)?$payload['changes']:[] as $i=>$edit){
   if(($edit['reset']??false)===true)continue;$value=$edit['value']??'';$k=$edit['kind']??'';
   $format=match($k){'href'=>'link','src'=>'media','background','poster'=>'image',default=>null};
   if($k==='visible'&&!in_array($value,['0','1'],true))$errors['changes.'.$i.'.value'][]='enum';
   if($format&&(!is_string($value)||!preg_match('~'.str_replace('~','\\~',$contract['formats'][$format]).'~iuD',$value)||(in_array($format,['image','media'])&&str_contains($value,'..'))))$errors['changes.'.$i.'.value'][]='format';
  }
  return $errors;
 }
 public static function enforce(string $kind,Request $request): void {
  $errors=self::errors($kind,$request->all());$limit=self::contract()['maxJsonBytes'][$kind]??null;if($limit&&strlen($request->getContent())>$limit)$errors['_form'][]='max';if(!$errors)return;
  $fa=str_starts_with(app()->getLocale(),'fa');$messages=[];
  $text=$fa?['required'=>'این مورد ضروری است.','type'=>'نوع مقدار درست نیست.','min'=>'مقدار از حداقل مجاز کمتر است.','max'=>'مقدار از حداکثر مجاز بیشتر است.','format'=>'قالب مقدار درست نیست.','enum'=>'گزینهٔ معتبر انتخاب کنید.','accepted'=>'رضایت خود را تأیید کنید.','pair'=>'عرض و طول جغرافیایی را با هم وارد کنید.','contact'=>'تلفن یا ایمیل معتبر لازم است.','distinct'=>'شناسهٔ تکراری وجود دارد.','unknown'=>'این فیلد مجاز نیست.']:['required'=>'This field is required.','type'=>'Invalid value type.','min'=>'Below the minimum allowed.','max'=>'Above the maximum allowed.','format'=>'Invalid format.','enum'=>'Choose a valid option.','accepted'=>'Please confirm your consent.','pair'=>'Enter latitude and longitude together.','contact'=>'A valid phone or email is required.','distinct'=>'Duplicate identifiers.','unknown'=>'This field is not allowed.'];
  foreach($errors as $field=>$codes)$messages[$field]=array_map(fn($code)=>$text[$code]??$code,$codes);
  throw ValidationException::withMessages($messages);
 }
 public static function inquiryKind(array $data): string {
  if(isset($data['form_type']))return is_string($data['form_type'])?$data['form_type']:'_invalid';
  if(array_key_exists('obj.telephone',$data))return 'legacy_message';
  if(array_key_exists('obj.link_man',$data))return 'product_inquiry';
  return 'generic_inquiry';
 }
}
