<?php
namespace App\Support;
use Illuminate\Support\Facades\DB;
final class NativeFacets {
 public static function aliases(string $label,string $locale):array{static $maps=[];if(!isset($maps[$locale])){$maps[$locale]=[];foreach(DB::table('managed_pages')->where('locale',$locale)->where('kind','fragment')->where('base_html','like','%data-name=%')->pluck('base_html') as $html)foreach(self::definitions($html) as $d)$maps[$locale][$d['native']][$d['label']]=$d['label'];}return array_values($maps[$locale][$label]??[$label]);}
 public static function definitions(string $html):array{$nodes=NativeNodes::all($html);$defs=[];foreach($nodes as $item)if($item['end']&&NativeNodes::has($item,'item')){$label='';$native='';$options=[];foreach($nodes as $n)if($n['start']>$item['open']&&$n['end']<=$item['close']){if(NativeNodes::has($n,'t'))$label=NativeNodes::text($html,$n);if(isset($n['attrs']['data-name']))$native=$n['attrs']['data-name'];if($n['tag']==='li'&&isset($n['attrs']['data-id']))$options[]=$n;}if($label&&$native)$defs[]=['label'=>$label,'native'=>$native,'options'=>$options];}return $defs;}
 public static function filter(string $label,string $value):array{$ranges=[];$values=[];foreach(explode('|',$value) as $v){if(preg_match('/^([0-9]+(?:\.[0-9]+)?)~([0-9]+(?:\.[0-9]+)?)$/D',$v,$m)){if($m[1]>$m[2])LocaleCatalogue::fail('specs','Choose a valid range.');$ranges[]=[(float)$m[1],(float)$m[2]];}elseif(is_numeric($v))$ranges[]=[(float)$v,(float)$v];elseif($v!=='')$values[]=$v;}return ['label'=>$label]+($ranges?['native_ranges'=>$ranges]:[])+($values?['native_values'=>$values]:[]);}
}
