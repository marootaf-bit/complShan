<?php
namespace App\Support;
final class WorkspaceMedia {
 public static function resolve(string $path):?string {
  if(!preg_match('~^/(?!/)[a-zA-Z0-9/_%.\-]+\.(?:png|jpe?g|webp|gif|svg|mp4|webm)$~i',$path)||str_contains(rawurldecode($path),'..'))return null;
  foreach([base_path('../public'),config('shantui.upload_root',base_path('../public'))] as $root){$root=realpath($root);$file=$root?realpath($root.$path):false;if($file&&str_starts_with($file,$root.DIRECTORY_SEPARATOR)&&is_file($file))return $file;}
  $manifestFile=base_path('../data/self-hosted-media.json');static $manifest=null;$manifest??=is_file($manifestFile)?json_decode(file_get_contents($manifestFile),true):[];$entry=$manifest[$path]??null;$root=realpath(config('shantui.media_root'));$file=$root&&$entry?realpath($root.DIRECTORY_SEPARATOR.$entry['file']):false;
  return $file&&str_starts_with($file,$root.DIRECTORY_SEPARATOR)&&is_file($file)?$file:null;
 }
 public static function listing():array {
  $paths=[];$m=base_path('../data/self-hosted-media.json');if(is_file($m))$paths=array_keys(json_decode(file_get_contents($m),true)??[]);
  foreach([base_path('../public/upload'),base_path('../public/uploads'),rtrim(config('shantui.upload_root',base_path('../public')),'/').'/uploads'] as $root){if(!is_dir($root))continue;$prefix=str_ends_with($root,'/upload')?'/upload/':'/uploads/';foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS)) as $file)if($file->isFile())$paths[]=$prefix.str_replace(DIRECTORY_SEPARATOR,'/',substr($file->getPathname(),strlen($root)+1));}
  $result=[];foreach(array_unique($paths) as $path){$file=self::resolve($path);if(!$file)continue;$mime=mime_content_type($file);if(!str_starts_with($mime,'image/')&&!in_array($mime,['video/mp4','video/webm']))continue;$result[]=['path'=>$path,'name'=>basename($path),'type'=>str_starts_with($mime,'image/')?'image':'video','bytes'=>filesize($file)];}return $result;
 }
}
