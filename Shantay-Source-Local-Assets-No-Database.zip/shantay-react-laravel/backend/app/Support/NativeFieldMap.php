<?php
namespace App\Support;

/** Byte-offset adapter. No DOM serialization, template reconstruction, or new public markup. */
final class NativeFieldMap
{
 public static function fields(string $html): array {
  $pattern='~<!--[\s\S]*?-->|<(script|style)\b(?:"[^"]*"|\'[^\']*\'|[^\'">])*>[\s\S]*?</\1\s*>|<![^>]*>|<(?:"[^"]*"|\'[^\']*\'|[^\'">])*>|[^<]+~i';
  preg_match_all($pattern,$html,$tokens,PREG_OFFSET_CAPTURE);$stack=[];$rows=[];$numbers=[];
  foreach($tokens[0] as [$token,$offset]){
   if(str_starts_with($token,'<!--')||preg_match('~^<(?:script|style)\b|^<!~i',$token))continue;
   if(preg_match('~^</([a-z0-9]+)~i',$token,$close)){
    for($i=count($stack)-1;$i>=0;$i--)if($stack[$i]['tag']===strtolower($close[1])){$stack=array_slice($stack,0,$i);break;}continue;
   }
   $context=$stack?end($stack):['skip'=>false,'group'=>'Page content','tag'=>'','classes'=>'','in_head'=>false];
   if(preg_match('~^<([a-z0-9]+)\b~i',$token,$open)){
    $tag=strtolower($open[1]);
    preg_match_all('~\s([a-z_:][a-z0-9_:.-]*)\s*=\s*(["\'])(.*?)\2~is',$token,$attributeTokens,PREG_SET_ORDER|PREG_OFFSET_CAPTURE);
    $named=[];foreach($attributeTokens as $a)$named[strtolower($a[1][0])]=$a[3][0];$classes=$named['class']??'';
    $skip=$context['skip']||in_array($tag,['header','footer','nav','svg','noscript'],true)||preg_match('~(?:^|\s)(?:header|footer|iconfont|fixright|m_header|m_nav|mnav|cookie-tip)(?:\s|$)~i',$classes);
    $group=$context['group'];foreach(['xc_banner'=>'Banner','pro_detail'=>'Product details','parts_detail'=>'Part details','news_detail'=>'Article','ipart'=>'Homepage sections','channel_content'=>'Page content','cms-contact'=>'Contact details'] as $key=>$label)if(str_contains($classes,$key))$group=$label;
    if($tag==='table')$group='Technical specifications';if($tag==='title')$group='SEO';
    $ctx=['tag'=>$tag,'skip'=>(bool)$skip,'group'=>$group,'classes'=>$classes,'in_head'=>$context['in_head']||$tag==='head'];
    if(!$skip&&in_array($tag,['img','source','video','a','meta'],true)){
     foreach($attributeTokens as $attr){$name=strtolower($attr[1][0]);if(!in_array($name,['src','href','alt','poster','content'],true))continue;$raw=$attr[3][0];$type=null;$label='';
      if(in_array($tag,['img','source','video'],true)&&in_array($name,['src','poster'],true)){$type=$tag==='source'||$tag==='video'&&$name==='src'?'video':'image';$label=$type==='video'?'Video':'Image';}
      elseif($tag==='img'&&$name==='alt'){$type='alt';$label='Image description';}
      elseif($tag==='a'&&$name==='href'&&preg_match('~^(?:/(?!/)|https://|mailto:|tel:)~i',$raw)){$type='link';$label='Link destination';}
      elseif($tag==='meta'&&$name==='content'&&strtolower($named['name']??'')==='description'){$type='text';$label='SEO description';}
      if($type){$id='f-'.dechex($offset+$attr[3][1]);$value=html_entity_decode($raw,ENT_QUOTES|ENT_HTML5,'UTF-8');$rows[$id]=['id'=>$id,'group'=>$tag==='meta'?'SEO':$group,'type'=>$type,'label'=>$label,'value'=>$value,'limit'=>$type==='text'?mb_strlen($value):($type==='alt'?240:2000),'start'=>$offset+$attr[3][1],'length'=>strlen($raw),'attribute'=>true,'editable'=>!($name==='src'&&((bool)array_intersect(['srcset','data-src','data-original','data-lazy-src'],array_keys($named))||in_array('picture',array_column($stack,'tag'),true)))];}
     }
    }
    if(!in_array($tag,['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'],true)&&!str_ends_with(rtrim($token),'/>'))$stack[]=$ctx;
    continue;
   }
   if($context['skip']||$context['in_head']&&$context['tag']!=='title')continue;
   $raw=trim($token);$value=html_entity_decode($raw,ENT_QUOTES|ENT_HTML5,'UTF-8');
   if(!preg_match('/[\p{L}\p{N}]/u',$value)||(mb_strlen($value)<2&&!preg_match('/\p{N}/u',$value)))continue;
   $start=$offset+strlen($token)-strlen(ltrim($token));$id='f-'.dechex($start);$role=in_array($context['tag'],['h1','h2','h3','h4'],true)?'Heading':($context['tag']==='title'?'Page title':(in_array($context['tag'],['td','th'],true)?'Specification text':($context['tag']==='a'?'Link text':'Text')));
   $n=($numbers[$context['group'].'|'.$role]??0)+1;$numbers[$context['group'].'|'.$role]=$n;
   $rows[$id]=['id'=>$id,'group'=>$context['group'],'type'=>'text','label'=>$role.' '.$n,'value'=>$value,'limit'=>mb_strlen($value),'start'=>$start,'length'=>strlen($raw),'attribute'=>false,'editable'=>mb_strlen($value)<=20000];
  }
  return $rows;
 }
 public static function render(string $html,array $values): string {
  if(!$values)return $html;$fields=self::fields($html);$patches=[];
  foreach($values as $id=>$value){$f=$fields[$id]??null;if(!$f||$value===$f['value'])continue;$flags=ENT_SUBSTITUTE|($f['attribute']?ENT_QUOTES:ENT_NOQUOTES);$patches[]=['start'=>$f['start'],'length'=>$f['length'],'value'=>htmlspecialchars($value,$flags,'UTF-8')];}
  usort($patches,fn($a,$b)=>$b['start']<=>$a['start']);foreach($patches as $p)$html=substr_replace($html,$p['value'],$p['start'],$p['length']);return $html;
 }
}
