<?php
namespace App\Support;

/** Read-only display corrections. Does not approve translations or write catalogue data. */
final class DisplayReview
{
    public static function decorate(\DOMDocument $doc, \DOMXPath $xpath): void
    {
        $copy = [
            'یک نقل قول دریافت کنید' => 'پیشنهاد قیمت دریافت کنید',
            'لایه لوله متوسط' => 'لوله‌گذار متوسط',
            'استخراج کارشناسی ارشد' => 'استخراج حرفه‌ای',
            '400 مرکز خدمات مشتری ما به مراکز ارتباطات اطلاعاتی تقسیم شده اند، مراکزی برای بهبود رضایت مشتری' => 'طبق معلومات سازنده، شبکهٔ جهانی شانتای شامل ۴۰۰ مرکز خدمات مشتری برای ارتباط با مشتریان و بهبود رضایت آنان است.',
            '400 مرکز خدمات مشتری ما' => '۴۰۰ مرکز خدمات مشتری شرکت سازندهٔ شانتای در شبکهٔ جهانی آن',
        ];
        foreach ($xpath->query('//text()[not(ancestor::script or ancestor::style or ancestor::textarea or ancestor::code or ancestor::pre)]') as $node) {
            $node->nodeValue = preg_replace('/\bTotal\s+(\d+)\s+results\b/u', 'مجموع $1 محصول', strtr($node->nodeValue, $copy));
        }
        // A missing source value is not zero, and must not be fabricated.
        foreach ($xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," parameter ")]//*[contains(concat(" ",normalize-space(@class)," ")," line ") or contains(concat(" ",normalize-space(@class)," ")," item ")]') as $line) {
            if (preg_match('/(?:قدرت\s*(?:انجن|موتور)|Engine\s+power).*[:：]\s*$/iu', trim($line->textContent))) {
                $notice = $doc->createElement('span');
                $notice->setAttribute('class', 'catalogue-unreported');
                $notice->appendChild($doc->createTextNode(' در کاتالوگ درج نشده'));
                $line->appendChild($notice);
            }
        }
        foreach ($xpath->query('//title/text()') as $node) {
            $node->nodeValue = preg_replace('/^Excavator(?=\s*\|)/u', 'اکسکاواتور', $node->nodeValue);
        }

    }

    public static function fragment(string $html, bool $fa): string
    {
        if (!$fa || trim($html) === '') return $html;
        $doc = new \DOMDocument('1.0', 'UTF-8');
        $old = libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8"><html><body><div id="display-review-root">'.$html.'</div></body></html>');
        libxml_clear_errors(); libxml_use_internal_errors($old);
        $xpath = new \DOMXPath($doc); self::decorate($doc, $xpath);
        $root = $xpath->query('//*[@id="display-review-root"]')->item(0);
        $out = ''; foreach ($root->childNodes as $node) $out .= $doc->saveHTML($node);
        return $out;
    }
}
