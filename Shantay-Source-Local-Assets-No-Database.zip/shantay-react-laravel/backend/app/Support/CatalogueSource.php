<?php
namespace App\Support;
use Illuminate\Support\Facades\DB;
/** Read-only discovery of existing records. No public rendering or source writes. */
final class CatalogueSource
{
 public static function c(string $name): string{return "contains(concat(' ',normalize-space(@class),' '),' $name ')";}
 public static function gid(string $path): string{return 'g-'.substr(hash('sha256',$path),0,16);}
 public static function iid(string $path): string{return 'i-'.substr(hash('sha256',$path),0,16);}
 public static function defaults(): array {
  $groups=[];$native=[];$members=[];$meta=[];
  $pages=DB::table('pages')->where('path','like','/product/%')->where('path','not like','%detail%')->orderBy('path')->get(['path','title','html']);
  $localized=DB::table('component_localizations')->where('component_type','page')->where('locale','fa')->whereIn('component_key',$pages->pluck('path'))->pluck('html','component_key')->all();
  foreach($pages as $p){
   if($p->path==='/product/parts.htm'){
    [$d,$x]=SiteContent::dom($p->html);[$fd,$fx]=SiteContent::dom($localized[$p->path]??$p->html);
    foreach($x->query('//*['.self::c('parts_list01').']//*['.self::c('top').']//li[@data-id]') as $li){$n=$li->getAttribute('data-id');if(!ctype_digit($n))continue;$id=self::gid('parts-'.$n);$fa=$fx->query('//li[@data-id="'.$n.'"]//*['.self::c('t').']')->item(0)?->textContent; $en=$x->query('.//*['.self::c('t').']',$li)->item(0)?->textContent??$n;
     $groups[]=['id'=>$id,'kind'=>'parts','name_fa'=>trim($fa?:$en),'name_en'=>trim($en),'path'=>$p->path,'source_path'=>$p->path,'native_id'=>$n,'published'=>true,'legacy'=>true];$native['parts:'.$n]=$id;
    }continue;
   }
   [$d,$x]=SiteContent::dom($p->html);$n=$x->query('//input[@id="channelId"]')->item(0)?->getAttribute('value')??'';
   if($n===''||!ctype_digit($n))continue;
   $name=function($html,$fallback){[$d,$x]=SiteContent::dom($html);$n=$x->query('//*['.self::c('xc_banner').']//*[self::h1 or self::h2 or '.self::c('title').' or '.self::c('tit').' or '.self::c('t').']')->item(0);return trim($n?->textContent?:$fallback);};
   $id=self::gid($p->path);$fallback=explode('-Shantui',$p->title)[0];$groups[]=['id'=>$id,'kind'=>'products','name_fa'=>$name($localized[$p->path]??$p->html,$fallback),'name_en'=>$name($p->html,$fallback),'path'=>$p->path,'source_path'=>$p->path,'native_id'=>$n,'published'=>true,'legacy'=>true];$native['product:'.$n]=$id;
  }
  foreach(DB::table('fragments')->whereIn('kind',['product','parts'])->where('flag','getData')->get(['kind','channel_id','filters','html']) as $f){
   $filters=json_decode($f->filters,true)?:[];$key=$f->kind.':'.($f->kind==='parts'?($filters['catId']??''):$f->channel_id);$gid=$native[$key]??null;
   [$d,$x]=SiteContent::dom('<html><body>'.$f->html.'</body></html>');foreach($x->query('//a[contains(@href,"/product/") and contains(@href,"detail-")]') as $a){$path=parse_url($a->getAttribute('href'),PHP_URL_PATH);if(!$path)continue;if($gid)$members[$path][$gid]=true;$image=$x->query('.//img[@src]',$a)->item(0)?->getAttribute('src')??'';$name=($x->query('.//*['.self::c('model').']',$a)->item(0)??$x->query('.//*['.self::c('t').' or '.self::c('tit').' or '.self::c('title').']',$a)->item(0))?->textContent??'';if($image)$meta[$path]['image']=$image;if(trim($name)!=='')$meta[$path]['name']=trim($name);}
  }
  $items=[];
  foreach(DB::table('pages')->where(fn($q)=>$q->where('path','like','/product/pro-detail-%')->orWhere('path','like','/product/parts-detail-%'))->orderBy('path')->cursor() as $p){
   $kind=str_contains($p->path,'/parts-detail-')?'parts':'products';$ids=array_keys($members[$p->path]??[]);
   if(!$ids){$gid='unassigned-'.$kind;if(!in_array($gid,array_column($groups,'id'),true))$groups[]=['id'=>$gid,'kind'=>$kind,'name_fa'=>'بدون گروپ — نیاز به تعیین','name_en'=>'Unassigned','path'=>'','source_path'=>'','native_id'=>'','published'=>false,'legacy'=>true];$ids=[$gid];}
   preg_match('~<div\b[^>]*class=["\'][^"\']*\bmodel\b[^"\']*["\'][^>]*>(.*?)</div>~is',$p->html,$model);$name=trim(html_entity_decode(strip_tags($model[1]??($meta[$p->path]['name']??explode('-Shantui',$p->title)[0])),ENT_QUOTES,'UTF-8'));
   if($name==='')$name=trim($meta[$p->path]['name']??'');if($name===''){preg_match('/detail-([0-9]+)/',$p->path,$number);$name='بدون نام — نیاز به بررسی ('.($number[1]??'').')';}
   $items[]=['id'=>self::iid($p->path),'kind'=>$kind,'path'=>$p->path,'name_fa'=>$name,'name_en'=>$name,'group_ids'=>$ids,'image'=>$meta[$p->path]['image']??'','description_fa'=>'','description_en'=>'','specs'=>[],'published'=>true,'legacy'=>true];
  }
  return ['groups'=>$groups,'items'=>$items];
 }
}
