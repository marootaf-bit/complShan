<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \Illuminate\Support\Facades\RateLimiter::for('admin-login',fn($request)=>\Illuminate\Cache\RateLimiting\Limit::perMinute(5)->by($request->ip()));
        \Illuminate\Support\Facades\RateLimiter::for('inquiries',fn($request)=>\Illuminate\Cache\RateLimiting\Limit::perMinute(5)->by($request->ip()));
        \Illuminate\Support\Facades\RateLimiter::for('newsletter',fn($request)=>\Illuminate\Cache\RateLimiting\Limit::perMinute(3)->by($request->ip()));
    }
}
