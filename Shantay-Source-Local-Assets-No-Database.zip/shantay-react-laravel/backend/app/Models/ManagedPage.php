<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
final class ManagedPage extends Model {
 use SoftDeletes;
 protected $guarded=['id'];
 protected $hidden=['base_html'];
 protected function casts(): array{return ['draft_values'=>'array','published_values'=>'array','revision'=>'integer'];}
}
