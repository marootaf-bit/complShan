<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class ManagePageRequest extends FormRequest {
 public function authorize(): bool{return \App\Http\Middleware\AdminApiAuth::validToken((string)$this->cookie('shantui_admin',''));}
 public function rules(): array {
  return ['locale'=>'required|in:fa,en','revision'=>'required|integer|min:1','changes'=>'sometimes|array|max:2500','changes.*.id'=>'required|string|max:40|distinct','changes.*.value'=>'present|nullable|string|max:20000'];
 }
}
