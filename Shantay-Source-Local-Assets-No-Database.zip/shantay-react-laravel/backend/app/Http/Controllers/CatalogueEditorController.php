<?php
namespace App\Http\Controllers;

use App\Support\CatalogueSource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** Stage 1: admin-only registry. No hooks into public templates, menus or renderers. */
final class CatalogueEditorController extends Controller
{
    public const KEY='admin.catalogue.v1';

    private function state(): array
    {
        $raw=DB::table('settings')->where('key',self::KEY)->value('value');
        $data=$raw===null?CatalogueSource::defaults():json_decode($raw,true);
        abort_unless(is_array($data)&&isset($data['groups'],$data['items']),409,'Catalogue data requires review.');
        return $data;
    }
    private function responseData(array $data): array
    {
        return ['data'=>$data,'revision'=>hash('sha256',json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),'public_connected'=>false];
    }
    public function index() { return response()->json($this->responseData($this->state())); }
    private function invalid(string $field,string $message): never
    {
        throw ValidationException::withMessages([$field=>[$message]]);
    }
    public function save(Request $request,string $resource,?string $id=null)
    {
        abort_unless(in_array($resource,['groups','items'],true),404);
        $rules=['revision'=>'required|string|size:64','kind'=>'required|in:products,parts','name_fa'=>'required|string|max:180','name_en'=>'nullable|string|max:180','published'=>'required|boolean'];
        if($resource==='items')$rules += ['group_ids'=>'required|array|min:1|max:30','group_ids.*'=>'required|string|distinct|max:80','image'=>['nullable','string','max:500','regex:~^/(?!/)[a-zA-Z0-9/_%.\-]+\.(?:jpe?g|png|webp|gif|svg)$~i'],'description_fa'=>'nullable|string|max:10000','description_en'=>'nullable|string|max:10000','specs'=>'present|array|max:80','specs.*.name'=>'required|string|max:160','specs.*.value'=>'required|string|max:600'];
        $v=$request->validate($rules);
        return DB::transaction(function() use($v,$resource,$id){
            $data=$this->state();abort_unless(hash_equals($this->responseData($data)['revision'],$v['revision']),409,'این فهرست تغییر کرده است؛ دوباره بارگذاری کنید.');
            $index=null;
            if($id!==null){foreach($data[$resource] as $n=>$row)if($row['id']===$id){$index=$n;break;}abort_if($index===null,404);if($data[$resource][$index]['kind']!==$v['kind'])$this->invalid('kind','نوع محصول/قطعه قابل تغییر نیست.');}
            $row=$index!==null?$data[$resource][$index]:['id'=>($resource==='groups'?'g-':'i-').Str::uuid(),'kind'=>$v['kind'],'legacy'=>false,'path'=>'','source_path'=>'','native_id'=>''];
            $v['published']=(bool)$v['published'];
            if($resource==='items'){
                foreach($v['group_ids'] as $gid){$group=collect($data['groups'])->firstWhere('id',$gid);if(!$group||$group['kind']!==$v['kind'])$this->invalid('group_ids','گروپ باید از همین نوع محصول یا قطعه باشد.');
                    if(!$group['published']&&!in_array($gid,$row['group_ids']??[],true))$this->invalid('group_ids','گروپ غیرفعال را برای مورد تازه انتخاب نکنید.');}
                // Arrays are rebuilt explicitly: unknown input cannot overwrite canonical IDs/paths.
                $row['group_ids']=array_values($v['group_ids']);$row['image']=$v['image']??'';$row['description_fa']=$v['description_fa']??'';$row['description_en']=$v['description_en']??'';
                $row['specs']=array_map(fn($s)=>['name'=>$s['name'],'value'=>$s['value']],$v['specs']);
            } elseif(!$v['published'] && !empty($row['published'])) {
                foreach($data['items'] as $item)if(in_array($row['id'],$item['group_ids'],true))$this->invalid('published','ابتدا همهٔ موارد این گروپ را منتقل کنید؛ از گزینهٔ انتقال و غیرفعال‌سازی استفاده کنید.');
            }
            $row['name_fa']=$v['name_fa'];$row['name_en']=$v['name_en']??'';$row['published']=$v['published'];
            if($index===null)$data[$resource][]=$row;else $data[$resource][$index]=$row;
            DB::table('settings')->updateOrInsert(['key'=>self::KEY],['value'=>json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'updated_at'=>now()->toIso8601String()]);
            return response()->json($this->responseData($data)+['saved_id'=>$row['id']],$index===null?201:200);
        },3);
    }
    public function retire(Request $request,string $id)
    {
        $v=$request->validate(['revision'=>'required|string|size:64','target_group_id'=>'nullable|string|max:80']);
        return DB::transaction(function()use($id,$v){
            $data=$this->state();abort_unless(hash_equals($this->responseData($data)['revision'],$v['revision']),409,'فهرست تغییر کرده است؛ دوباره بارگذاری کنید.');
            $index=null;foreach($data['groups'] as $n=>$g)if($g['id']===$id){$index=$n;break;}abort_if($index===null,404);
            $children=array_filter($data['items'],fn($i)=>in_array($id,$i['group_ids'],true));$target=$v['target_group_id']??null;
            if($target){$g=collect($data['groups'])->firstWhere('id',$target);if(!$g||$target===$id||$g['kind']!==$data['groups'][$index]['kind']||!$g['published'])$this->invalid('target_group_id','گروپ مقصد باید فعال، متفاوت و از همین نوع باشد.');}
            if($children&&!$target)$this->invalid('target_group_id','گروپ دارای مورد است؛ مقصد انتقال را انتخاب کنید.');
            foreach($data['items'] as &$item)if(in_array($id,$item['group_ids'],true))$item['group_ids']=array_values(array_unique(array_merge(array_diff($item['group_ids'],[$id]),[$target])));unset($item);
            $data['groups'][$index]['published']=false;
            DB::table('settings')->updateOrInsert(['key'=>self::KEY],['value'=>json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'updated_at'=>now()->toIso8601String()]);
            return response()->json($this->responseData($data)+['transferred'=>count($children)]);
        },3);
    }
}
