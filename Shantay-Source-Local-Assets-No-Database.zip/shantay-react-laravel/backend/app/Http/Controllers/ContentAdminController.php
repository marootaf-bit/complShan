<?php
namespace App\Http\Controllers;

use App\Support\SiteContent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

final class ContentAdminController extends Controller
{
 private function kind(string $kind): void {abort_unless(in_array($kind,['news','branches','navigation'],true),404);}
 public function collection(string $kind){$this->kind($kind);$items=SiteContent::collection($kind);return response()->json(['items'=>$items,'revision'=>SiteContent::revision($items)]);}
 public function save(Request $request,string $kind){
  $this->kind($kind);abort_if(strlen($request->getContent())>4000000,413);
  $data=$request->validate(['revision'=>'required|string|size:64','items'=>'present|array|max:200','items.*.id'=>['required','string','max:80','regex:/^[a-zA-Z0-9][a-zA-Z0-9_-]*$/','distinct'],'items.*.published'=>'required|boolean']);
  $rules=match($kind){
   'news'=>['title_fa'=>'required|string|max:240','title_en'=>'nullable|string|max:240','summary_fa'=>'nullable|string|max:1500','summary_en'=>'nullable|string|max:1500','body_fa'=>'required|string|max:30000','body_en'=>'nullable|string|max:30000','date'=>'required|date_format:Y-m-d','image'=>'nullable|string|max:500'],
   'branches'=>['name_fa'=>'required|string|max:160','name_en'=>'nullable|string|max:160','address_fa'=>'required|string|max:500','address_en'=>'nullable|string|max:500','phone'=>['nullable','string','max:25','regex:/^\+?[\p{N} ()-]{7,25}$/u'],'email'=>'nullable|email|max:180','whatsapp'=>['nullable','string','regex:/^[0-9]{7,18}$/'],'latitude'=>'nullable|numeric|between:-90,90','longitude'=>'nullable|numeric|between:-180,180'],
   'navigation'=>['path'=>['required','string','max:240','regex:~^/(?!/)[^\s<>]*$~'],'label_fa'=>'required|string|max:100','label_en'=>'nullable|string|max:100']};
  $items=[];
  foreach($request->input('items') as $row){$v=Validator::make($row,$rules)->validate();foreach(array_keys($rules) as $field)if(!isset($v[$field]))$v[$field]=in_array($field,['latitude','longitude'])?null:'';$v['id']=$row['id'];$v['published']=(bool)$row['published'];
   if($kind==='news' && $v['image']!=='' && !$this->localImage($v['image']))return response()->json(['message'=>'تصویر باید مسیر محلی معتبر باشد.'],422);
   if($kind==='branches' && (($v['latitude']===null)!==($v['longitude']===null)))return response()->json(['message'=>'عرض و طول جغرافیایی را با هم وارد کنید.'],422);
   $items[]=$v;
  }
  return DB::transaction(function()use($kind,$data,$items){$current=SiteContent::collection($kind);if(!hash_equals(SiteContent::revision($current),$data['revision']))return response()->json(['message'=>'محتوا تغییر کرده است؛ دوباره بارگذاری کنید.'],409);SiteContent::store('cms.'.$kind,$items);return response()->json(['saved'=>true,'items'=>$items,'revision'=>SiteContent::revision($items)]);});
 }
 private function localImage(string $value): bool{return (bool)preg_match('~^/(?!/)(?:assets|upload|uploads|resources|global)/[^<>\s"\']+\.(?:png|jpe?g|webp|gif|svg)(?:\?[^<>"\']*)?$~i',$value)&&!str_contains($value,'..');}
 private function rendered(string $path,string $locale): string {
  abort_unless(DB::table('pages')->where('path',$path)->exists(),404);$before=config('shantui.admin_content_preview',false);
  try{config(['shantui.admin_content_preview'=>true]);$r=app(SiteApiController::class)->render(Request::create('/api/site/render','GET',['path'=>$path,'lang'=>$locale]),$path);abort_unless($r->getStatusCode()===200,404);abort_if($locale==='fa'&&$r->headers->get('X-Content-Locale')!=='fa-AF',422,'نسخهٔ دری کامل نیست؛ ابتدا ترجمه را در بخش صفحات ثبت کنید.');return $r->getContent();}finally{config(['shantui.admin_content_preview'=>$before]);}
 }
 public function preview(Request $request){$v=$request->validate(['path'=>'required|string|max:240','locale'=>'required|in:fa,en']);return response($this->rendered($v['path'],$v['locale']))->header('Content-Type','text/html; charset=UTF-8')->header('Cache-Control','no-store, private');}
 public function visual(Request $request){$v=$request->validate(['path'=>'required|string|max:240','locale'=>'required|in:fa,en']);$html=$this->rendered($v['path'],$v['locale']);$edits=SiteContent::overrides($v['path'],$v['locale']);return response()->json(['nodes'=>SiteContent::nodes($html),'revision'=>SiteContent::revision($edits),'base_hash'=>hash('sha256',$html),'path'=>$v['path'],'locale'=>$v['locale'],'overrides'=>count($edits)]);}
 public function saveVisual(Request $request){
  abort_if(strlen($request->getContent())>4000000,413);
  $v=$request->validate(['path'=>'required|string|max:240','locale'=>'required|in:fa,en','revision'=>'required|string|size:64','base_hash'=>'required|string|size:64','changes'=>'present|array|max:1000','changes.*.xpath'=>'required|string|max:1500','changes.*.kind'=>'required|in:text,src,href,alt,title,placeholder,visible,description,background,poster','changes.*.value'=>'nullable|string|max:30000','changes.*.reset'=>'sometimes|boolean']);
  return DB::transaction(function()use($v){
  $html=$this->rendered($v['path'],$v['locale']);$current=SiteContent::overrides($v['path'],$v['locale']);
  if(!hash_equals(SiteContent::revision($current),$v['revision'])||!hash_equals(hash('sha256',$html),$v['base_hash']))return response()->json(['message'=>'نسخهٔ صفحه تغییر کرده؛ ابتدا بارگذاری مجدد کنید.'],409);
  $allowed=[];foreach(SiteContent::nodes($html) as $node)$allowed[$node['xpath'].'|'.$node['kind']]=$node;
  $edits=[];foreach($current as $e)$edits[$e['xpath'].'|'.$e['kind']]=$e;
  foreach($v['changes'] as $e){$key=$e['xpath'].'|'.$e['kind'];if(!isset($allowed[$key]))return response()->json(['message'=>'این بخش صفحه قابل ویرایش نیست.'],422);if($e['reset']??false){unset($edits[$key]);continue;}$e['value']??='';
   if(in_array($e['kind'],['src','background','poster'],true)){
    $video=$e['kind']==='src'&&in_array($allowed[$key]['tag']??'',['video','source'],true);
    $valid=$video?(bool)preg_match('~^/(?!/)(?:upload|uploads|assets|resources|global)/[^<>\s"\']+\.mp4$~i',$e['value'])&&!str_contains($e['value'],'..'):$this->localImage($e['value']);
    if(!$valid)return response()->json(['message'=>'از مسیر محلی معتبر تصویر یا ویدیوی MP4 استفاده کنید.'],422);
   }
   if($e['kind']==='href'&&(!preg_match('~^(?:/(?!/)|https://|mailto:|tel:|#)~i',$e['value'])||preg_match('/[\r\n<>]/',$e['value'])))return response()->json(['message'=>'لینک معتبر نیست.'],422);
   if($e['kind']==='visible'&&!in_array($e['value'],['0','1'],true))return response()->json(['message'=>'وضعیت نمایش معتبر نیست.'],422);
   $edits[$key]=['xpath'=>$e['xpath'],'kind'=>$e['kind'],'value'=>$e['value']];
  }
  SiteContent::store(SiteContent::overrideKey($v['path'],$v['locale']),array_values($edits));return response()->json(['saved'=>true,'count'=>count($edits)]);
  });
 }
}
