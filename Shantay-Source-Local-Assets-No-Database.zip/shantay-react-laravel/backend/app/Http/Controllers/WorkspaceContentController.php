<?php
namespace App\Http\Controllers;
use App\Http\Requests\ManagePageRequest;
use App\Models\ManagedPage;
use App\Support\ManagedPublishing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class WorkspaceContentController extends Controller {
 public function media(){return \App\Support\WorkspaceMedia::listing();}
 public function index(Request $r){
  $v=$r->validate(['locale'=>'required|in:fa,en','q'=>'nullable|string|max:160','kind'=>'nullable|in:page,product,part,category,parts-category,news,fragment','page'=>'sometimes|integer|min:1']);
  $q=ManagedPage::where('locale',$v['locale'])->where('kind','!=','fragment');if(!empty($v['kind']))$q->where('kind',$v['kind']);
  if(!empty($v['q'])){$needle=addcslashes($v['q'],'%_\\');$q->where(fn($q)=>$q->where('title','like','%'.$needle.'%')->orWhere('path','like','%'.$needle.'%'));}
  return $q->select('id','locale','path','title','kind','status','revision')->orderBy('path')->paginate(25);
 }
 public function show(Request $r,int $id){$v=$r->validate(['locale'=>'required|in:fa,en']);$p=ManagedPublishing::page($id,$v['locale']);return $this->dto($p);}
 private function dto(ManagedPage $p):array{return ['id'=>$p->id,'locale'=>$p->locale,'path'=>$p->path,'title'=>$p->title,'kind'=>$p->kind,'status'=>$p->status,'revision'=>$p->revision,'has_draft_changes'=>$p->draft_values!=$p->published_values,'fields'=>ManagedPublishing::fields($p),'versions'=>DB::table('managed_versions')->where('page_id',$p->id)->orderByDesc('id')->limit(20)->get(['id','revision','created_at'])];}
 public function save(ManagePageRequest $r,int $id){return $this->mutate($r,$id,fn($p)=>ManagedPublishing::update($p,$r->validated('changes',[])));}
 public function publish(ManagePageRequest $r,int $id){return $this->mutate($r,$id,fn($p)=>ManagedPublishing::publish($p));}
 public function unpublish(ManagePageRequest $r,int $id){return $this->mutate($r,$id,function($p){$p->status='draft';$p->revision++;$p->save();ManagedPublishing::audit($p,'unpublish');});}
 public function restore(ManagePageRequest $r,int $id,int $version){return $this->mutate($r,$id,function($p)use($version){$v=DB::table('managed_versions')->where('page_id',$p->id)->find($version);abort_unless($v,404);$p->draft_values=json_decode($v->values,true);$p->revision++;$p->save();ManagedPublishing::audit($p,'restore_draft',['version_id'=>$version]);});}
 private function mutate(ManagePageRequest $r,int $id,callable $action){return DB::transaction(function()use($r,$id,$action){$p=ManagedPage::where('locale',$r->validated('locale'))->lockForUpdate()->findOrFail($id);abort_unless($p->revision===$r->integer('revision'),409,'This content changed in another session. Reload before saving; your input has not been overwritten.');$action($p);return $this->dto($p);},3);}
 public function preview(Request $r,int $id){$v=$r->validate(['locale'=>'required|in:fa,en']);$p=ManagedPublishing::page($id,$v['locale']);$html=ManagedPublishing::html($p,true);if(config('shantui.managed_catalogue_enabled')){$root=DB::table('catalogue_groups')->where('page_id',$p->id)->whereNull('parent_id')->first();if($root)$html=\App\Support\CategoryRootTemplate::render($html,$root,true);}return $this->previewResponse($html);}
 public function categoryPreview(Request $r,int $id){$v=$r->validate(['locale'=>'required|in:fa,en']);$g=\App\Support\LocaleCatalogue::group($id,$v['locale'],true);$root=$g;while($root->parent_id)$root=\App\Support\LocaleCatalogue::group($root->parent_id,$v['locale']);$p=ManagedPage::withTrashed()->find($root->page_id);$html=ManagedPublishing::html($p,true);$d=json_decode($g->draft_data??'{}',true);$override=clone $g;foreach(['name','position','published'] as $key)if(array_key_exists($key,$d))$override->$key=$d[$key];$override->deleted_at=null;$provenance=json_decode($g->provenance,true);if(isset($d['image']))$provenance['image']=$d['image'];$override->provenance=json_encode($provenance);$html=\App\Support\CategoryRootTemplate::render($html,$root,$g->id===$root->id);$html=\App\Support\CatalogueMenu::render($html,$v['locale'],$root,$override);return $this->previewResponse($html);}
 private function previewResponse(string $html){return response(\App\Support\PrivatePreview::html($html))->header('Content-Type','text/html; charset=UTF-8')->header('Cache-Control','no-store, private')->header('X-Robots-Tag','noindex, nofollow')->header('Content-Security-Policy',"form-action 'none'; base-uri 'none'; object-src 'none'");}
}
