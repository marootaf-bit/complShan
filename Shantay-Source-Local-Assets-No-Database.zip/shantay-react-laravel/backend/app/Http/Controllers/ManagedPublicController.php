<?php
namespace App\Http\Controllers;
use App\Models\ManagedPage;
use App\Support\ManagedPublishing;
use App\Support\SiteLocale;
use Illuminate\Http\Request;

final class ManagedPublicController extends Controller {
 public function render(Request $r,string $path){
  $locale=SiteLocale::storageCode(SiteLocale::resolve($r));
  $page=ManagedPage::where('locale',$locale)->where('path',$path)->where('status','published')->first();
  if(!$page)return response('<!doctype html><meta charset="utf-8"><h1>Page not found</h1>',404)->header('Content-Type','text/html; charset=UTF-8')->header('X-Robots-Tag','noindex');
  $html=ManagedPublishing::html($page);
if(config('shantui.managed_catalogue_enabled')){$root=\Illuminate\Support\Facades\DB::table('catalogue_groups')->where('locale',$locale)->where('page_id',$page->id)->whereNull('parent_id')->first();if($root&&(!$root->published||$root->deleted_at))abort(404);if($root)$html=\App\Support\CategoryRootTemplate::render($html,$root);$html=\App\Support\CatalogueMenu::render($html,$locale,$root);$html=\App\Support\CatalogueNative::detail($html,$page);$html=\App\Support\CatalogueNative::document($html,$locale,$root?->id);if($root)$html=\App\Support\CatalogueNative::appendNew($html,$locale,$root->id);}
if(config('shantui.managed_inquiries_enabled'))$html=preg_replace('~</head>~i','<script src="/global/inquiry-context.js"></script></head>',$html,1);
  if($path==='/site/search.htm'&&$r->filled('keywords')){
   $v=$r->validate(['keywords'=>'required|string|max:120']);$results=$this->results($locale,$v['keywords'],1,60);
   $groups=['product'=>[],'news'=>[],'case'=>[],'channel'=>[]];foreach($results['data'] as $hit){$group=str_starts_with($hit['path'],'/product/')?'product':(str_starts_with($hit['path'],'/news/')?'news':'channel');$href='/api/site/render?'.http_build_query(['path'=>$hit['path'],'lang'=>$locale]);$groups[$group][]='<li data-translation-status="source"><a href="'.e($href).'"><span class="t">'.e($hit['title']).'</span></a></li>';}
   foreach(['keyword'=>e($v['keywords']),'resultNum'=>(string)$results['total'],'productList'=>implode('',$groups['product']),'newList'=>implode('',$groups['news']),'caseList'=>'','channelList'=>implode('',$groups['channel'])] as $id=>$value){$tag=in_array($id,['keyword','resultNum'])?'span':'ul';$html=preg_replace_callback('~(<'.$tag.'\b[^>]*\bid=["\']'.preg_quote($id,'~').'["\'][^>]*>).*?(</'.$tag.'>)~is',fn($m)=>$m[1].$value.$m[2],$html,1);}
   $html=str_replace('class="content_form" style="display: none"','class="content_form" style="display: block"',$html);
  }
  $contentLocale=$locale==='fa'?SiteLocale::DARI:SiteLocale::ENGLISH;
  return response($html)->header('Content-Type','text/html; charset=UTF-8')->header('Cache-Control','no-store')->header('Content-Language',$contentLocale)->header('X-Requested-Locale',$contentLocale)->header('X-Content-Locale',$contentLocale)->header('X-Translation-Status',$page->source_status??'independent')->withCookie(cookie('shantui_lang',$contentLocale,43200,'/',null,$r->isSecure(),false,false,'Lax'));
 }
 public static function fold(string $s):string{return mb_strtolower(strtr($s,['ي'=>'ی','ك'=>'ک','ى'=>'ی']));}
 public function search(Request $r){abort_unless(config('shantui.managed_content_enabled'),404);$v=$r->validate(['lang'=>'required|in:fa,en','keywords'=>'required|string|max:120','page'=>'sometimes|integer|min:1','per_page'=>'sometimes|integer|min:1|max:60']);return $this->results($v['lang'],$v['keywords'],$r->integer('page',1),$r->integer('per_page',15));}
 private function results(string $locale,string $query,int $page,int $per):array {
  $term=self::fold(trim($query));$rows=[];
  if($term!=='')foreach(ManagedPage::where('locale',$locale)->where('status','published')->where('kind','!=','fragment')->where('path','!=','/site/search.htm')->select('id','title','path','search_text')->cursor() as $p){$hay=self::fold($p->title.' '.$p->search_text);if(str_contains($hay,$term))$rows[]=['id'=>$p->id,'title'=>$p->title,'path'=>$p->path,'locale'=>$locale];}
  $total=count($rows);$last=max(1,(int)ceil($total/$per));$page=min($page,$last);return ['data'=>array_slice($rows,($page-1)*$per,$per),'locale'=>$locale,'total'=>$total,'current_page'=>$page,'last_page'=>$last,'per_page'=>$per];
 }
}
