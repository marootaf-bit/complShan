<?php

namespace App\Http\Controllers;

use App\Support\SiteLocale;
use App\Support\Dealership;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class SiteApiController extends Controller
{
    private function now(): string { return now()->utc()->toIso8601String(); }

    private function safePath(?string $raw): ?string
    {
        $path = '/' . ltrim(str_replace('\\', '/', (string) $raw), '/');
        if (str_contains($path, "\0") || preg_match('~(^|/)\.\.?(/|$)~', $path)) return null;
        return $path;
    }

    private function sitePublicPath(string $relative = ''): string
    {
        return rtrim(config('shantui.upload_root',base_path('../public')),'/') . ($relative === '' ? '' : '/' . ltrim($relative, '/'));
    }

    private function sourceHash(string $type, string $key): ?string
    {
        if ($type === 'page') {
            $source = DB::table('pages')->where('path', $key)->first(['title', 'html']);
            return $source ? hash('sha256', (string) $source->title . chr(0) . (string) $source->html) : null;
        }
        if ($type === 'fragment') {
            $source = DB::table('fragments')->where('id', (int) $key)->first(['html']);
            return $source ? hash('sha256', (string) $source->html) : null;
        }
        return null;
    }

    private function localizationStatus(?object $localized, ?string $sourceHash, bool $requiresTitle = false): string
    {
        if (!$localized) return 'missing';
        if (trim((string) ($localized->html ?? '')) === '' || ($requiresTitle && trim((string) ($localized->title ?? '')) === '')) return 'incomplete';
        if (!$sourceHash || !hash_equals($sourceHash, (string) ($localized->source_hash ?? ''))) return 'stale';
        return in_array($localized->status ?? '', ['draft', 'needs_review', 'approved'], true) ? $localized->status : 'needs_review';
    }

    private function canDisplayLocalization(string $status): bool
    {
        // Owner explicitly authorized fresh drafts on this TEST hostname for review.
        // Both configured URL and actual request host must match; statuses stay intact.
        $testReview = config('shantui.test_translation_preview', false)
            && parse_url((string) config('app.url'), PHP_URL_HOST) === 'test.grandtire.af'
            && request()->getHost() === 'test.grandtire.af';
        return $status === 'approved' || (config('shantui.admin_content_preview',false) && in_array($status,['draft','needs_review','stale'],true)) || ((app()->environment('local')
            && config('shantui.translation_preview', false) || $testReview)
            && in_array($status, ['draft', 'needs_review'], true));
    }

    private function setDocumentLocale(string $html, string $requested, string $content, string $status): string
    {
        $pattern = '~<html\b([^>]*)>~i';
        return preg_replace_callback($pattern, function ($match) use ($requested, $content, $status) {
            $attributes = preg_replace('~\s(?:lang|dir|data-requested-locale|data-content-locale|data-translation-status)=(?:"[^"]*"|\'[^\']*\'|[^\s>]*)~i', '', $match[1]) ?? $match[1];
            return '<html' . $attributes . ' lang="' . e($content) . '" dir="' . SiteLocale::direction($content) . '" data-requested-locale="' . e($requested) . '" data-content-locale="' . e($content) . '" data-translation-status="' . e($status) . '">';
        }, $html, 1) ?? $html;
    }

    private function saveFaComponent(string $type, string $key, ?string $title, string $html, string $status = 'needs_review'): void
    {
        if (trim($html) === '' && trim((string) $title) === '') {
            DB::table('component_localizations')->where('component_type', $type)->where('component_key', $key)->where('locale', 'fa')->delete();
            return;
        }
        if (!in_array($status, ['draft', 'needs_review', 'approved'], true)) $status = 'needs_review';
        $reviewedAt = $status === 'approved' ? $this->now() : null;
        DB::table('component_localizations')->updateOrInsert(
            ['component_type' => $type, 'component_key' => $key, 'locale' => 'fa'],
            ['title' => $title, 'html' => $html, 'status' => $status, 'source_hash' => $this->sourceHash($type, $key), 'reviewed_at' => $reviewedAt, 'updated_at' => $this->now()]
        );
    }

    public function home(Request $request)
    {
        $compiled = base_path('../dist/index.html');
        if (is_file($compiled)) return response()->file($compiled, ['Cache-Control'=>'no-store, max-age=0']);

        // The unbundled Vite index points at JSX that Laravel cannot serve directly.
        // When the frontend bundle is absent, show the mirrored homepage instead of a blank shell.
        if (!$request->query->has('lang')) {
            return redirect('/?lang=' . SiteLocale::storageCode(SiteLocale::resolve($request)));
        }
        return $this->render($request, '/global/home.html');
    }

    public function adminPage(Request $request)
    {
        $file = base_path(config('shantui.managed_content_enabled')?'../public/admin/workspace.html':'../public/admin/index.html');
        abort_unless(is_file($file), 404);
        $demoAllowed=app()->environment('local') || config('shantui.admin_demo_enabled',false);
        abort_if($request->query('demo')==='1' && !$demoAllowed,404);
        $html=file_get_contents($file);
        if(!$demoAllowed)$html=preg_replace('~<a href="/admin\?demo=1">.*?</a>~s','',$html);
        return response($html)->header('Content-Type','text/html; charset=UTF-8');
    }

    public function render(Request $request, ?string $routePath = null)
    {
        $path = $this->safePath($request->query('path', $routePath ? '/' . ltrim($routePath, '/') : '/global/home.html'));
        if (!$path) return response('Bad path', 400);
        if ($path === '/') $path = '/global/home.html';
        if(config('shantui.managed_content_enabled')&&!config('shantui.importing_content')){
            return app(\App\Http\Controllers\ManagedPublicController::class)->render($request,$path);
        }

        if (Dealership::removed($path)) return response('<!doctype html><html lang="fa-AF" dir="rtl"><meta charset="utf-8"><title>صفحه حذف شده</title><p>این صفحه از سایت حذف شده است.</p><a href="/global/home.html?lang=fa">صفحهٔ اصلی</a></html>',404);
        $dealerSettings = DB::table('settings')->where('key','not like','cms.page.%')->pluck('value', 'key')->all();
        if (Dealership::unavailable($path, $dealerSettings)) return response('<!doctype html><html lang="fa-AF" dir="rtl"><meta charset="utf-8"><title>بخش غیرفعال</title><p>این بخش فعلاً فعال نیست.</p><a href="/about/contact-us.htm?lang=fa">تماس با نمایندگی</a></html>',410);
        $row = DB::table('pages')->where('path', $path)->first();
        if (!$row) return response('<!doctype html><meta charset="utf-8"><h1>Page not found</h1>', 404)->header('Content-Type', 'text/html; charset=UTF-8');
        $requestedLocale = SiteLocale::resolve($request);
        $lang = SiteLocale::storageCode($requestedLocale);
        $contentLocale = SiteLocale::ENGLISH;
        $translationStatus = 'source';
        $html = $row->html;
        if ($requestedLocale === SiteLocale::DARI) {
            $localized = DB::table('component_localizations')->where('component_type', 'page')->where('component_key', $path)->where('locale', 'fa')->first();
            $translationStatus = $this->localizationStatus($localized, $this->sourceHash('page', $path), true);
            if ($this->canDisplayLocalization($translationStatus)) {
                $contentLocale = SiteLocale::DARI;
                $html = $localized->html;
                $title = e($localized->title);
                $html = preg_replace_callback('~(<title\\b[^>]*>).*?(</title>)~is', fn ($m) => $m[1] . $title . $m[2], $html, 1) ?? $html;
            }
        }
        if($path==='/site/search.htm'){
            // Existing result slots are filled by searchMarkup from OUR database.
            // Remove only the inherited search module, not the shared page initializer.
            $html=preg_replace('~define\("channel-content-[0-9]+",function\(require\)\s*\{.*?\}\);\s*seajs\.use\("channel-content-[0-9]+"\);~s','',$html);
        }
        if ($path === '/site/search.htm') \App\Support\FormValidation::enforce('search',$request);
        if ($path === '/site/search.htm' && $request->filled('keywords')) $html = $this->searchMarkup($html, (string) $request->query('keywords'), $lang);
        $settings = DB::table('settings')->where('key','not like','cms.page.%')->pluck('value', 'key')->all();
        $label = $contentLocale === SiteLocale::DARI
            ? ($settings['local_representative_title_fa'] ?? 'SHANTUI در افغانستان')
            : ($settings['local_representative_title_en'] ?? 'SHANTUI in Afghanistan');
        if ($label !== 'SHANTUI in Afghanistan') $html = str_replace('SHANTUI in Afghanistan', e($label), $html);
        $html = Dealership::apply($html, $path, $settings, $contentLocale === SiteLocale::DARI);
        $html = \App\Support\SiteContent::apply($html,$path,$settings,$contentLocale===SiteLocale::DARI);
        $html = \App\Support\PageRuntime::ensure($html, $path);
        $html = \App\Support\LocalMedia::html($html);
        $html = \App\Support\SiteContent::applyOverrides($html,$path,SiteLocale::storageCode($contentLocale));
        $html = $this->setDocumentLocale($html, $requestedLocale, $contentLocale, $translationStatus);
        return response($html, 200)->header('Content-Type', 'text/html; charset=UTF-8')->header('Cache-Control', 'no-store')
            ->header('Content-Language', $contentLocale)
            ->header('X-Requested-Locale', $requestedLocale)
            ->header('X-Content-Locale', $contentLocale)
            ->header('X-Translation-Status', $translationStatus)
            ->withCookie(cookie('shantui_lang', $requestedLocale, 60 * 24 * 30, '/', null, $request->isSecure(), false, false, 'Lax'));
    }

    public function pageRoute(Request $request, ?string $path = null)
    {
        $path = '/' . ltrim((string) $path, '/');
        return $this->render($request, $path);
    }

    public function routesList()
    {
        if(config('shantui.managed_content_enabled'))return \App\Models\ManagedPage::where('locale',SiteLocale::storageCode(SiteLocale::resolve(request())))->where('status','published')->where('kind','!=','fragment')->orderBy('path')->get(['path','title']);
        $settings = DB::table('settings')->where('key','not like','cms.page.%')->pluck('value','key')->all();
        return response()->json(DB::table('pages')->select('path', 'title')->orderBy('path')->get()->reject(fn($page)=>Dealership::unavailable($page->path,$settings))->values());
    }

    public function health() { return response()->json(['ok' => true, 'framework' => 'Laravel', 'database' => 'SQLite']); }

    private function searchMarkup(string $source, string $term, string $lang): string
    {
        $term = mb_substr(trim($term), 0, 120);
        if ($term === '') return $source;
        $terms = [mb_strtolower($term)];
        $results = [];
        $plain=function(string $html): string {
            if(preg_match('~<section\b[^>]*class=["\'][^"\']*\bchannel_content\b[^"\']*["\'][^>]*>(.*)</section>~is',$html,$match))$html=$match[1];
            $html=preg_replace('~<(script|style)\b[^>]*>.*?</\1>~is','',$html);
            return html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8');
        };
        $dealerSettings = DB::table('settings')->where('key','not like','cms.page.%')->pluck('value','key')->all();
        $localizations = DB::table('component_localizations')->where('component_type', 'page')->where('locale', 'fa')->get()->keyBy('component_key');
        foreach (DB::table('pages')->select('path', 'title', 'html')->where('path', '<>', '/site/search.htm')->orderBy('path')->cursor() as $page) {
            if (Dealership::unavailable($page->path,$dealerSettings)) continue;
            $localized = $localizations->get($page->path);
            $status = $this->localizationStatus($localized, hash('sha256', (string) $page->title . chr(0) . (string) $page->html), true);
            $sourcePlain = $plain($page->html);
            $localizedPlain = $this->canDisplayLocalization($status) ? $plain((string)$localized->html) : '';
            $localizedTitle = $this->canDisplayLocalization($status) ? (string) $localized->title : '';
            $folded = mb_strtolower($page->title . ' ' . $sourcePlain . ' ' . $localizedTitle . ' ' . $localizedPlain);
            $hits = 0;
            foreach ($terms as $t) if ($t !== '' && str_contains($folded, $t)) $hits += substr_count($folded, $t) + (str_contains(mb_strtolower($localizedTitle . ' ' . $page->title), $t) ? 5 : 0);
            if ($hits) {
                $displayTitle = $lang === 'fa' && $this->canDisplayLocalization($status) ? $localizedTitle : $page->title;
                $results[] = ['score' => $hits, 'path' => $page->path, 'title' => $displayTitle, 'translation_status' => $lang === 'fa' ? $status : 'source'];
            }
        }
        foreach(\App\Support\SiteContent::collection('news',$dealerSettings) as $story){
            if(!($story['published']??false)||($story['date']??'')>now('Asia/Kabul')->toDateString())continue;
            $haystack=mb_strtolower(implode(' ',array_map(fn($key)=>(string)($story[$key]??''),['title_fa','title_en','summary_fa','summary_en','body_fa','body_en'])));
            $score=substr_count($haystack,mb_strtolower($term));if($score)$results[]=['score'=>$score+5,'path'=>'/news/news-center.htm','anchor'=>'local-news-'.$story['id'],'title'=>($story['title_'.($lang==='fa'?'fa':'en')]??'')?:$story['title_fa'],'translation_status'=>'source','owned_news'=>true];
        }
        usort($results, fn ($a, $b) => $b['score'] <=> $a['score'] ?: strcmp($a['path'], $b['path']));
        $results = array_slice($results, 0, 60);
        $groups = ['product' => [], 'news' => [], 'case' => [], 'channel' => []];
        foreach ($results as $result) {
            $p = $result['path'];
            $group = str_starts_with($p, '/product/') ? 'product' : (str_starts_with($p, '/news/') ? 'news' : (str_starts_with($p, '/case/') ? 'case' : 'channel'));
            $title = $result['title'];
            $href = '/api/site/render?' . http_build_query(['path' => $p, 'lang' => $lang]).(isset($result['anchor'])?'#'.rawurlencode($result['anchor']):'');
            $status = $result['translation_status'];
            $fallbackLabel = $lang === 'fa' && empty($result['owned_news']) && !$this->canDisplayLocalization($status) ? ' <small class="translation-incomplete" title="' . e(__('search.incomplete')) . '">' . e(__('search.incomplete')) . '</small>' : '';
            $groups[$group][] = '<li data-translation-status="' . e($status) . '"><a href="' . e($href) . '"><span class="t">' . e($title) . '</span>' . $fallbackLabel . '</a></li>';
        }
        $values = ['keyword' => e($term), 'resultNum' => (string) count($results), 'productList' => implode('', $groups['product']), 'newList' => implode('', $groups['news']), 'caseList' => implode('', $groups['case']), 'channelList' => implode('', $groups['channel'])];
        foreach ($values as $id => $value) {
            $tag = in_array($id, ['keyword', 'resultNum'], true) ? 'span' : 'ul';
            $pattern = '~(<'.$tag.'\b[^>]*\bid=["\']'.preg_quote($id, '~').'["\'][^>]*>).*?(</'.$tag.'>)~is';
            $source = preg_replace_callback($pattern, fn ($m) => $m[1] . $value . $m[2], $source, 1) ?? $source;
        }
        $labels = ['product' => __('search.product'), 'news' => __('search.news'), 'case' => __('search.case'), 'channel' => __('search.information')];
        foreach ($labels as $group => $label) {
            $pattern = '~(<h3\b[^>]*\bid=["\']'.preg_quote($group, '~').'["\'][^>]*>).*?(</h3>)~is';
            $source = preg_replace_callback($pattern, fn ($m) => $m[1] . e($label) . '（' . count($groups[$group]) . '）' . $m[2], $source, 1) ?? $source;
        }
        $source = str_replace('class="content_form" style="display: none"', 'class="content_form" style="display: block"', $source);
        foreach (['product' => 'content_product', 'news' => 'content_news', 'case' => 'content_case', 'channel' => 'content_mess'] as $group => $class) {
            if (!$groups[$group]) {
                $pattern = '~(<div\b[^>]*class=["\'][^"\']*\b'.preg_quote($class, '~').'\b[^"\']*["\'][^>]*)(>)~i';
                $source = preg_replace($pattern, '$1 style="display:none"$2', $source, 1) ?? $source;
            }
        }
        return $source;
    }

    public function login(Request $request)
    {
if(config('shantui.managed_identity_enabled'))return \App\Support\AdminIdentity::login($request);
        \App\Support\FormValidation::enforce('login',$request);
        $data = $request->validate(['email' => ['required', 'email'], 'password' => ['required', 'string', 'max:500']]);
        $expectedEmail = (string) config('shantui.admin_email');
        $expectedPassword = (string) config('shantui.admin_password');
        if (!\App\Http\Middleware\AdminApiAuth::keyConfigured()) return response()->json(['error'=>'authentication_not_configured'],503);
        if (app()->environment('production') && ($expectedPassword === 'ChangeThis-2026!' || strlen($expectedPassword) < 14 || str_contains((string) config('app.key'), 'base64:YourKeyHere'))) return response()->json(['error' => 'production_credentials_not_configured'], 503);
        $validPassword = str_starts_with($expectedPassword, '$2y$') ? Hash::check($data['password'], $expectedPassword) : hash_equals($expectedPassword, $data['password']);
        if (!hash_equals($expectedEmail, $data['email']) || !$validPassword) return response()->json(['error' => 'invalid_credentials'], 401);
        $expires = (string) (time() + 8 * 60 * 60);
        $token = $expires . '.' . hash_hmac('sha256', $expires, (string) config('app.key'));
        return response()->json(['authenticated' => true])->withCookie(cookie('shantui_admin', $token, 480, '/', null, app()->environment('production') || $request->isSecure(), true, false, 'Lax'));
    }

    public function logout(Request $request)
    {
if(config('shantui.managed_identity_enabled'))return \App\Support\AdminIdentity::logout($request);
        return response()->json(['authenticated' => false])->withCookie(cookie()->forget('shantui_admin', '/'));
    }

    public function session(Request $request)
    {
if(config('shantui.managed_identity_enabled'))return \App\Support\AdminIdentity::session($request);
        $valid = \App\Http\Middleware\AdminApiAuth::validToken((string) $request->cookie('shantui_admin', ''));
        return response()->json(['authenticated' => $valid, 'email' => $valid ? config('shantui.admin_email') : null]);
    }

    public function pages(Request $request)
    {
        $query = DB::table('pages');
        if ($search = trim((string) $request->query('q', ''))) $query->where(fn ($q) => $q->where('path', 'like', '%' . $search . '%')->orWhere('title', 'like', '%' . $search . '%'));
        $items = $query->select('path', 'title', 'updated_at', DB::raw('length(html) as bytes'))->orderBy('path')->get();
        $localized = DB::table('component_localizations')->where('component_type', 'page')->where('locale', 'fa')->whereIn('component_key', $items->pluck('path'))->get()->keyBy('component_key');
        $sourcePages = $localized->isEmpty() ? collect() : DB::table('pages')->whereIn('path', $localized->keys())->get(['path', 'title', 'html'])->keyBy('path');
        $items->each(function ($item) use ($localized, $sourcePages) {
            $entry = $localized->get($item->path);
            $source = $entry ? $sourcePages->get($item->path) : null;
            $hash = $source ? hash('sha256', (string) $source->title . chr(0) . (string) $source->html) : null;
            $item->has_fa = $entry !== null;
            $item->translation_status = $this->localizationStatus($entry, $hash, true);
        });
        return response()->json($items);
    }

    public function getPage(Request $request)
    {
        $path = $this->safePath($request->query('path'));
        $page = $path ? DB::table('pages')->where('path', $path)->first() : null;
        if (!$page) return response()->json(['error' => 'page_not_found'], 404);
        $localized = DB::table('component_localizations')->where('component_type', 'page')->where('component_key', $path)->where('locale', 'fa')->first();
        $page->fa_title = $localized->title ?? '';
        $page->fa_html = $localized->html ?? '';
        $page->fa_status = $this->localizationStatus($localized, hash('sha256', (string) $page->title . chr(0) . (string) $page->html), true);
        $page->fa_reviewed_at = $localized->reviewed_at ?? null;
        return response()->json($page);
    }

    public function createPage(Request $request)
    {
        $data = $request->validate(['path' => ['required', 'string', 'max:500'], 'title' => ['required', 'string', 'max:240'], 'html' => ['required', 'string'], 'fa_title' => ['nullable', 'string', 'max:240'], 'fa_html' => ['nullable', 'string']]);
        $path = $this->safePath($data['path']);
        if (!$path || !preg_match('/\.(html?|htm)$/i', $path)) return response()->json(['error' => 'invalid_html_route'], 422);
        if (DB::table('pages')->where('path', $path)->exists()) return response()->json(['error' => 'page_exists'], 409);
        DB::transaction(function () use ($data, $path) {
            DB::table('pages')->insert(['path' => $path, 'title' => $data['title'], 'html' => $data['html'], 'updated_at' => $this->now()]);
            if (trim((string) ($data['fa_html'] ?? '')) !== '' || trim((string) ($data['fa_title'] ?? '')) !== '') $this->saveFaComponent('page', $path, $data['fa_title'] ?? null, $data['fa_html'] ?? '');
        });
        return response()->json(['saved' => true, 'path' => $path], 201);
    }

    public function updatePage(Request $request)
    {
        $data = $request->validate(['path' => ['required', 'string'], 'title' => ['required', 'string', 'max:240'], 'html' => ['required', 'string'], 'fa_title' => ['sometimes', 'nullable', 'string', 'max:240'], 'fa_html' => ['sometimes', 'nullable', 'string'], 'fa_status' => ['sometimes', Rule::in(['draft', 'needs_review', 'approved'])]]);
        $path = $this->safePath($data['path']);
        if (!$path) return response()->json(['error' => 'invalid_path'], 422);
        if (!DB::table('pages')->where('path', $path)->exists()) return response()->json(['error' => 'page_not_found'], 404);
        DB::transaction(function () use ($data, $path) {
            DB::table('pages')->where('path', $path)->update(['title' => $data['title'], 'html' => $data['html'], 'updated_at' => $this->now()]);
            if (array_key_exists('fa_html', $data) || array_key_exists('fa_title', $data) || array_key_exists('fa_status', $data)) {
                $existing = DB::table('component_localizations')->where('component_type', 'page')->where('component_key', $path)->where('locale', 'fa')->first();
                $faTitle = array_key_exists('fa_title', $data) ? (string) ($data['fa_title'] ?? '') : ($existing?->title ?? null);
                $faHtml = array_key_exists('fa_html', $data) ? (string) ($data['fa_html'] ?? '') : ($existing?->html ?? '');
                $changed = $faTitle !== ($existing?->title ?? null) || $faHtml !== ($existing?->html ?? '');
                if ($changed || array_key_exists('fa_status', $data)) {
                    $status = $data['fa_status'] ?? ($changed ? 'needs_review' : ($existing?->status ?? 'needs_review'));
                    $this->saveFaComponent('page', $path, $faTitle, $faHtml, $status);
                }
            }
        });
        return response()->json(['saved' => true]);
    }

    public function deletePage(Request $request)
    {
        $path = $this->safePath((string) ($request->query('path') ?: $request->input('path')));
        if (!$path) return response()->json(['error' => 'invalid_path'], 422);
        $deleted = DB::table('pages')->where('path', $path)->delete();
        if ($deleted) DB::table('component_localizations')->where('component_type', 'page')->where('component_key', $path)->delete();
        return $deleted ? response()->json(['deleted' => true]) : response()->json(['error' => 'page_not_found'], 404);
    }

    public function translations(Request $request)
    {
        $query = DB::table('translations');
        if ($term = trim((string) $request->query('q', ''))) $query->where(fn ($q) => $q->where('source', 'like', '%' . $term . '%')->orWhere('translated', 'like', '%' . $term . '%'));
        $total = (clone $query)->count();
        $limit = min(2000, max(1, (int) $request->query('limit', 1000)));
        $offset = max(0, (int) $request->query('offset', 0));
        return response()->json(['total' => $total, 'items' => $query->orderBy('source')->offset($offset)->limit($limit)->get()]);
    }

    public function saveTranslation(Request $request)
    {
        $data = $request->validate(['source' => ['required', 'string', 'max:1500'], 'translated' => ['required', 'string', 'max:6000']]);
        DB::table('translations')->updateOrInsert(['source' => $data['source']], ['translated' => $data['translated'], 'updated_at' => $this->now()]);
        return response()->json(['saved' => true]);
    }

    public function deleteTranslation(Request $request)
    {
        $source = (string) ($request->query('source') ?: $request->input('source'));
        if ($source === '') return response()->json(['error' => 'source_required'], 422);
        $deleted = DB::table('translations')->where('source', $source)->delete();
        return $deleted ? response()->json(['deleted' => true]) : response()->json(['error' => 'translation_not_found'], 404);
    }

    public function settings()
    {
        return response()->json(DB::table('settings')->where('key','not like','cms.%')->pluck('value', 'key')->all());
    }

    public function saveSetting(Request $request)
    {
        $data = $request->validate(['key' => ['required', 'string', 'max:120'], 'value' => ['present']]);
        if(str_starts_with($data['key'],'cms.'))return response()->json(['message'=>'برای این محتوا از بخش اختصاصی مدیریت استفاده کنید.'],422);
        DB::table('settings')->updateOrInsert(['key' => $data['key']], ['value' => (string) $data['value'], 'updated_at' => $this->now()]);
        return response()->json(['saved' => true]);
    }

    public function saveDealerProfile(Request $request)
    {
        $data = $request->validate(['settings'=>['required','array']]);
        $data['settings']=array_map(fn($value)=>$value===null?'':$value,$data['settings']);
        $allowed = config('dealership.fields');
        foreach($data['settings'] as $key=>$value){
            if(!isset($allowed[$key]) || !is_string($value) || mb_strlen($value)>5000) return response()->json(['error'=>'invalid_dealer_profile'],422);
            if(($key==='dealer.logo'||str_starts_with($key,'dealer.social.')) && $value!=='' && !preg_match('~^(?:/(?!/)|https://)~i',$value)) return response()->json(['error'=>'invalid_dealer_url'],422);
            if($key==='dealer.email' && !filter_var($value,FILTER_VALIDATE_EMAIL)) return response()->json(['error'=>'invalid_dealer_email'],422);
        }
        DB::transaction(function()use($data){foreach($data['settings'] as $key=>$value)DB::table('settings')->updateOrInsert(['key'=>$key],['value'=>$value,'updated_at'=>$this->now()]);});
        return response()->json(['saved'=>true]);
    }

    public function deleteSetting(Request $request)
    {
        $key = (string) ($request->query('key') ?: $request->input('key'));
        if(str_starts_with($key,'cms.'))return response()->json(['message'=>'برای این محتوا از بخش اختصاصی مدیریت استفاده کنید.'],422);
        if ($key === '') return response()->json(['error' => 'key_required'], 422);
        $deleted = DB::table('settings')->where('key', $key)->delete();
        return $deleted ? response()->json(['deleted' => true]) : response()->json(['error' => 'setting_not_found'], 404);
    }

    public function fragments(Request $request)
    {
        $query = DB::table('fragments');
        if ($request->filled('kind')) $query->where('kind', $request->query('kind'));
        if ($term = trim((string) $request->query('q', ''))) $query->where(fn ($q) => $q->where('kind', 'like', '%' . $term . '%')->orWhere('flag', 'like', '%' . $term . '%')->orWhere('filters', 'like', '%' . $term . '%'));
        $items = $query->select('id', 'kind', 'channel_id', 'flag', 'filters', 'updated_at', DB::raw('length(html) as chars'))->orderBy('kind')->orderBy('channel_id')->orderBy('flag')->orderBy('filters')->get();
        $localized = DB::table('component_localizations')->where('component_type', 'fragment')->where('locale', 'fa')->whereIn('component_key', $items->pluck('id')->map(fn ($id) => (string) $id))->get()->keyBy('component_key');
        $sourceFragments = $localized->isEmpty() ? collect() : DB::table('fragments')->whereIn('id', $localized->keys())->get(['id', 'html'])->keyBy(fn ($row) => (string) $row->id);
        $items->each(function ($item) use ($localized, $sourceFragments) {
            $entry = $localized->get((string) $item->id);
            $source = $entry ? $sourceFragments->get((string) $item->id) : null;
            $item->has_fa = $entry !== null;
            $item->translation_status = $this->localizationStatus($entry, $source ? hash('sha256', (string) $source->html) : null);
        });
        return response()->json($items);
    }

    public function getFragment(Request $request)
    {
        $item = DB::table('fragments')->where('id', (int) $request->query('id'))->first();
        if (!$item) return response()->json(['error' => 'fragment_not_found'], 404);
        $localized = DB::table('component_localizations')->where('component_type', 'fragment')->where('component_key', (string) $item->id)->where('locale', 'fa')->first();
        $item->fa_title = $localized->title ?? '';
        $item->fa_html = $localized->html ?? '';
        $item->fa_status = $this->localizationStatus($localized, hash('sha256', (string) $item->html));
        $item->fa_reviewed_at = $localized->reviewed_at ?? null;
        return response()->json($item);
    }

    public function createFragment(Request $request)
    {
        $data = $request->validate(['kind' => ['required', 'in:news,home,product,parts,video'], 'channel_id' => ['nullable', 'string', 'max:64'], 'flag' => ['required', 'string', 'max:64'], 'filters' => ['nullable'], 'html' => ['required', 'string'], 'fa_title' => ['nullable', 'string', 'max:240'], 'fa_html' => ['nullable', 'string']]);
        $filters = $data['filters'] ?? [];
        if (is_string($filters)) $filters = json_decode($filters, true) ?? [];
        if (!is_array($filters)) return response()->json(['error' => 'filters_must_be_object'], 422);
        ksort($filters);
        try {
            $id = DB::transaction(function () use ($data, $filters) {
                $id = DB::table('fragments')->insertGetId(['kind' => $data['kind'], 'channel_id' => $data['channel_id'] ?? '', 'flag' => $data['flag'], 'filters' => json_encode($filters, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 'html' => $data['html'], 'updated_at' => $this->now()]);
                if (trim((string) ($data['fa_html'] ?? '')) !== '' || trim((string) ($data['fa_title'] ?? '')) !== '') $this->saveFaComponent('fragment', (string) $id, $data['fa_title'] ?? null, $data['fa_html'] ?? '');
                return $id;
            });
            return response()->json(['saved' => true, 'id' => $id], 201);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['error' => 'fragment_already_exists'], 409);
        }
    }

    public function updateFragment(Request $request)
    {
        $data = $request->validate(['id' => ['required', 'integer'], 'html' => ['required', 'string'], 'fa_title' => ['sometimes', 'nullable', 'string', 'max:240'], 'fa_html' => ['sometimes', 'nullable', 'string'], 'fa_status' => ['sometimes', Rule::in(['draft', 'needs_review', 'approved'])]]);
        $fragment = DB::table('fragments')->where('id', $data['id'])->first();
        if (!$fragment) return response()->json(['error' => 'fragment_not_found'], 404);
        DB::transaction(function () use ($data) {
            DB::table('fragments')->where('id', $data['id'])->update(['html' => $data['html'], 'updated_at' => $this->now()]);
            if (array_key_exists('fa_html', $data) || array_key_exists('fa_title', $data) || array_key_exists('fa_status', $data)) {
                $existing = DB::table('component_localizations')->where('component_type', 'fragment')->where('component_key', (string) $data['id'])->where('locale', 'fa')->first();
                $faTitle = array_key_exists('fa_title', $data) ? (string) ($data['fa_title'] ?? '') : ($existing?->title ?? null);
                $faHtml = array_key_exists('fa_html', $data) ? (string) ($data['fa_html'] ?? '') : ($existing?->html ?? '');
                $changed = $faTitle !== ($existing?->title ?? null) || $faHtml !== ($existing?->html ?? '');
                if ($changed || array_key_exists('fa_status', $data)) {
                    $status = $data['fa_status'] ?? ($changed ? 'needs_review' : ($existing?->status ?? 'needs_review'));
                    $this->saveFaComponent('fragment', (string) $data['id'], $faTitle, $faHtml, $status);
                }
            }
        });
        return response()->json(['saved' => true]);
    }

    public function deleteFragment(Request $request)
    {
        $id = (int) ($request->query('id') ?: $request->input('id'));
        $deleted = DB::table('fragments')->where('id', $id)->delete();
        if ($deleted) DB::table('component_localizations')->where('component_type', 'fragment')->where('component_key', (string) $id)->delete();
        return $deleted ? response()->json(['deleted' => true]) : response()->json(['error' => 'fragment_not_found'], 404);
    }

    public function requests(Request $request)
    {
        $limit = min(1000, max(1, (int) $request->query('limit', 200)));
        $items = DB::table('requests')->orderByDesc('id')->limit($limit)->get()->map(function ($row) {
            $row->payload = json_decode($row->payload, true) ?: [];
            return $row;
        });
        return response()->json($items);
    }

    public function updateRequest(Request $request, int $id)
    {
        $data = $request->validate(['status' => ['required', Rule::in(['new','reviewed','closed'])]]);
        $updated = DB::table('requests')->where('id', $id)->update(['status' => $data['status']]);
        return $updated ? response()->json(['saved' => true]) : response()->json(['error' => 'request_not_found'], 404);
    }

    public function deleteRequest(int $id)
    {
        $deleted = DB::table('requests')->where('id', $id)->delete();
        return $deleted ? response()->json(['deleted' => true]) : response()->json(['error' => 'request_not_found'], 404);
    }

    public function upload(Request $request)
    {
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $request->validate(['file'=>['required','file','mimetypes:image/jpeg,image/png,image/webp,image/gif,application/pdf,video/mp4','max:131072']]);
            $mime=$file->getMimeType();
            $types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','application/pdf'=>'pdf','video/mp4'=>'mp4'];
            $limit=$mime==='video/mp4'?128*1024*1024:($mime==='application/pdf'?50*1024*1024:8*1024*1024);
            if($file->getSize()>$limit)return response()->json(['error'=>'invalid_or_large_file'],422);
            // Never trust the client's filename extension (e.g. a JPEG named .php).
            $ext=$types[$mime];
            $dir = 'uploads/' . now()->format('Y/m');
            $name = Str::uuid()->toString() . '.' . $ext;
            $destination = $this->sitePublicPath($dir);
            if (!is_dir($destination)) mkdir($destination, 0755, true);
            $file->move($destination, $name);
            return response()->json(['path' => '/' . $dir . '/' . $name], 201);
        }
        $data = $request->validate(['content_type' => ['required', 'in:image/jpeg,image/png,image/webp,image/gif'], 'data' => ['required', 'string', 'max:12000000']]);
        $bytes = base64_decode($data['data'], true);
        if ($bytes === false || strlen($bytes) > 8 * 1024 * 1024) return response()->json(['error' => 'invalid_or_large_file'], 422);
        $imageInfo = @getimagesizefromstring($bytes);
        if (!$imageInfo || ($imageInfo['mime'] ?? '') !== $data['content_type']) return response()->json(['error' => 'upload_is_not_a_matching_image'], 422);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$data['content_type']];
        $relative = 'uploads/' . now()->format('Y/m');
        $dir = $this->sitePublicPath($relative);
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $name = Str::uuid()->toString() . '.' . $ext;
        file_put_contents($dir . '/' . $name, $bytes);
        return response()->json(['path' => '/' . $relative . '/' . $name], 201);
    }

    public function media(Request $request)
    {
        $files = [];
        $root = $this->sitePublicPath('uploads');
        if (is_dir($root)) {
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
            foreach ($iterator as $item) {
                if (!$item->isFile()) continue;
                $full = $item->getPathname();
                $files[] = ['path' => '/' . str_replace('\\', '/', substr($full, strlen($this->sitePublicPath()) + 1)), 'bytes' => $item->getSize(), 'modified' => date(DATE_ATOM, $item->getMTime())];
            }
        }
        if($request->boolean('include_catalogue')){
            $manifestFile=base_path('../data/self-hosted-media.json');$manifest=is_file($manifestFile)?json_decode(file_get_contents($manifestFile),true):[];
            foreach($manifest as $path=>$entry)$files[]=['path'=>$path,'bytes'=>$entry['bytes'],'modified'=>'','mime'=>$entry['mime'],'catalogue'=>true,'read_only'=>true];
        }
        usort($files, fn ($a, $b) => strcmp($b['modified'], $a['modified']));
        return response()->json(array_slice($files, 0, min(2000, max(1, (int) $request->query('limit', 500)))));
    }

    public function deleteMedia(Request $request)
    {
        $relative = ltrim((string) ($request->query('path') ?: $request->input('path')), '/');
        if (!str_starts_with($relative, 'uploads/') || str_contains($relative, '..')) return response()->json(['error' => 'invalid_media_path'], 422);
        $target = realpath($this->sitePublicPath($relative));
        $root = realpath($this->sitePublicPath('uploads'));
        if (!$target || !$root || !str_starts_with($target, $root . DIRECTORY_SEPARATOR) || !is_file($target)) return response()->json(['error' => 'media_not_found'], 404);
        unlink($target);
        return response()->json(['deleted' => true]);
    }

    public function submitInquiry(Request $request)
    {
        if(count($request->all())>40 || strlen($request->getContent())>32768)return response()->json(['error'=>'inquiry_too_large'],422);
        $kind=\App\Support\FormValidation::inquiryKind($request->all());
        if(!in_array($kind,['contact_message','generic_inquiry','product_inquiry','brochure','service_inquiry','parts_inquiry','distributor_inquiry','legacy_message'],true))throw \Illuminate\Validation\ValidationException::withMessages(['form_type'=>['Invalid form type.']]);
        \App\Support\FormValidation::enforce($kind,$request);
        if($request->input('form_type')==='contact_message')$request->validate([
            'name'=>'required|string|max:120','phone'=>['nullable','string','regex:/^\+?[\p{N} ()-]{7,25}$/u'],'email'=>'nullable|email|max:180',
            'subject'=>'nullable|string|max:160','message'=>'required|string|min:5|max:5000','consent'=>'accepted',
            'source_page'=>'required|in:/about/about-us.htm,/about/contact-us.htm','branch_id'=>'nullable|string|max:80'
        ]);
        if ($request->input('form_type') === 'contact_message' && $request->filled('branch_id')) {
            $activeIds = array_column(array_filter(\App\Support\SiteContent::collection('branches'), fn ($branch) => $branch['published'] ?? false), 'id');
            if (!in_array($request->input('branch_id'), $activeIds, true)) {
                return response()->json(['error'=>'invalid_branch','message'=>app()->getLocale()==='fa'?'دفتر انتخاب‌شده فعال نیست؛ صفحه را دوباره باز کنید.':'The selected office is unavailable. Please reload the page.'], 422);
            }
        }
        $payload = $request->all();
        if (count($payload)>40 || strlen($request->getContent())>32768) return response()->json(['error'=>'inquiry_too_large'],422);
        if (!empty($payload['website'])) return response()->json(['error'=>'invalid_inquiry'],422);
        unset($payload['website']);
        foreach($payload as $key=>$value) {
            if (!is_scalar($value) && $value!==null) return response()->json(['error'=>'invalid_inquiry_fields'],422);
            if (mb_strlen((string)$value)>5000) return response()->json(['error'=>'inquiry_field_too_long'],422);
            $payload[$key]=\App\Support\FormValidation::trim((string)$value);
        }
        $contact=false;
        foreach(['email','phone','telephone','obj.email','obj.telephone','obj.field2','obj.field3','obj.field4'] as $key) {
            $value=$payload[$key]??'';
            if(filter_var($value,FILTER_VALIDATE_EMAIL) || preg_match('/^\+?[\p{N} ()-]{7,25}$/u',$value))$contact=true;
        }
        if(!$contact) return response()->json(['error'=>'contact_required'],422);
        if(config('shantui.managed_inquiries_enabled'))return \App\Support\InquiryStore::store($request,$payload);
        $id=DB::table('requests')->insertGetId(['created_at'=>$this->now(),'payload'=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'status'=>'new']);
        $notification='disabled';
        if(config('shantui.inquiry_email_enabled') && filter_var(config('shantui.inquiry_email_to'),FILTER_VALIDATE_EMAIL)) {
            try { \Illuminate\Support\Facades\Mail::to(config('shantui.inquiry_email_to'))->send(new \App\Mail\InquiryReceived($id,$payload));$notification='sent'; }
            catch(\Throwable $e) { $notification='failed';\Illuminate\Support\Facades\Log::warning('Inquiry notification failed',['request_id'=>$id]); }
        }
        return response()->json(['stored'=>true,'id'=>$id,'notification'=>$notification],201);
    }

    public function newsletter(Request $request)
    {
        if(!is_string($request->input('email')))return response('notemail',200)->header('Content-Type','text/plain; charset=UTF-8');
        $email = mb_strtolower(\App\Support\FormValidation::trim($request->input('email', '')));
        if (\App\Support\FormValidation::errors('newsletter',['email'=>$email]) || !filter_var($email, FILTER_VALIDATE_EMAIL)) return response('notemail', 200)->header('Content-Type', 'text/plain; charset=UTF-8');
        $exists = DB::table('requests')->where('payload', 'like', '%"type":"newsletter"%')->where('payload', 'like', '%"email":"' . $email . '"%')->exists();
        if ($exists) return response('exit', 200)->header('Content-Type', 'text/plain; charset=UTF-8');
        DB::table('requests')->insert(['created_at' => $this->now(), 'payload' => json_encode(['type' => 'newsletter', 'email' => $email], JSON_UNESCAPED_UNICODE), 'status' => 'new']);
        return response('ok', 200)->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    public function fragmentResponse(string $kind, Request $request)
    {
if(config('shantui.managed_catalogue_enabled')&&in_array($kind,['product','parts'])&&$request->input('flag')==='getData')return app(\App\Http\Controllers\CatalogueFragmentController::class)->render($kind,$request);
        if(config('shantui.managed_catalogue_enabled')&&$kind==='product'&&$request->input('flag')==='param'&&$request->filled('channelId'))return app(\App\Http\Controllers\CatalogueFragmentController::class)->params($request);
        $data = $request->all();
        $flag = (string) ($data['flag'] ?? '');
        $channel = in_array($kind, ['news','parts'], true) || ($kind === 'product' && $flag === 'getData') ? (string) ($data['channelId'] ?? '') : ($kind==='video'?(string)($data['parentId']??''):'');
        $keys = match ($kind) {
            'parts' => ['catId'],
            'video' => ['catId','key'],
            'case' => ['pro', 'solu', 'key'],
            'news' => $flag === 'getData' ? ['key', 'year'] : [],
            'home' => $flag === 'newsKeyList' ? ['data'] : [],
            'product' => $flag === 'getData' ? ['channelId', 'parentId', 'catId', 'attr01', 'attr02', 'attr03', 'xz01', 'xz02', 'xz03', 'nowPage'] : ($flag === 'param' ? ['parentId', 'catId'] : []),
            default => [],
        };
        $filters = [];
        foreach ($keys as $key) $filters[$key] = (string) ($data[$key] ?? '');
        ksort($filters);
        $base = DB::table('fragments')->where('kind', $kind)->where('channel_id', $channel)->where('flag', $flag);
        $find = fn (array $f) => (clone $base)->where('filters', json_encode((object) $f, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))->first(['id', 'html'])
            ?? (!$f ? (clone $base)->where('filters', '[]')->first(['id', 'html']) : null);
        $match = $find($filters);
        $payload = $match?->html;
        if ($payload === null && $flag === 'getData') {
            $candidates = [];
            if ($kind === 'news') $candidates = [['key' => '', 'year' => (string) ($filters['year'] ?? '')], ['key' => '', 'year' => '']];
            elseif ($kind === 'case') $candidates = [['pro' => $filters['pro'] ?? '', 'solu' => $filters['solu'] ?? '', 'key' => ''], ['pro' => '', 'solu' => '', 'key' => '']];
            elseif ($kind === 'product') {
                $first = $filters; $first['nowPage'] = ''; ksort($first); $candidates[] = $first;
                $second = $first; foreach (['attr01', 'attr02', 'attr03', 'xz01', 'xz02', 'xz03'] as $k) $second[$k] = ''; ksort($second); $candidates[] = $second;
                if (!empty($second['catId'])) { $third = $second; $third['catId'] = ''; ksort($third); $candidates[] = $third; }
            }
            foreach ($candidates as $candidate) { ksort($candidate); $match = $find($candidate); if ($match !== null) { $payload = $match->html; break; } }
            if ($payload === null && $kind === 'news') { $match = $base->orderBy('id')->first(['id', 'html']); $payload = $match?->html; }
        }
        if($payload===null && $kind==='video'){$match=$find(['catId'=>(string)($filters['catId']??''),'key'=>'']);$payload=$match?->html;}
        if ($payload === null && $kind === 'product' && $flag === 'param') { $match = $find(['catId' => '', 'parentId' => (string) ($filters['parentId'] ?? '')]); $payload = $match?->html; }
        $requestedLocale = SiteLocale::normalize(isset($data['lang']) ? (string) $data['lang'] : null) ?? SiteLocale::resolve($request);
        $contentLocale = SiteLocale::ENGLISH;
        $translationStatus = 'source';
        if ($requestedLocale === SiteLocale::DARI && $match) {
            $localized = DB::table('component_localizations')->where('component_type', 'fragment')->where('component_key', (string) $match->id)->where('locale', 'fa')->first();
            $translationStatus = $this->localizationStatus($localized, hash('sha256', (string) $match->html));
            if ($this->canDisplayLocalization($translationStatus)) {
                $payload = $localized->html;
                $contentLocale = SiteLocale::DARI;
            }
        }
        if(config('shantui.managed_content_enabled')){
            $localizedPage=$match?\App\Models\ManagedPage::where('locale',SiteLocale::storageCode($requestedLocale))->where('path','fragment:'.$match->id)->where('status','published')->first():null;
            $payload=$localizedPage?\App\Support\ManagedPublishing::html($localizedPage):'<div class="global-data-empty"></div>';
            $contentLocale=$requestedLocale;
        }
        if($kind==='video' && trim((string)($filters['key']??''))!=='' && $payload){
            $needle=mb_strtolower(mb_substr((string)$filters['key'],0,120));$d=new \DOMDocument();@$d->loadHTML('<?xml encoding="UTF-8">'.$payload);$x=new \DOMXPath($d);
            foreach(iterator_to_array($x->query('//li')) as $li)if(!str_contains(mb_strtolower($li->textContent),$needle))$li->parentNode?->removeChild($li);
            $payload=$d->saveHTML();
        }
        if(!config('shantui.managed_content_enabled')) $payload = \App\Support\DisplayReview::fragment($payload ?? '<div class="global-data-empty"></div>', $contentLocale === SiteLocale::DARI);
        return response(\App\Support\LocalMedia::html($payload), 200)->header('Content-Type', 'text/html; charset=UTF-8')->header('Cache-Control', 'no-store')
            ->header('Content-Language', $contentLocale)
            ->header('X-Requested-Locale', $requestedLocale)
            ->header('X-Content-Locale', $contentLocale)
            ->header('X-Translation-Status', $translationStatus);
    }

    /** Resolve the solution's category against the local canonical catalogue.
     * No invented cards, remote requests, content writes, or one-product fallback.
     */
    public function solutionProducts(Request $request)
    {
        $id = (string) $request->input('data', '');
        $empty = fn () => response('<ul class="catalogue-related-grid"></ul>')->header('Content-Type', 'text/html; charset=UTF-8')->header('Cache-Control', 'no-store');
        if (!preg_match('/^[0-9]{1,10}$/', $id)) return $empty();
        $category = null;
        foreach (DB::table('pages')->where('path', 'like', '/solution/solution-detail-%')->where('html', 'like', '%data-id="'.$id.'"%')->get(['html']) as $page) {
            $doc = new \DOMDocument(); @$doc->loadHTML('<?xml encoding="UTF-8">'.$page->html);
            $xpath = new \DOMXPath($doc);
            $tab = $xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," solu_detail03 ")]//a[@data-id="'.$id.'"]')->item(0);
            if ($tab) { $category = trim($tab->textContent); break; }
        }
        if (!$category) return $empty();
        $listing = DB::table('pages')->where('path', 'like', '/product/%')->where('path', 'not like', '%detail%')->where('title', 'like', $category.'-Shantui%')->first(['html']);
        if (!$listing) return $empty();
        $doc = new \DOMDocument(); @$doc->loadHTML($listing->html); $xpath = new \DOMXPath($doc);
        $channel = $xpath->query('//input[@id="channelId"]')->item(0)?->getAttribute('value');
        if (!$channel) return $empty();
        $cards = [];
        foreach (DB::table('fragments')->where('kind', 'product')->where('channel_id', $channel)->where('flag', 'getData')->orderBy('id')->get(['filters']) as $row) {
            $filters = json_decode($row->filters, true) ?: [];
            foreach (['catId','attr01','attr02','attr03','xz01','xz02','xz03'] as $key) if (($filters[$key] ?? '') !== '') continue 2;
            $filters['flag'] = 'getData';
            $filters['lang'] = $request->input('lang') ?: SiteLocale::resolve($request);
            $html = $this->fragmentResponse('product', Request::create('/ext/ajax_proList.jsp', 'POST', $filters))->getContent();
            $doc = new \DOMDocument(); @$doc->loadHTML('<?xml encoding="UTF-8">'.$html); $xpath = new \DOMXPath($doc);
            foreach ($xpath->query('//li[a[contains(@href,"/product/pro-detail-")]]') as $li) {
                $href = $xpath->query('./a[@href]', $li)->item(0)->getAttribute('href');
                $path = parse_url($href, PHP_URL_PATH);
                if (!isset($cards[$path]) && DB::table('pages')->where('path', $path)->exists()) $cards[$path] = $doc->saveHTML($li);
            }
        }
        $total = count($cards); $perPage = 12;
        $last = max(1, (int) ceil($total / $perPage));
        $page = max(1, min($last, (int) $request->input('page', 1)));
        $fa = SiteLocale::normalize((string) $request->input('lang')) === SiteLocale::DARI;
        $markup = '<ul class="catalogue-related-grid">'.implode('', array_slice(array_values($cards), ($page - 1) * $perPage, $perPage)).'</ul>';
        if ($last > 1) {
            $markup .= '<nav class="related-pagination" aria-label="'.($fa ? 'صفحه‌های محصولات مرتبط' : 'Related product pages').'">';
            if ($page > 1) $markup .= '<button type="button" data-related-page="'.($page - 1).'">'.($fa ? 'قبلی' : 'Previous').'</button>';
            $markup .= '<span>'. $page.' / '.$last.'</span>';
            if ($page < $last) $markup .= '<button type="button" data-related-page="'.($page + 1).'">'.($fa ? 'بعدی' : 'Next').'</button>';
            $markup .= '</nav>';
        }
        return response(\App\Support\LocalMedia::html($markup))->header('Content-Type', 'text/html; charset=UTF-8')->header('Cache-Control', 'no-store')->header('X-Total-Products', (string) $total);
    }

    public function downloadList(Request $request)
    {
        $raw=(string)$request->input('formatList','[]');
        if(strlen($raw)>4096)return response()->json([],422);
        $items=json_decode($raw,true);
        if(!is_array($items) || count($items)>20)return response()->json([],422);
        $urls=[];
        foreach($items as $item){
            $id=is_array($item)?(string)($item['id']??''):'';
            if(!preg_match('/^[0-9]{1,16}$/',$id))continue;
            $source=DB::table('pages')->where('path','like','/product/%')->where('html','like','%data-id="'.$id.'"%')->value('html');
            if(!$source)continue;
            $d=new \DOMDocument();@$d->loadHTML($source);$x=new \DOMXPath($d);
            $links=$x->query('//*[contains(concat(" ",normalize-space(@class)," ")," tc_down ")]//a[contains(@href,"filename=")]');
            if($links->length!==1)continue;
            parse_str(parse_url($links->item(0)->getAttribute('href'),PHP_URL_QUERY)??'',$query);$file=$query['filename']??'';
            if(preg_match('~^/upload/file/[a-zA-Z0-9/_%.-]+\.pdf$~',$file))$urls[$file]=['url'=>$file];
        }
        return response()->json(array_values($urls));
    }

    public function authCode()
    {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="90" height="34"><rect width="100%" height="100%" fill="#f5f5f5"/><text x="8" y="24" font-size="17" fill="#333">LOCAL</text></svg>';
        return response($svg)->header('Content-Type', 'image/svg+xml');
    }
}
