<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SiteSecurity
{
 public function handle(Request $request, Closure $next): Response
 {
  $reject = false;
  if (app()->environment('production') && in_array($request->method(),['POST','PUT','PATCH','DELETE'],true)) {
   $origin=$request->header('Origin');
   $normalize=static function(string $url): ?string {
    $parts=parse_url($url);
    if (!$parts || !isset($parts['scheme'],$parts['host']) || !in_array(strtolower($parts['scheme']),['http','https'],true) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) || !in_array($parts['path']??'', ['', '/'], true)) return null;
    $scheme=strtolower($parts['scheme']);
    return $scheme.'://'.strtolower($parts['host']).':'.($parts['port']??($scheme==='https'?443:80));
   };
   $allowed=array_filter([$normalize($request->getSchemeAndHttpHost()),$normalize((string) config('app.url'))]);
   $reject=$request->header('Sec-Fetch-Site')==='cross-site' || ($origin!==null && (!($normalized=$normalize($origin)) || !in_array($normalized,$allowed,true)));
  }
  $response=$reject?response()->json(['error'=>'cross_origin_write_rejected'],403):$next($request);
  $response->headers->set('X-Content-Type-Options','nosniff');
  $response->headers->set('Referrer-Policy','strict-origin-when-cross-origin');
  $response->headers->set('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  if ($request->is('api/admin/*','admin','admin/*')) {
   $response->headers->set('Cache-Control','no-store, private');
   $response->headers->set('X-Robots-Tag','noindex, nofollow');
  }
  if (app()->environment('production')) {
   // Inline scripts/eval are inherited; only owner-approved Google map frames may be external.
   $response->headers->set('Content-Security-Policy',"default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'self' ".($request->is('admin','admin/*')?'blob: ':'')."https://maps.google.com https://www.google.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
   $response->headers->set('X-Frame-Options','SAMEORIGIN');
   if ($request->isSecure()) $response->headers->set('Strict-Transport-Security','max-age=31536000');
  }
  return $response;
 }
}
