<?php

namespace App\Http\Middleware;

use App\Support\SiteLocale;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveSiteLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $locale = SiteLocale::resolve($request);
        $request->attributes->set('site_locale', $locale);
        app()->setLocale($locale);

        return $next($request);
    }
}
