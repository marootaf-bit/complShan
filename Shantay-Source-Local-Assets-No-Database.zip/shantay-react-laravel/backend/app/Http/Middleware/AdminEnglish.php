<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
final class AdminEnglish {
 public function handle(Request $r,Closure $next){if($r->is('api/admin/workspace/*')&&!config('shantui.managed_content_enabled'))abort(404);
  if(config('shantui.managed_inquiries_enabled')&&$r->is('api/admin/requests/*')&&!in_array($r->method(),['GET','HEAD']))return response()->json(['message'=>'Use the private inquiry tracker; destructive deletion is disabled.'],409);
  if($r->is('api/admin/*','admin','admin/*'))app()->setLocale('en');
  if(config('shantui.managed_content_enabled')&&$r->is('api/admin/*')&&in_array($r->method(),['POST','PUT','PATCH','DELETE'])&&!$r->is('api/admin/workspace/*','api/admin/login','api/admin/logout','api/admin/upload','api/admin/requests/*'))return response()->json(['message'=>'This legacy editor is read-only. Use the language-scoped workspace editor.'],409);return $next($r);}
}
