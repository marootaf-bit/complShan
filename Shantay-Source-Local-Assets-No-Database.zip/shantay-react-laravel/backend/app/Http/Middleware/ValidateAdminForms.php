<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use App\Support\FormValidation;
class ValidateAdminForms
{
 public function handle(Request $request,Closure $next){
  if(in_array($request->method(),['POST','PUT','PATCH'],true)){
   $kind=FormValidation::route($request->method(),'/'.$request->path());
   if($kind && !($kind==='image_upload'&&$request->hasFile('file')))FormValidation::enforce($kind,$request);
  }
  return $next($request);
 }
}
