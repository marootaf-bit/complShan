<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminApiAuth
{
    public static function keyConfigured(): bool
    {
        $key = (string) config('app.key');
        return strlen($key) >= 32 && !str_contains($key, 'YourKeyHere');
    }

    public static function validToken(string $token): bool
    {
        if (!self::keyConfigured()) return false;
        if(config('shantui.managed_identity_enabled'))return \App\Support\AdminIdentity::resolve($token)!==null;
        $parts = explode('.', $token, 2);
        if (count($parts) !== 2 || !ctype_digit($parts[0]) || strlen($parts[0]) > 12 || (int) $parts[0] < time()) return false;
        return hash_equals(hash_hmac('sha256', $parts[0], (string) config('app.key')), $parts[1]);
    }

    public function handle(Request $request, Closure $next): Response
    {
        if (!self::validToken((string) $request->cookie('shantui_admin', ''))) {
            return response()->json(['error' => 'authentication_required'], 401);
        }
        if(config('shantui.managed_identity_enabled')){$p=\App\Support\AdminIdentity::resolve((string)$request->cookie('shantui_admin'));if(!\App\Support\AdminIdentity::allowed($p,\App\Support\AdminIdentity::capability($request)))return response()->json(['error'=>'permission_denied'],403);if(!in_array($request->method(),['GET','HEAD','OPTIONS'])&&!\App\Support\AdminIdentity::csrfValid($request,$p))return response()->json(['error'=>'csrf_token_mismatch'],419);$request->attributes->set('admin_identity',$p);}
        return $next($request);
    }
}
