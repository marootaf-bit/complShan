<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('component_localizations')) return;

        Schema::table('component_localizations', function (Blueprint $table) {
            if (!Schema::hasColumn('component_localizations', 'status')) {
                $table->string('status', 24)->default('needs_review');
            }
            if (!Schema::hasColumn('component_localizations', 'source_hash')) {
                $table->char('source_hash', 64)->nullable();
            }
            if (!Schema::hasColumn('component_localizations', 'reviewed_at')) {
                $table->string('reviewed_at')->nullable();
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('component_localizations')) return;

        Schema::table('component_localizations', function (Blueprint $table) {
            $columns = [];
            foreach (['reviewed_at', 'source_hash', 'status'] as $column) {
                if (Schema::hasColumn('component_localizations', $column)) $columns[] = $column;
            }
            if ($columns !== []) $table->dropColumn($columns);
        });
    }
};
