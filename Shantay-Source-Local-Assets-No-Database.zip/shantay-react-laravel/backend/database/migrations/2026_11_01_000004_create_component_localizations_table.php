<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('component_localizations')) return;

        Schema::create('component_localizations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('component_type', 24);
            $table->string('component_key', 500);
            $table->string('locale', 8);
            $table->string('title', 240)->nullable();
            $table->longText('html');
            $table->string('updated_at');
            $table->unique(['component_type', 'component_key', 'locale'], 'component_localizations_unique');
        });
    }

    public function down(): void
    {
        // Keep bilingual content on rollback; the table is intentionally preserved.
    }
};
