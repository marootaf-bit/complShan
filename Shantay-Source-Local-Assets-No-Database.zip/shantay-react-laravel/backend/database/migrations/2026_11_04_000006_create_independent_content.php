<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('managed_pages',function(Blueprint $t){
   $t->id();$t->string('locale',5);$t->string('path',255);$t->string('title',500);$t->string('kind',30);$t->string('status',20)->default('draft');
   $t->longText('base_html');$t->longText('search_text');$t->text('draft_values')->default('{}');$t->text('published_values')->default('{}');$t->unsignedInteger('revision')->default(1);$t->string('source_status',30)->nullable();$t->string('source_sha256',64);$t->timestamps();$t->softDeletes();$t->unique(['locale','path']);$t->index(['locale','kind','status']);
  });
  Schema::create('managed_versions',function(Blueprint $t){$t->id();$t->foreignId('page_id')->constrained('managed_pages');$t->unsignedInteger('revision');$t->text('values');$t->string('action',30);$t->string('actor',180);$t->timestamps();});
  Schema::create('managed_audit',function(Blueprint $t){$t->id();$t->foreignId('page_id')->nullable()->constrained('managed_pages');$t->string('locale',5);$t->string('action',40);$t->string('actor',180);$t->text('metadata');$t->timestamps();});
 }
 public function down(): void {Schema::dropIfExists('managed_audit');Schema::dropIfExists('managed_versions');Schema::dropIfExists('managed_pages');}
};
