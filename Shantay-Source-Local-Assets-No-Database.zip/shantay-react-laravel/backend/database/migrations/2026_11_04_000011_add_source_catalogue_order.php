<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\{Schema,DB};
return new class extends Migration{public function up():void{Schema::table('catalogue_entries',fn(Blueprint $t)=>$t->unsignedInteger('source_position')->nullable());DB::table('catalogue_entries')->update(['source_position'=>DB::raw('published_position')]);}public function down():void{Schema::table('catalogue_entries',fn(Blueprint $t)=>$t->dropColumn('source_position'));}};
