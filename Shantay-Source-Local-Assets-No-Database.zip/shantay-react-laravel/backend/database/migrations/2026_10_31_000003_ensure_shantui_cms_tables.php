<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('pages')) Schema::create('pages', function (Blueprint $table) {
            $table->string('path')->primary();
            $table->string('title', 240);
            $table->longText('html');
            $table->string('updated_at');
        });
        if (!Schema::hasTable('translations')) Schema::create('translations', function (Blueprint $table) {
            $table->string('source', 1500)->primary();
            $table->text('translated');
            $table->string('updated_at');
        });
        if (!Schema::hasTable('settings')) Schema::create('settings', function (Blueprint $table) {
            $table->string('key', 120)->primary();
            $table->longText('value');
            $table->string('updated_at');
        });
        if (!Schema::hasTable('requests')) Schema::create('requests', function (Blueprint $table) {
            $table->increments('id');
            $table->string('created_at');
            $table->longText('payload');
            $table->string('status', 32)->default('new');
        });
        if (!Schema::hasTable('fragments')) Schema::create('fragments', function (Blueprint $table) {
            $table->increments('id');
            $table->string('kind', 32);
            $table->string('channel_id', 64)->default('');
            $table->string('flag', 64);
            $table->text('filters');
            $table->longText('html');
            $table->string('updated_at');
            $table->unique(['kind', 'channel_id', 'flag', 'filters'], 'fragments_unique_key');
        });
    }

    public function down(): void
    {
        // Existing mirrored-content tables are intentionally preserved on rollback.
    }
};
