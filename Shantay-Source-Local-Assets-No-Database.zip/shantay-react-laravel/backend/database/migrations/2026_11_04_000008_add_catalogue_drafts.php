<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{Schema::table('catalogue_entries',fn(Blueprint $t)=>$t->index(['locale','kind']));}public function down():void{Schema::table('catalogue_entries',fn(Blueprint $t)=>$t->dropIndex(['locale','kind']));}};
