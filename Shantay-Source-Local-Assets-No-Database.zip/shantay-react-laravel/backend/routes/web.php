<?php

use App\Http\Controllers\SiteApiController as Site;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/', [Site::class, 'home']);
Route::get('/admin/catalogue', function(Request $request){if(config('shantui.managed_content_enabled'))return app(Site::class)->adminPage($request);return response()->file(base_path('../public/admin/catalogue-editor.html'),['Content-Type'=>'text/html; charset=UTF-8']);});
Route::get('/admin', [Site::class, 'adminPage']);
Route::get('/admin/{path?}', [Site::class, 'adminPage'])->where('path', '.*');

Route::match(['GET', 'POST'], '/ext/ajax_news.jsp', fn (Request $request) => app(Site::class)->fragmentResponse('news', $request));
Route::match(['GET', 'POST'], '/ext/ajax_index.jsp', fn (Request $request) => app(Site::class)->fragmentResponse('home', $request));
Route::match(['GET', 'POST'], '/ext/ajax_proList.jsp', fn (Request $request) => app(Site::class)->fragmentResponse('product', $request));
Route::match(['GET','POST'], '/ext/ajax_partsList.jsp', fn(Request $request)=>app(Site::class)->fragmentResponse('parts',$request));
Route::match(['GET','POST'], '/ext/ajax_video.jsp', fn(Request $request)=>app(Site::class)->fragmentResponse('video',$request));
Route::post('/ext/from_dingyue.jsp', [Site::class, 'newsletter'])->middleware('throttle:newsletter');

Route::get('/authCodeServlet', [Site::class, 'authCode']);
Route::get('/core/control/common/down.jsp', function(Request $request) {
    $file=(string)$request->query('filename','');
    abort_unless(preg_match('~^/upload/file/[a-zA-Z0-9/_%.-]+\.pdf$~',$file),404);
    return \App\Support\LocalMedia::response(ltrim($file,'/'));
});
Route::post('/ext/ajax_downLoad.jsp', [Site::class,'downloadList'])->middleware('throttle:60,1');
Route::get('/solution/solution.jsp', fn (Request $request) => redirect('/api/site/render?' . http_build_query(['path' => '/solution/engineering-solutions.htm', 'lang' => $request->query('lang', 'en')])));

Route::get('/{assetPath}', function (string $assetPath) {
    $publicRoot = realpath(base_path('../public'));
    $distRoot = realpath(base_path('../dist'));
    $roots = str_starts_with($assetPath, 'assets/') ? [$distRoot, $publicRoot] : [$publicRoot, $distRoot];
    foreach ($roots as $root) {
        if (!$root) continue;
        $candidate = realpath($root . DIRECTORY_SEPARATOR . ltrim($assetPath, '/'));
        if ($candidate && str_starts_with($candidate, $root . DIRECTORY_SEPARATOR) && is_file($candidate)) {
            $mime=['js'=>'application/javascript','css'=>'text/css','json'=>'application/json','svg'=>'image/svg+xml','woff'=>'font/woff','woff2'=>'font/woff2','ttf'=>'font/ttf','html'=>'text/html; charset=UTF-8'];
            $extension=strtolower(pathinfo($candidate,PATHINFO_EXTENSION));
            return response()->file($candidate,isset($mime[$extension])?['Content-Type'=>$mime[$extension]]:[]);
        }
    }
    // Vite rewrites stored HTML routes in development. On Apache/Laravel,
    // /global/home.html must also reach the CMS rather than the asset fallback.
    // Existing physical HTML helpers above retain priority, just as in Vite.
    if (preg_match('~\.(?:html?|htm)$~i', $assetPath)) {
        return app(Site::class)->pageRoute(request(), $assetPath);
    }
    return \App\Support\LocalMedia::response($assetPath);
})->where('assetPath', '(?:resources|upload|uploads|assets|global)/.*');

Route::get('/{path}', [Site::class, 'pageRoute'])->where('path', '.*\.(?:html?|htm)');

Route::match(['GET','POST'], '/ext/ajax_solution.jsp', [Site::class, 'solutionProducts']);

Route::match(['GET','POST'],'/ext/ajax.jsp',function(Request $r){abort_unless(config('shantui.managed_catalogue_enabled'),404);return app(\App\Http\Controllers\CatalogueFragmentController::class)->categories($r);});
