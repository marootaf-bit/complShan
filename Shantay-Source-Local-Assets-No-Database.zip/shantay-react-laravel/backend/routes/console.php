<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('release:check {--json}', function () {
    $report=\App\Support\ReleaseCheck::run();
    $this->line(json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    return $report['ready']?0:1;
})->purpose('Read-only release gates; never changes credentials, records or approvals');

// No delivery unless both configuration and --send explicitly authorize it.
Artisan::command('inquiries:retry-notifications {--send} {--limit=25}', function () {
    $limit=max(1,min(100,(int)$this->option('limit')));
    $due=\Illuminate\Support\Facades\DB::table('inquiry_outbox')->whereIn('status',['pending','failed'])->where('attempts','<',5)->where(function($q){$q->whereNull('last_attempt_at')->orWhere('last_attempt_at','<=',now()->subMinutes(15));})->orderBy('id')->limit($limit)->pluck('request_id');
    $send=$this->option('send')&&config('shantui.inquiry_email_enabled');
    if($send)foreach($due as $id)\App\Support\InquiryStore::notify((int)$id);
    $this->line(json_encode(['delivery_enabled'=>(bool)$send,'eligible'=>count($due),'processed'=>$send?count($due):0,'statuses'=>\Illuminate\Support\Facades\DB::table('inquiry_outbox')->selectRaw('status, count(*) as total')->groupBy('status')->pluck('total','status'),'stalled_sending'=>\Illuminate\Support\Facades\DB::table('inquiry_outbox')->where('status','sending')->where('last_attempt_at','<',now()->subMinutes(20))->count()]));
    return 0;
})->purpose('Retry committed inquiry notifications; dry-run by default; never recreate requests');
if(config('shantui.inquiry_outbox_schedule_enabled')&&config('shantui.inquiry_email_enabled'))\Illuminate\Support\Facades\Schedule::command('inquiries:retry-notifications --send --limit=25')->everyFiveMinutes()->withoutOverlapping();
