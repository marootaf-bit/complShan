<?php

use App\Http\Controllers\SiteApiController as Site;
use Illuminate\Support\Facades\Route;

Route::get('/site/content-search',[\App\Http\Controllers\ManagedPublicController::class,'search'])->middleware('throttle:60,1');
Route::get('/health', [Site::class, 'health']);
Route::get('/site/render', [Site::class, 'render']);
Route::get('/site/routes', [Site::class, 'routesList']);
Route::post('/requests', [Site::class, 'submitInquiry'])->middleware('throttle:inquiries');

Route::post('/admin/login', [Site::class, 'login'])->middleware('throttle:admin-login');
Route::post('/admin/logout', [Site::class, 'logout']);
Route::get('/admin/session', [Site::class, 'session']);
Route::middleware(['admin.api','forms.validate'])->prefix('admin')->group(function () {
    Route::get('/content/{kind}', [\App\Http\Controllers\ContentAdminController::class,'collection']);
    Route::put('/content/{kind}', [\App\Http\Controllers\ContentAdminController::class,'save']);
    Route::get('/visual-preview', [\App\Http\Controllers\ContentAdminController::class,'preview']);
    Route::get('/visual-page', [\App\Http\Controllers\ContentAdminController::class,'visual']);
    Route::put('/visual-page', [\App\Http\Controllers\ContentAdminController::class,'saveVisual']);

    Route::get('/pages', [Site::class, 'pages']);
    Route::get('/page', [Site::class, 'getPage']);
    Route::post('/page', [Site::class, 'createPage']);
    Route::put('/page', [Site::class, 'updatePage']);
    Route::delete('/page', [Site::class, 'deletePage']);

    Route::get('/translations', [Site::class, 'translations']);
    Route::post('/translation', [Site::class, 'saveTranslation']);
    Route::put('/translation', [Site::class, 'saveTranslation']);
    Route::delete('/translation', [Site::class, 'deleteTranslation']);

    Route::put('/dealer-profile', [Site::class, 'saveDealerProfile']);
    Route::get('/settings', [Site::class, 'settings']);
    Route::post('/setting', [Site::class, 'saveSetting']);
    Route::put('/setting', [Site::class, 'saveSetting']);
    Route::delete('/setting', [Site::class, 'deleteSetting']);

    Route::get('/fragments', [Site::class, 'fragments']);
    Route::get('/fragment', [Site::class, 'getFragment']);
    Route::post('/fragment', [Site::class, 'createFragment']);
    Route::put('/fragment', [Site::class, 'updateFragment']);
    Route::delete('/fragment', [Site::class, 'deleteFragment']);

    Route::get('/requests', [Site::class, 'requests']);
    Route::patch('/requests/{id}', [Site::class, 'updateRequest']);
    Route::delete('/requests/{id}', [Site::class, 'deleteRequest']);

    Route::get('/media', [Site::class, 'media']);
    Route::post('/upload', [Site::class, 'upload']);
    Route::delete('/media', [Site::class, 'deleteMedia']);
});

// Stage 1 admin-only catalogue. Intentionally not consumed by public rendering.
Route::middleware('admin.api')->prefix('admin/catalogue-editor')->group(function () {
    Route::get('/', [\App\Http\Controllers\CatalogueEditorController::class,'index']);
    Route::post('/groups/{id}/retire', [\App\Http\Controllers\CatalogueEditorController::class,'retire']);
    Route::post('/{resource}', [\App\Http\Controllers\CatalogueEditorController::class,'save'])->where('resource','groups|items');
    Route::patch('/{resource}/{id}', [\App\Http\Controllers\CatalogueEditorController::class,'save'])->where('resource','groups|items');
});

Route::middleware('admin.api')->prefix('admin/workspace')->group(function () {
 Route::get('/media',[\App\Http\Controllers\WorkspaceContentController::class,'media']);
 Route::get('/pages',[\App\Http\Controllers\WorkspaceContentController::class,'index']);
 Route::get('/pages/{id}',[\App\Http\Controllers\WorkspaceContentController::class,'show']);
 Route::put('/pages/{id}',[\App\Http\Controllers\WorkspaceContentController::class,'save']);
 Route::post('/pages/{id}/publish',[\App\Http\Controllers\WorkspaceContentController::class,'publish']);
 Route::post('/pages/{id}/unpublish',[\App\Http\Controllers\WorkspaceContentController::class,'unpublish']);
 Route::post('/pages/{id}/restore/{version}',[\App\Http\Controllers\WorkspaceContentController::class,'restore']);
 Route::get('/pages/{id}/preview',[\App\Http\Controllers\WorkspaceContentController::class,'preview']);
});

Route::middleware('admin.api')->prefix('admin/workspace')->group(function(){
Route::get('/inquiries',[\App\Http\Controllers\WorkspaceInquiryController::class,'index']);Route::patch('/inquiries/{id}',[\App\Http\Controllers\WorkspaceInquiryController::class,'status']);Route::get('/access',[\App\Http\Controllers\AdminAccessController::class,'index']);Route::put('/access',[\App\Http\Controllers\AdminAccessController::class,'save']);});

Route::get('/site/catalogue',[\App\Http\Controllers\LocaleCatalogueController::class,'publicIndex'])->middleware('throttle:60,1');
Route::middleware('admin.api')->prefix('admin/workspace/catalogue')->group(function(){
Route::get('/items',[\App\Http\Controllers\LocaleCatalogueController::class,'index']);Route::get('/items/{id}',[\App\Http\Controllers\LocaleCatalogueController::class,'show']);Route::post('/items',[\App\Http\Controllers\LocaleCatalogueController::class,'create']);Route::put('/items/{id}',[\App\Http\Controllers\LocaleCatalogueController::class,'save']);Route::post('/items/{id}/{action}',[\App\Http\Controllers\LocaleCatalogueController::class,'lifecycle'])->where('action','publish|archive|restore');
Route::get('/groups',[\App\Http\Controllers\LocaleCatalogueController::class,'groups']);Route::post('/groups',[\App\Http\Controllers\LocaleCatalogueController::class,'saveGroup']);Route::put('/groups/{id}',[\App\Http\Controllers\LocaleCatalogueController::class,'saveGroup']);Route::post('/groups/{id}/{action}',[\App\Http\Controllers\LocaleCatalogueController::class,'groupLifecycle'])->where('action','publish|archive|restore');});

Route::get('/admin/workspace/catalogue/groups/{id}/preview',[\App\Http\Controllers\WorkspaceContentController::class,'categoryPreview'])->middleware('admin.api');
