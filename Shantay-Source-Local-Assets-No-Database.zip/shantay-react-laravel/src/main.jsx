import React,{useCallback,useEffect,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {useTranslation} from 'react-i18next';
import i18n,{changeLocale,DARI_LOCALE,ENGLISH_LOCALE,getInitialLocale} from './i18n.js';
import './style.css';

const initialRoute=()=>{
 const q=new URLSearchParams(location.search),path=q.get('path');
 q.delete('path');q.delete('lang');q.delete('site');return {path:path?.startsWith('/')&&/\.html?$|\.htm$/i.test(path)?path:'/global/home.html',query:q.toString(),hash:location.hash};
};
function sourceUrl(route,locale){
 const q=new URLSearchParams(route.query||'');q.delete('path');q.set('path',route.path);q.set('lang',locale===DARI_LOCALE?'fa':'en');
 return '/api/site/render?'+q.toString()+(route.hash||'');
}
function LoadingIndicator({label='در حال آماده‌سازی سایت…'}){
 return <div className="site-loading" role="status" aria-live="polite"><div className="site-loading-card"><div className="site-loading-mark" aria-hidden="true"><i/><i/><i/></div><strong>SHANTUI<span>AFGHANISTAN</span></strong><p>{label}</p><div className="site-loading-track" aria-hidden="true"><span/></div></div></div>;
}
function App(){
 const frame=useRef(null),route=useRef(initialRoute()),activeLocale=useRef(getInitialLocale());
 const [locale,setLocale]=useState(getInitialLocale);
 const [src,setSrc]=useState(()=>sourceUrl(route.current,getInitialLocale()));
 const [frameState,setFrameState]=useState('loading');
 const [translationFallback,setTranslationFallback]=useState(false);
 const [preview,setPreview]=useState(false);
 const {t}=useTranslation();
 const applyLocale=useCallback(value=>{
  const next=value===DARI_LOCALE?DARI_LOCALE:ENGLISH_LOCALE;
  setLocale(next);
  if(activeLocale.current!==next){
   activeLocale.current=next;setFrameState('loading');setTranslationFallback(false);setPreview(false);setSrc(sourceUrl(route.current,next));
  }
  const q=new URLSearchParams(location.search);q.set('lang',next===DARI_LOCALE?'fa':'en');
  q.set('path',route.current.path);history.replaceState(null,'','/?'+q);
 },[]);
 useEffect(()=>{
  const changed=applyLocale;
  const message=event=>{
   if(event.origin!==location.origin||event.source!==frame.current?.contentWindow)return;
   const d=event.data||{};
   if(d.type==='site-route-change'&&typeof d.path==='string'&&d.path.startsWith('/')&&/\.html?$|\.htm$/i.test(d.path)){
    route.current={path:d.path,query:d.query||'',hash:d.hash||''};
    const q=new URLSearchParams(d.query||'');q.delete('path');q.set('path',d.path);q.set('lang',locale==='fa-AF'?'fa':'en');if(new URLSearchParams(location.search).has('site'))q.set('site','1');const target='/?'+q+(d.hash||'');if(target!==location.pathname+location.search+location.hash)history.pushState(null,'',target);
   }
   if(d.type==='site-locale-change'){
    if(d.path&&d.path!=='/api/site/render')route.current.path=d.path;
    if(d.query){const q=new URLSearchParams(d.query);q.delete('path');q.delete('lang');route.current.query=q.toString()}
    route.current.hash=d.hash||'';applyLocale(d.locale);void changeLocale(d.locale);
   }
   if(d.type==='site-translation-status'){
    setTranslationFallback(d.requestedLocale===DARI_LOCALE&&d.contentLocale!==DARI_LOCALE);
    setPreview(d.contentLocale===DARI_LOCALE&&['draft','needs_review'].includes(d.status));
   }
  };
  const back=()=>{route.current=initialRoute();setFrameState('loading');setSrc(sourceUrl(route.current,activeLocale.current));};window.addEventListener('popstate',back);i18n.on('languageChanged',changed);window.addEventListener('message',message);
  document.documentElement.lang=locale;document.documentElement.dir=locale===DARI_LOCALE?'rtl':'ltr';document.title=t('app.title');
  const description=document.querySelector('meta[name="description"]');if(description)description.content=t('app.description');
  return()=>{window.removeEventListener('popstate',back);i18n.off('languageChanged',changed);window.removeEventListener('message',message)};
 },[locale,t,applyLocale]);
 useEffect(()=>{
  if(frameState!=='loading')return;
  const timer=setTimeout(()=>setFrameState('error'),45000);return()=>clearTimeout(timer);
 },[frameState,src]);
 const loaded=event=>{
  // Ignore an obsolete document finishing after a new language was requested.
  try{const q=new URL(event.currentTarget.contentWindow.location.href).searchParams;const wanted=locale===DARI_LOCALE?'fa':'en';if(q.has('lang')&&q.get('lang')!==wanted)return}catch{}
  setFrameState('loaded');
  try{const title=event.currentTarget.contentDocument?.title;if(title)document.title=title}catch{}
  try{
   const doc=event.currentTarget.contentDocument?.documentElement;
   setTranslationFallback(doc?.dataset.requestedLocale===DARI_LOCALE&&doc?.dataset.contentLocale!==DARI_LOCALE);
   setPreview(doc?.dataset.contentLocale===DARI_LOCALE&&['draft','needs_review'].includes(doc?.dataset.translationStatus));
  }catch{setTranslationFallback(false)}
 };
 return <main className="global-mirror-shell" aria-busy={frameState==='loading'}>
  {frameState==='loading'&&<LoadingIndicator label={t('app.loading')}/>}
  {frameState==='error'&&<div className="preview-error" role="alert">{t('app.loadError')}<button type="button" onClick={()=>{setFrameState('loading');frame.current?.contentWindow.location.reload()}}>{locale===DARI_LOCALE?'تلاش دوباره':'Try again'}</button></div>}
  {translationFallback&&<div className="translation-fallback" role="status" aria-live="polite">{t('app.translationFallback')}</div>}
  {preview&&<div className="draft-preview-label" role="status">{t('app.draftPreview')}</div>}
  <iframe ref={frame} title={t('app.title')} className="global-mirror-frame" src={src} onLoad={loaded} onError={()=>setFrameState('error')}/>
 </main>
}
createRoot(document.getElementById('root')).render(<React.Suspense fallback={<LoadingIndicator/>}><App/></React.Suspense>);
