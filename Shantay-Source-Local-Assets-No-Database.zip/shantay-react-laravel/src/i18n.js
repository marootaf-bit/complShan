import i18n from 'i18next';
import HttpBackend from 'i18next-http-backend';
import { initReactI18next } from 'react-i18next';

export const DARI_LOCALE = 'fa-AF';
export const ENGLISH_LOCALE = 'en';
const STORAGE_KEY = 'shantui-lang';
const COOKIE_KEY = 'shantui_lang';

export function normalizeLocale(value) {
  const locale = String(value || '').trim().replaceAll('_', '-').toLowerCase();
  if (locale === 'en' || locale.startsWith('en-')) return ENGLISH_LOCALE;
  if (locale === 'fa' || locale.startsWith('fa-') || locale === 'prs' || locale.startsWith('prs-')) return DARI_LOCALE;
  return null;
}

function cookieLocale() {
  try {
    const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${COOKIE_KEY}=([^;]+)`));
    return match ? decodeURIComponent(match[1]) : null;
  } catch {
    return null;
  }
}

export function getInitialLocale() {
  const fromQuery = normalizeLocale(new URLSearchParams(window.location.search).get('lang'));
  if (fromQuery) return fromQuery;

  try {
    const fromStorage = normalizeLocale(window.localStorage.getItem(STORAGE_KEY));
    if (fromStorage) return fromStorage;
  } catch {
    // Continue with the cookie/browser locale when storage is unavailable.
  }

  const fromCookie = normalizeLocale(cookieLocale());
  if (fromCookie) return fromCookie;
  // This is the Dari-first website. Browser English must not silently replace its default.
  return DARI_LOCALE;
}

export function persistLocale(value) {
  const locale = normalizeLocale(value) || DARI_LOCALE;
  try {
    window.localStorage.setItem(STORAGE_KEY, locale === DARI_LOCALE ? 'fa' : 'en');
  } catch {
    // The cookie remains available when localStorage is disabled.
  }
  try {
    document.cookie = `${COOKIE_KEY}=${encodeURIComponent(locale)}; Path=/; Max-Age=2592000; SameSite=Lax`;
  } catch {
    // The current page still uses the selected locale for this session.
  }
  return locale;
}

const initialLocale = getInitialLocale();

i18n
  .use(HttpBackend)
  .use(initReactI18next)
  .init({
    lng: initialLocale,
    fallbackLng: false,
    supportedLngs: [ENGLISH_LOCALE, DARI_LOCALE],
    load: 'currentOnly',
    ns: ['translation'],
    defaultNS: 'translation',
    backend: { loadPath: '/global/locales/{{lng}}.json' },
    returnNull: false,
    returnEmptyString: false,
    interpolation: { escapeValue: false },
  });

i18n.on('languageChanged', (value) => {
  const locale = normalizeLocale(value) || DARI_LOCALE;
  document.documentElement.lang = locale;
  document.documentElement.dir = locale === DARI_LOCALE ? 'rtl' : 'ltr';
  persistLocale(locale);
});

export async function changeLocale(locale) {
  const normalized = normalizeLocale(locale);
  if (!normalized) return false;
  await i18n.changeLanguage(normalized);
  return true;
}

export default i18n;
