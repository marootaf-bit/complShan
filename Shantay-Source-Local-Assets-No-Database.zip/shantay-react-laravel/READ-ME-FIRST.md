# Shantay: React + Laravel source with local assets, WITHOUT database

Selected project: project-shantui-global. Packaged 2026-11-05.

Includes editable React source (src/), Laravel source (backend/), dependency manifests/lockfiles, public local images/fonts/CSS/JS and other available public resources, backend view/icon resources, and existing compiled frontend (hosted-frontend/).

No database or database snapshot, credentials/.env, private keys, vendor, node_modules, runtime caches/logs or other projects are included. Database migration/seeder PHP source is included as code, not database data.

IMPORTANT: Without a content database this package cannot reproduce the populated preview. Existing local launch/preparation scripts expect data/hosted-content.sqlite.gz; that file is NOT included as explicitly requested. Configure your own isolated local environment and database before running database-backed pages. Do not point tests or migrations at production.

This React frontend is a small editable shell displaying Laravel-rendered HTML in an iframe, NOT a full native React/Tailwind conversion. The local project's documentation describes its editable React shell as reconstructed from the hosted baseline. Backend has local additions; this is the selected local project, not a claim of a byte-identical full hosting backup.

The media here is only what already exists locally. The full hosting media library was not downloaded and some background images/videos/documents may still be absent. No files were fetched from hosting for this package.

Installation: npm ci in project root; composer install in backend/ after reviewing scripts. Create fresh local environment secrets/runtime folders and configure a separate database. hosted-frontend/ contains compiled assets and can be mapped/symlinked to dist/ for the existing Laravel layout. Local preview helper scripts are not for production deployment. A fresh no-database installation was not certified as a fully working populated site.
