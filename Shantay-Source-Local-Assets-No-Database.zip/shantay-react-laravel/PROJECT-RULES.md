# قوانین الزام‌آور پروژه

## قانون اول — ظاهر صفحهٔ اصلی بدون اجازهٔ صریح مالک تغییر نکند

دستور صریح مالک: «دیزاین صفحهٔ اصلی سایت هیچ‌وقت تا من نخواستم هیچ تغییر نکند؛ حتی کوچک‌ترین بخش آن.»

- مرجع فعلی، نسخهٔ بازگردانده‌شده از هاست `test.grandtire.af` است؛ نه پیاده‌سازی ردشدهٔ Studio.
- هیچ تغییر ظاهری، حتی جزئی، در صفحهٔ اصلی بدون درخواست صریح مالک مجاز نیست: چیدمان، رنگ، فونت، اندازه، فاصله، هدر، منو، فوتر، عکس، بنر، اسلایدر، آیکون، متن قابل‌نمایش و رفتار بصری/واکنش‌گرای آن.
- این ممنوعیت برای موبایل و دسکتاپ و برای آثار غیرمستقیم تغییر CSS/JS مشترک، داده، بک‌اند یا داشبورد نیز برقرار است.
- درخواست تغییر بک‌اند یا داشبورد به معنی اجازهٔ تغییر ظاهر صفحهٔ اصلی نیست.
- اگر تغییر درخواستی مستلزم اثر ظاهری بر صفحهٔ اصلی باشد، پیش از اجرا اثر مشخص توضیح داده شود و اجازه گرفته شود. تغییر خودکار، بهینه‌سازی سلیقه‌ای یا بازطراحی مجاز نیست.
- کارها منظم و بخش‌به‌بخش انجام شوند؛ در هر بخش فقط محدودهٔ درخواست‌شده تغییر کند و آثار جانبی بررسی شوند.
- انتشار روی هاست مجوز جداگانه می‌خواهد. این قانون به‌خودی‌خود مجوز تغییر هیچ بخش دیگری از سایت نیست.

## محدودهٔ مرحلهٔ فعلی

مالک «محصولات و قطعات» را برای مرحلهٔ اول انتخاب کرد. فرم‌ها و بک‌اند مستقل مجازند؛ اتصال به منو یا صفحات عمومی در این مرحله عمداً فعال نشده است. انتخاب این مرحله مجوز تغییر ظاهر صفحهٔ اصلی نیست. قبل از توسعهٔ بیشتر، گزارش `reports/CATALOGUE-PHASE1.md` و نظر مالک دربارهٔ پیش‌نمایش بررسی شود.

## Scope update — 2026-11-04 (supersedes the previous phase boundary only)
The owner now authorizes comprehensive Laravel/admin repair and connection of existing public content, navigation, search and forms **in this workspace only**. The earlier products/parts-admin-only integration restriction is superseded. All homepage/public-design restrictions above remain binding at every breakpoint. No hosting deployment is authorized. Languages must be independent; implementations must stay disabled until their own validation is complete. Partial page editing must not be described as completion of catalogue, forms, permissions or the whole project.
