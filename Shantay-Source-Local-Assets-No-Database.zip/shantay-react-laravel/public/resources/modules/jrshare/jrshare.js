/*
 * name: jrshare.js
 * version: v0.2.0
 * update: 添加了注入组件的模式
 * date: 2022-05-18
 * author: fyh
 */

define('jrshare/jrshare', function(require, exports, module){
    var jQuery = require('jquery');

    (function($, window, document, undefined) {
        var JRS = require('jrs');

        // jQuery全局函数，用于在已有结构上绑定分享事件
        $.extend({
            jrshare: function(config) {
                var jrs = new JRS(config);
                jrs.attach();
            }
        });

        // 处理第三方插件兼容
        $.extend($.jrshare, {
            bshare: function() {
                var jrs = new JRS({ bshare: true });
                jrs.attach();
                jrs.compBShare();
            },
            bdshare: function(commonConf, shareConf) {
                var jrs = new JRS({ bdshare: true });
                jrs.attach();
                jrs.compBDShare(commonConf, shareConf);
            }
        });
    
        // jQuery对象方法，用于创建包含结构和样式的分享组件
        $.fn.extend({
            jrshare: function(platforms, style) {
                var create = {};
                create.platforms = platforms;
                create.style = style;

                return this.each(function() {
                    var jrs = new JRS({ create: create });
                    jrs.create(this);
                });
            }
        });

        module.exports = JRS;
    })(window.Zepto || jQuery, window, document);
});

/**
 * JRS
 */
define('jrs', function(require, exports, module) {
    var $ = require('jquery');
    var utils = require('utils');
    var Platform = require('platform');

    // 默认配置
    var def = {
        // 分享容器
        bshare: false, // 是否使用bshare容器
        bdshare: false, // 是否使用bdshare容器
        container: '.jrshare_box',
        qq: '.jrs_qq',
        qzone: '.jrs_qzone',
        weixin: '.jrs_weixin',
        weibo: '.jrs_weibo',
        tieba: '.jrs_tieba',
        douban: '.jrs_douban',
        facebook: '.jrs_facebook',
        linkedin: '.jrs_linkedin',
        twitter: '.jrs_twitter',

        // 分享参数
        url: '',
        title: '',
        desc: '',
        pic: '',
        comment: '',

        // 创建参数
        create: {
            platforms: ['qq', 'weixin', 'weibo', 'qzone', 'facebook', 'twitter'],
            style: 'popup_1_1', // 第一：类型 第二：风格 第三：图标 1: 纯色无底 2: 彩色无底 3: 纯色圆底 4: 彩色圆底
        },

        // 平台接口
        platforms: {
            qq: {
                name: 'QQ', 
                type: 'qr', 
                template: 'https://connect.qq.com/widget/shareqq/index.html?url={url}&title={title}&summary={desc}' 
            },
            weixin: {
                name: '微信',
                type: 'qr'
            },
            qzone: { 
                name: 'QQ空间',
                type: 'url', 
                template: 'https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url={url}&title={title}&summary={desc}&pic={pic}' 
            },
            weibo: { 
                name: '微博',
                type: 'url', 
                template: 'https://service.weibo.com/share/share.php?url={url}&title={comment}&pic={pic}&searchPic=true' 
            },
            douban: {
                name: '豆瓣',
                type: 'url',
                template: 'https://www.douban.com/share/service?name={title}&href={url}&image={pic}&url={url}&title={title}'
            },
            tieba: {
                name: '贴吧',
                type: 'url',
                template: 'http://tieba.baidu.com/f/commit/share/openShareApi?url={url}&title={title}&desc={desc}&comment={comment}'
            },
            facebook: {
                name: 'Facebook',
                type: 'url',
                template: 'https://www.facebook.com/sharer/sharer.php?u={url}'
            },
            linkedin: {
                name: 'Linkedin',
                type: 'url',
                template: 'https://www.linkedin.com/sharing/share-offsite/?url={url}'
            },
            twitter: {
                name: 'Twitter',
                type: 'url',
                template: 'https://twitter.com/intent/tweet?url={url}&text={comment}'
            }
        }
    };

    function JRS(options) {
        var opt = utils.getOptions(JRS.defaults, options);
        this.comp = {
            bshare: opt.bshare,
            bdshare: opt.bdshare
        };

        this.selectors = {
            container: opt.container,
            qq: opt.qq,
            qzone: opt.qzone,
            weixin: opt.weixin,
            weibo: opt.weibo,
            tieba: opt.tieba,
            douban: opt.douban,
            facebook: opt.facebook,
            linkedin: opt.linkedin,
            twitter: opt.twitter,
        };

        this.metadata = {
            url: opt.url,
            title: opt.title,
            desc: opt.desc,
            pic: opt.pic,
            comment: opt.comment
        };

        var $this = this;
        this.platforms = [];
        $.each(opt.platforms, function(key, plat) {
            plat.id = key;
            var platform = new Platform(plat, $this.metadata);
            $this.platforms.push(platform);
        });

        this.createOpt = {
            platforms: [],
            style: opt.create.style
        };
        $.each(opt.create.platforms, function(idx, key) {
            var plat = opt.platforms[key];
            plat.id = key;
            var platform = new Platform(plat, $this.metadata);
            $this.createOpt.platforms.push(platform);
        });

        this._injectStyle();
        this._createMobile();
    }

    JRS.defaults = def;

    JRS.prototype.attach = function() {
        var sels = this.selectors;
        var plats = this.platforms;

        // 检查容器
        var $containers = $(sels.container);
        if($containers.length === 0) {
            return;
        }

        // 初始化各个容器
        $containers.each(function() {
            // 检查是否已初始化
            $container = $(this);
            if($container.attr('data-jrs') != 'loaded') {
                // 遍历并挂载各个分享接口
                $.each(plats, function(idx, plat){
                    var $platElm = $container.find(sels[plat.id]);
                    if($platElm.length != 0) {
                        $platElm.attr('href', 'javascript:void(0);');
                        $platElm.on('click', function(e) {
                            e.preventDefault();
                            plat.share();
                        });
                    }
                });

                // 初始化完成，防止重复挂载
                $container.attr('data-jrs', 'loaded');
            }
        });
    };

    JRS.prototype.create = function(elm) {
        var plats = this.createOpt.platforms;
        var $elm = $(elm);
        var path = utils.getModulesPath() + '/jrshare';

        var styles = this.createOpt.style.split('_');
        var type = styles[0];
        var style = styles[1];
        var icons = [ 
            [1, false], [1, true],
            [2, false], [2, true]
        ];
        var icon = icons[styles[2] - 1];

        if(type === 'popup') {
            createPopup(style, icon);
        } else if(type === 'tile') {
            createTile(style, icon);
        } else if(type === 'inline') {
            createInline(style, icon);
        } else {
            createPopup(style, icon);
        }

        this.attach();

        function createPopup(style, icon) {
            var $popup = $('<div class="jrshare_box jrs_popup jrs_popup_' + style + ' jrs_icon_' + icon[0] + (icon[1] ? ' jrs_icon_color' : '') + '">' +
            '    <div class="popup_box">' +
            '        <div class="content">' +
            '            <div class="box">' +
            '                <div class="share_title">' +
            '                    Share to：' +
            '                </div>' +
            '                <div class="share_box">' +
                                createElements() +
            '                </div>' +
            '                <div class="share_close"></div>' +
            '            </div>' +
            '        </div>' +
            '        <div class="share_bg"></div>' +
            '    </div>' +
            '</div>').appendTo(utils.getWrapper());
    
            function createElements() {
                var elms = '';
                $.each(plats, function(){
                    var elm = 
        '                        <a class="jrs_' + this.id + '" target="_blank" title="分享到' + this.name + '">' +
        '                            <i class="iconfont-jrs"></i>' +
        '                            <span class="txt">' + this.name + '</span>' +
        '                        </a>';
                    elms += elm;
                });
                return elms;
            }
    
            $elm.on('click', function() {
                if(utils.getDeviceType() === 'Mobile') {
                    $('.jrshare_mobile').fadeIn();
                } else {
                    $popup.find('.popup_box').stop().fadeIn();
                }
            });
    
            $popup.find('.share_close').on('click', function(){
                $popup.find('.popup_box').stop().fadeOut();
            });
        }

        function createTile(style, icon) {
            var $tile = $(
                '<div class="jrshare_box jrs_tile jrs_tile_' + style + ' jrs_icon_' + icon[0] + (icon[1] ? ' jrs_icon_color' : '') + '">' +
                    createElement() +
                '</div>'
            );

            function createElement() {
                var elms = '';
                $.each(plats, function(){
                    var elm = '<a class="jrs_' + this.id + '" title="分享到' + this.name + '"><i class="iconfont-jrs"></i></a>';
                    elms += elm;
                });
                return elms;
            }

            $tile.appendTo($elm);
        }

        function createInline(style, icon) {
            var $inline = $(
                '<div class="jrshare_box jrs_inline jrs_inline_' + style + ' jrs_icon_' + icon[0] + (icon[1] ? ' jrs_icon_color' : '') + '">' +
                    createElement() +
                '</div>'
            );

            function createElement() {
                var elms = '';
                $.each(plats, function(){
                    var elm = '<a class="jrs_' + this.id + '" title="分享到' + this.name + '"><i class="iconfont-jrs"></i></a>';
                    elms += elm;
                });
                return elms;
            }

            $inline.appendTo($elm);
        }
    };

    JRS.prototype.compBShare = function() {

    }

    JRS.prototype.compBDShare = function(commonConf, shareConf) {
        if(commonConf===void(0)){
            commonConf = {}
        }
        if(shareConf===void(0)){
            shareConf = commonConf;
            commonConf = {}
        };
        commonConf = $.extend({bdSign:false},commonConf);
        
        // 导入bdshare样式
        function importBDStyle(bdsOpt, $container) {
            // 默认导入配置
            var bdsDef = {
                stylePath: utils.getModulesPath() + '/jrshare/bdshare/css',
                commonConf: {
                    bdSize: 16,
                    bdStyle: 0
                },
                shareConf: []
            };

            // 合并选项
            if(typeof bdsOpt != 'object') {
                bdsOpt = bdsDef;
            } else {
                bdsOpt = $.extend(true, {}, bdsDef, bdsOpt);
            }

            // 判断容器的tag是否在shareConf中配置，并导入相应样式
            var hasTag = false;
            $.each(bdsOpt.shareConf, function(idx, conf) {
                conf = $.extend({}, bdsOpt.commonConf, conf);
                if($container.attr('data-tag') === conf.tag) {
                    importStyle(conf);
                    hasTag = true;
                }
            });

            // tag不在配置中，或者无tag，则导入默认样式
            if(!hasTag) {
                importStyle(bdsOpt.commonConf);
            }

            // 样式导入
            function importStyle(conf) {
                $container.addClass('bdshare-button-style' + conf.bdStyle + '-' + conf.bdSize);
                var cssFile = 'share_style' + conf.bdStyle + '_' + conf.bdSize + '.css';
                if($('link[href$="' + cssFile + '"]').length === 0) {
                    $('<link rel="stylesheet" href="' + bdsOpt.stylePath + '/' + cssFile + '">').appendTo('head');
                }
            }
        }
        
        if(this.selectors.container) {
            $containers = $(this.selectors.container);
            $containers.each(function(idx, con){
                importBDStyle({
                    commonConf: commonConf,
                    shareConf: shareConf
                }, $(con));
            });
        }
    }

    // 插入样式表
    JRS.prototype._injectStyle = function() {
        var path = utils.getModulesPath() + '/jrshare';
        $('<link rel="stylesheet" href="' + path + '/jrshare.css">').appendTo('head');
    }

    // 创建移动端分享遮罩
    JRS.prototype._createMobile = function() {
        var $mobile = $('.jrshare_mobile');
        if($mobile.length === 0) {
            var path = utils.getModulesPath() + '/jrshare';
            $mobile = $('<div class="jrshare_mobile" style="display: none;"><img src="' + path + '/img/mobile.png" alt=""></div>"')
                .appendTo(utils.getWrapper());
            $mobile.on('click', function(){
                $mobile.fadeOut();
            });
        }
        
        // 如果url参数存在ref=jrs_m则自动显示遮罩，并移除参数
        var search = window.location.search;
        var refParam = 'ref=jrs_m';
        if(search.indexOf(refParam) != -1) {
            $mobile.show();
            if(window.history && window.history.replaceState) {
                window.history.replaceState({}, document.title, window.location.href.replace(refParam, ''));
            }
        }
    }

    return JRS;
})

/**
 * 分享平台
 */
 define('platform', function(require, exports, module){
    var $ = require('jquery');
    var qr = require('qr');
    var utils = require('utils');

    function Platform(config, metadata) {
        $.extend(this, Platform.defaults, config || {});
        this.metadata = metadata;
        this.$qrBox = null;
        this.link = null;

        // 初始化分享
        switch(this.type) {
            case 'qr':
                this.$qrBox = this._createQrBox();
                break;
            case 'url':
                this.link = this._generateLink();
                break;
            default:
                break;
        }
    }

    Platform.defaults = {
        id: 'unknown',
        name: '未知平台',
        type: 'url',
        template: '?url={url}&title={title}&desc={desc}&pic={pic}'
    };

    Platform.prototype.share = function() {
        // 执行分享
        switch(this.type) {
            case 'qr':
                this._showQrBox();
                break;
            case 'url':
                this._openLink();
                break;
            default:
                break;
        }
    };

    // 创建二维码框
    Platform.prototype._createQrBox = function() {
        var platName = this.name;
        var platClass = 'jrshare_' + this.id + 'Box';
        var $qrbox = $('.jrshare_qrbox.' + platClass);
        if($qrbox.length === 0) {
            var $qrbox = $('<div class="jrshare_qrbox ' + platClass + '">\
                <div class="qrbox_top">\
                    <span class="qrbox_title">分享到' + platName + '</span>\
                    <a href="javascript:void(0);" class="close_btn">\
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAASRJREFUWEfVl+EOgyAMhPHJt735UmMTxNK7qyxx/jEE6X0cRcrWzs/7aPp76L7dvMTfupDW+Tran9baaogwvgP0nc60EmIa3wCizpUQaXwEYCB3nMjE99jZEvQZV4GA4ub+LAmjdLeABsI8lLgF6gGsjQYyECjGyc0R4C6EJB454PaiQJETaEyYR5EDFYiSeOaAAmGT8D9olKDpDsocYCGyXQG3LwPAJKY8cx/AAqgQcOYVABaCFmeScLQWZbt8dvzNEjAzH92iloJxoCJO1xMIAIn76fiTHxEj3heZJYiZA4o4+8ekD6OKeBlCLUiYzJYmoJRkjLjsxCOKUskypiLtvoGx0b1AsX3GBi8ms1NuhXiWE3v8x1xOe1J3RFxu6vPL9fwL2ZJoIVbhqlMAAAAASUVORK5CYII=" alt="关闭"></img>\
                    </a>\
                </div>\
                <div class="qrbox_bott">\
                    <div class="qrbox_qrcode"></div>\
                    <div class="qrbox_text"></div>\
                </div>\
            </div>').appendTo(utils.getWrapper());
            $('<style>\
                .jrshare_qrbox{display:none; position:fixed; top:50%; left:50%; border:1px solid #d8d8d8; font-size:14px; color:#222; background:#fff; transform: translate(-50%, -50%); z-index:1001; user-select:none;} \
                .jrshare_qrbox .qrbox_top{position:relative; padding:5px 20px; background:#f2f2f2;}    \
                .jrshare_qrbox .qrbox_top .close_btn{position:absolute; right:20px; top:10px; width:12px; height:12px;} \
                .jrshare_qrbox .qrbox_bott{padding:20px;}\
            </style>').appendTo($('head'));

            $qrbox.find('.close_btn').on('click', function(){
                $qrbox.fadeOut(200);
            });

            // 添加移动端参数
            var mobileUrl = this.metadata.url;
            var urlParts = mobileUrl.split('?');
            if(urlParts.length < 2) {
                mobileUrl += '?ref=jrs_m';
            } else {
                var urlParams = urlParts[1];
                if(urlParams.indexOf('ref=jrs_m') === -1) {
                    mobileUrl += '&ref=jrs_m';
                }
            }

            // 创建二维码
            var qrcode = new qr($qrbox.find('.qrbox_qrcode').get(0), {
            text: mobileUrl,                          // 生成内容
                width: 180,                         // 宽
                height: 180,                        // 高
                colorDark : "#000000",              // 颜色
                colorLight : "#ffffff",             // 背景色
                correctLevel : qr.CorrectLevel.M    // 容错级别 L|M|Q|H
            });
        }

        return $qrbox;
    }

    // 生成分享链接
    Platform.prototype._generateLink = function() {
        var $this = this;
        return $this.template.replace(/\{(\w+)\}/g, function(matches) {
            var parameter = matches.slice(1, -1);
            var meta = $this.metadata[parameter];
            if (typeof meta !== 'undefined') {
                return encodeURIComponent(meta);
            }
            return ''
        });
    }

    // 显示二维码框
    Platform.prototype._showQrBox = function() {
        this.$qrBox.fadeIn(200);
    }

    // 打开分享链接
    Platform.prototype._openLink = function() {
        window.open(this.link, 'jrshare-' + this.id, 'menubar=no,toolbar=no,location=no,directories=no,status=no,dependent,width=800,height=620,top=100,left=100');
    }

    return Platform;
});

/**
 * 工具函数
 */
define('utils', function(require, exports, module){
    var $ = require('jquery');

    var bshare = {
        container: '.bshare-custom',
        qq: '.bshare-qqim',
        qzone: '.bshare-qzone',
        weixin: '.bshare-weixin',
        weibo: '.bshare-sinaminiblog',
        tieba: '.bshare-itieba',
        douban: '.bshare-douban',
        facebook: '.bshare-facebook',
        linkedin: '.bshare-linkedin',
        twitter: '.bshare-twitter'
    };

    var bdshare = {
        container: '.bdsharebuttonbox',
        qq: '.bds_sqq',
        qzone: '.bds_qzone',
        weixin: '.bds_weixin',
        weibo: '.bds_tsina',
        tieba: '.bds_tieba',
        douban: '.bds_douban',
        facebook: '.bds_fbook',
        linkedin: '.bds_linkedin',
        twitter: '.bds_twi'
    };

    // 提取页面元数据
    function extractMetadata() {
        var result = {};

        // 页面元数据列表
        var metaList = {
            // 页面URL，优先级为twitter:url > og:url > ref="canonical" > location.href
            url: [
                $('meta[name="twitter:url"]').attr('content'),
                $('meta[property="og:url"]').attr('content'),
                $('link[rel="canonical"]').attr('href'),
                window.location.href
            ],
            // 页面标题，优先级为twitter:title > og:title > title
            title: [
                $('meta[name="twitter:title"]').attr('content'),
                $('meta[property="og:title"]').attr('content'),
                $('title').text()
            ],
            // 页面描述，优先级为twitter:description > og:description > description
            desc: [
                $('meta[name="twitter:description"]').attr('content'),
                $('meta[property="og:description"]').attr('content'),
                $('meta[name="description"]').attr('content') || $('meta[name="Description"]').attr('content')
            ],
            // 图片，优先级为twitter:image > og:image > 文章第一张 > section第一张
            pic: [
                $('meta[name="twitter:image"]').attr('content'),
                $('meta[property="og:image"]').attr('content'),
                (function(){
                    var imgSrc ='';
                    var secImg = $('.section').find('img');
                    if(secImg.length != 0) {
                        imgSrc =  $('.section').find('img').eq(0).attr('src')
                        if(imgSrc.indexOf('http') === -1) {
                        imgSrc = window.location.origin + imgSrc;
                        }
                    }
                    var artImg = $('.myart').find('img');
                    if(artImg.length != 0) {
                        imgSrc =  $('.myart').find('img').eq(0).attr('src')
                        if(imgSrc.indexOf('http') === -1) {
                        imgSrc = window.location.origin + imgSrc;
                        }
                    }
                    
                    return imgSrc;
                })()
            ]
        };

        // 根据优先级获取Meta数据
        $.each(metaList, function(key, metaArr) {
            for(var i=0; i<metaArr.length; i++) {
                if(metaArr[i] && metaArr[i].trim()) {
                    result[key] = metaArr[i];
                    break;
                }
            }
        });

        return result;
    }

    // 处理配置项
    function getOptions(def, config) {
        // 获取初始分享参数
        var pageMeta = extractMetadata();
        def = $.extend({}, def, pageMeta);

        // 合并选项
        if(config && config.bshare) {
            config = $.extend(true, {}, bshare, config);
        }else if(config && config.bdshare) {
            config = $.extend(true, {}, bdshare, config);
        }
        var opt = $.extend(true, {}, def, config || {});
        if(config.create) {
            opt.create.platforms = config.create.platforms;
        }
        
        if(!opt.comment || opt.comment.length === 0) {
            opt.comment = (opt.title + '\n' + opt.desc).slice(0, 138 - opt.url.length / 2); // 拼接微博/Twitter输入框内容，长度限制140
        }

        if(!opt.create.platforms || opt.create.platforms.length === 0) {
            opt.create.platforms = def.create.platforms;
        }
        
        return opt;
    }

    // 获取模块路径
    function getModulesPath() {
        var path = '/resources/modules';
        var seajsPath = $('#seajsnode').attr('src');
        var matches = seajsPath.match(/(^.*\/modules)\/.*$/i);
        if(matches[1]) {
            path = matches[1];
        }
        return path;
    }

    // 获取外层容器
    function getWrapper() {
        var $wrapper = $('.jrshare_wrapper');
        if($wrapper.length === 0) {
            $wrapper = $('<div class="jrshare_wrapper"></div>').appendTo('body');
        }
        return $wrapper;
    }

    // 获取设备类型
    function getDeviceType() {
        var _Type = 'Pc';
        if (window.getComputedStyle) {
            var bodyMark = window.getComputedStyle(document.body, ":after").getPropertyValue("content");
            _Type = /Mobile/.test(bodyMark) ? 'Mobile' : (/Padp/.test(bodyMark) ? 'Padp' : (/Pad/.test(bodyMark) ? 'Pad' : 'Pc'));
        };
        return _Type;
    }

    module.exports = {
        extractMetadata: extractMetadata,
        getOptions: getOptions,
        getModulesPath: getModulesPath,
        getWrapper: getWrapper,
        getDeviceType: getDeviceType
    }
});