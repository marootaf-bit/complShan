/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');

	$(window).resize(function (event) {
		bianhua();
	});

	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);

	var st = null;
	function isIE() {
		return window.document.documentMode ? true : false;
	}
	function bianhua() {
		if (st) {
			st.kill();
			st = null;
		}
		$('.news_detail02 .right .item1').css({ 'transition': 'all .5s ease' });
		$('.news_detail02 .right .item2').css({ 'margin-bottom': 0 });
		if (base.getType() == "Pc" && !isIE()) {
			var gap = parseInt($('.news_detail02 .right .item').css('marginBottom').replace('px', ''));
			var startOffset = $('.header').height() + gap;
			var endOffset = $('.news_detail02 .right').height() + startOffset;
			st = ScrollTrigger.create({
				trigger: '.news_detail02 .left',
				start: 'top-=' + startOffset + 'px top',
				endTrigger: '.news_detail02 .left .bott',
				end: 'bottom-=' + endOffset + 'px top',
				pin: '.news_detail02 .right',
				onUpdate: function (self) {
					if ($('.header').hasClass('fixed')) {
						$('.news_detail02 .right .item1').css({ 'margin-top': '0' });
					} else {
						$('.news_detail02 .right .item1').css({ 'margin-top': '0' });
					}
				},
				onLeaveBack: function () {
					$('.news_detail02 .right .item1').css({ 'margin-top': '0' });
				}
			});
		} else {
			$('.news_detail02 .right .item1').css({ 'margin-top': '0' });
		}
	}

	bianhua();

	require('box');
	//新闻订阅提交
	$('#emailInput')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			var input = $('#emailInput')[0];
			if (input.value === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
				return false; // 阻止提交
			}
		}
	}
	$('#emailsubmit').click(function () {
		var email = $('#emailInput').val();
		$.post("/ext/from_dingyue.jsp", { email: email }, function (data) {
			if ($.trim(data) == 'ok') {
				$.box.alert("Successfully submitted, thank you for your subscription!", null, {
					title: "Successfully submitted"
				})
				$('#emailInput').val("");
			} else if ($.trim(data) == 'notemail') {
				$.box.alert("Incorrect email format!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'exit') {
				$.box.alert("The email has already submitted a subscription!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'outsize') {
				$.box.alert("The number of submissions today has exceeded the limit!", null, {
					title: "Verification Failed"
				})
			}
		})
	})


});