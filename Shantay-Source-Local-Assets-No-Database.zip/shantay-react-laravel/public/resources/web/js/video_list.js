/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var parentId = filterXSS($('#parentId').val());
	var catId = '', key = '';


	// 判断竖线
	$('.video_list02 .top .left .btns').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index();
		$('.video_list02 .top .left .btns').eq(i-2).addClass('prev').siblings().removeClass('prev');
		catId = $(this).data('id');
		key = '';
		$('.video_list02 .top .right .box .form_item .inp.key').val('');
		getData();
	}).eq(0).trigger('click')

	$('.video_list02 .top .right .box .form_item .inp')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			key = filterXSS($('.video_list02 .top .right .box .form_item .inp.key').val());
			if (key === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
			}else{
				getData();
			}
		}
	}

	$('.video_list02 .top .right .box .form_item .key_btn').on('click', '', function (event) {
		key = filterXSS($('.video_list02 .top .right .box .form_item .inp.key').val());
		if (key === "") {
			$.box.alert("Information cannot be empty!", null, {
				title: "Hint"
			})
		}else{
			getData();
		}
	});

	function getData() {
		$.post("/ext/ajax_video.jsp", { flag: "getData", parentId: parentId, catId: catId, key: key }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
			} else {
				$("#container").html('No Data!');
			}
			$('.video_list01 .box').each(function () {
				$(this).data('v').length > 0 ? $(this).addClass('hasVideo') : false;
			});
			$('.video_list02 .bott li .box').each(function () {
				$(this).data('v').length > 0 ? $(this).addClass('hasVideo') : false;
			});
		});
	}

	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);

	var slideTimer = 5000;
	var interleaveOffset = 0.5;
	var Swiper01 = new Swiper('.video_list01 .swiper-container', {
		loop: true,
		init:false,
		autoplay: {
			delay: slideTimer,
		},
		slidesPerView: 1,
		speed: 1500,
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
			renderBullet: function (index, className) {
				return '<div class="bullet_outer ' + className + '"><span class="process"></span></div>';
			}
		},
		on: {
			slideChange: function () {
				$('.video_list01 .swiper-pagination-bullet').removeClass('play');
				$('.video_list01 .swiper-pagination-bullet-active').addClass('play');
			},
			slideChangeTransitionStart: function () {
				var nextSlide = this.slides.eq(this.activeIndex);
				gsap.set(nextSlide.find('.cover .t'), { x: 0, autoAlpha: 1 });
				gsap.set(nextSlide.find('.cover .btns'), { x: 0, autoAlpha: 1 });
				gsap.from(nextSlide.find('.cover .t'), 2, { x: -100, autoAlpha: 0, ease: Power4.easeOut, delay: 0.5 });
				gsap.from(nextSlide.find('.cover .btns'), 2, { x: -100, autoAlpha: 0, ease: Power4.easeOut, delay: 1 });
			},
		},
		breakpoints: {
			780: { 
					slidesPerView: 1,
					spaceBetween: 10,
			},
		}
	})
	$(function () {
		$('.video_list01 .process').css({ "transition-duration": slideTimer + 'ms' });
		$('.video_list01 .swiper-pagination-bullet-active').addClass('play');
	});
	// 判断swiper-slide的数量
	if ($('.video_list01 .swiper-slide').length > 1) {
		Swiper01.init(); 
	}


	// 视频弹窗
	require('box');
	require('video');
	// 变量定义
	var video_width, video_height;

	// 屏幕类型改变后执行的代码
	$('body').on("screenChanged", function () {
		multiScreenJs(base.getType());
	});
	multiScreenJs(base.getType());
	function multiScreenJs(tempType) {
		if (tempType == 'Pc') {
			// 56.25%
			video_width = 960;
			video_height = 540;
		} else if (tempType == "Pad" || tempType == "Padp") {
			video_width = 760;
			video_height = 427;
		} else {
			video_width = '100%';
			video_height = 300;
		}
	}
	// 屏幕类型改变后执行的代码 end
	var videoControl;
	if (base.browser.ie > 8 || base.browser.ie == 0) {
		videoControl = true
	} else {
		videoControl = false
	}
	$('body').on('click', '.hasVideo', function () {
		if ($.trim($(this).data('v'))) {
			//e.preventDefault();
			var tmp = $(this).data('v');
			var videoId = 'video' + Math.floor(Math.random() * 100000);
			if (tmp.indexOf(".mp4") != -1) {
				//console.log('本地视频')
				// 本地视频dom
				var _dom = '<a id="about-close" class="about-video-close" '
					+ 'style="position: absolute; top: 5px; right: 5px; background: url(/resources/web/img/about_close.png); display: block; width: 22px; height: 22px; z-index: 5; cursor: pointer;">'
					+ '</a>'
					+ '<video id=' + videoId + ' class="video-js vjs-default-skin" oncontextmenu="return false;" loop>'
					+ '<source src=' + tmp + ' type="video/mp4">'
					+ '</video>';

				var player;
				$.box(_dom, {
					width: video_width != '100%' ? video_width : $(window).width(),
					height: video_height + 40,
					hook: 'i_video_box',
					layout: false,
					// 本地视频回调
					onshow: function () {
						player = videojs(videoId, {
							width: video_width != '100%' ? video_width : $(window).width(),
							height: video_height,
							poster: '',
							controls: videoControl,
							autoplay: true,
							preload: 'auto',
							bar: false
						});
						$('.vjs-big-play-button').trigger('click');
						$('.i_video_box').find('#about-close').click(function () {
							$.box.hide();
						})
					}
				});

			} else {
				//console.log('第三方视频')
				// 第三方视频dom
				var _dom = '<a id="about-close" class="about-video-close" '
					+ 'style="position: absolute; top: 5px; right: 5px; background: url(/resources/web/img/about_close.png); display: block; width: 22px; height: 22px; z-index: 5; cursor: pointer;">'
					+ '</a>'
					+ '<iframe height="100%" width="100%" frameborder="0" allowfullscreen="true"'
					+ ' src="' + tmp + '"></iframe>';

				var player;
				$.box(_dom, {
					width: video_width != '100%' ? video_width : $(window).width(),
					height: video_height + 40,
					hook: 'i_video_box',
					layout: false,

					// 第三方视频回调
					onshow: function () {
						$('.i_video_box').find('#about-close').click(function () {
							$.box.hide();
						})
					}
				});
			}
		}
	});

	function filterXSS(s) {
		s = s.toLowerCase().replace("<\\s*img\\s+([^>]*)\\s*>", "").replace("<[^<|^>]+>", "").replace("delete", "").replace("insert", "").replace("update", "").replace("select", "").replace("<", "").replace(">", "").replace("script", "").replace("or", "").replace("and", "").replace("iframe", "").replace("href", "").replace(".*([';]+|(--)+).*", " ").replace("alert", "").replace("if", "").replace("mousewheel", "").replace("mouseover", "").replace("click", "").replace("load", "").replace("onload", "").replace("blur", "").replace("start", "").replace("on", "").trim();
		return s;
	}

});