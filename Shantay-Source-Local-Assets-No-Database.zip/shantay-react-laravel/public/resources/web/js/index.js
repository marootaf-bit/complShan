/**
 * index
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');

	// 地区选择
	// 关闭
	// $('.location_choose .content .right .close_btns').on('click', function () {
	// 	$('.location_choose').addClass('up').slideUp(300)

	// })
	// 一级下拉
	$('.location_choose .content .right .form_item .sel_div').on('click', function () {
		if ($(this).hasClass('cur')) {
			$(this).siblings('.sel_down').stop().slideUp();
			$(this).removeClass('cur');
		} else {
			$(this).addClass('cur');
			$(this).siblings('.sel_down').stop().slideDown();
			$(this).siblings('.sel_down').find('.box').eq(0).addClass('cur').siblings().removeClass('cur');
		}
	})

	// 二级下拉
	$('.location_choose .content .right .form_item .sel_down .box').on('mouseenter', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index()
		$('.location_choose .content .right .form_item .sel_down .cont01').eq(i).show().siblings().hide()
	}).eq(0).trigger('mouseenter')

	// 同意cookie横条
	if ($.cookie('COOKIE_BAR_HIDE') != 'true') {
		$('.location_choose').removeClass('hide');
		$('.header').addClass('index');
		$('.ibanner').removeClass('mt');
	}
	$('.location_choose .content .right .close_btns').on('click', function () {
		$('.location_choose').addClass('hide');
		$.cookie('COOKIE_BAR_HIDE', 'true');
		$('.header').removeClass('index').addClass('fixed');
		$('.ibanner').addClass('mt');
	});
	$('.location_choose .content .right .form_btns').on('click', function () {
		$('.location_choose').addClass('hide');
		$.cookie('COOKIE_BAR_HIDE', 'true');
		$('.header').removeClass('index').addClass('fixed');
		$('.ibanner').addClass('mt');
	});

	// 同意cookie横条
	if ($.cookie('COOKIE_HIDE') != 'true') {
		$('.cookie_box').removeClass('hide');
	}
	$('.cookie_box .content .btns_box .accep').on('click', function () {
		$('.cookie_box').addClass('hide');
		$.cookie('COOKIE_HIDE', 'true');
	});
	$('.cookie_box .content .btns_box .refu').on('click', function () {
		$('.cookie_box').addClass('hide');
	});

	// 导航吸顶
	$(window).scroll(function () {
		if ($('.location_choose').hasClass('hide')) {
			$('.header').removeClass('index');
			if ($(window).scrollTop() > 0) {
				$('.header').addClass('fixed');
				$('.ibanner').removeClass('mt');
			} else {
				$('.header').removeClass('fixed');
				$('.ibanner').addClass('mt');
			}
		} else {
			var top = $('.location_choose').outerHeight();
			if ($(window).scrollTop() > top) {
				$('.header').removeClass('index');
				$('.ibanner').addClass('mt');
			} else {
				$('.header').addClass('index');
				$('.ibanner').removeClass('mt');
			}
		}
	})


	if (base.getType() == 'Mobile') {
		$('.ibanner .swiper-slide.video_slide').remove();
	};


	// banner
	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);

	var slideTimer = 5000;
	var bannerTimeOut;
	var bannerSwiper = new Swiper('.ibanner .swiper-container', {
		loop: true,
		// autoplay: {
		// 	delay: slideTimer,
		// },
		slidesPerView: 1,
		speed: 1500,
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
		},
		on: {
			init: function () {
				var intTimeOut = $('.ibanner .swiper-slide-active').data('second')
				console.log(intTimeOut)
				bannerTimeOut = setTimeout(function () {
					bannerSwiper.slideNext();
				}, intTimeOut);
			},
			slideChangeTransitionStart: function () {
				clearTimeout(bannerTimeOut);
				var intTimeOut = $('.ibanner .swiper-slide-active').data('second')
				console.log(intTimeOut)
				bannerTimeOut = setTimeout(function () {
					bannerSwiper.slideNext();
				}, intTimeOut);
				var nextSlide = this.slides.eq(this.activeIndex);
				gsap.set(nextSlide.find('.cover .words'), { x: 0, autoAlpha: 1 });
				gsap.set(nextSlide.find('.cover .more_btn'), { x: 0, autoAlpha: 1 });
				gsap.from(nextSlide.find('.cover .words'), 2, { x: -100, autoAlpha: 0, ease: Power4.easeOut, delay: 0.5 });
				gsap.from(nextSlide.find('.cover .more_btn'), 2, { x: -100, autoAlpha: 0, ease: Power4.easeOut, delay: 1 });
			},
		}
	})

	//banner箭头
	var xx;
	var yy;
	var text_over_current = true;
	bannerMouse = function () {
		$('.ibanner').mousemove(function (e) {
			if (text_over_current) {
				var winW = $(window).outerWidth();
				xx = e.originalEvent.x || e.originalEvent.layerX || 0;
				yy = e.originalEvent.y || e.originalEvent.layerY || 0;
				$('.cursor').stop().fadeIn(300).css({
					'top': yy - 12,
					'left': xx - 21
				});
				if (xx > winW / 2) {
					$('.cursor').addClass('right');
				} else {
					$('.cursor').removeClass('right');
				}
			}
		}).mouseleave(function (event) {
			$('.cursor').stop().fadeOut(300);
		});
	};
	bannerMouse();

	bannerClick = function () {
		$('.ibanner').click(function (e) {
			e.preventDefault();
			if (text_over_current) {
				if ($('.cursor').hasClass('right') !== (document.documentElement.dir === 'rtl')) {
					bannerSwiper.slideNext();
				} else {
					bannerSwiper.slidePrev();
				}
			}
		});
	}
	bannerClick();

	$('.ibanner').find('.more_btn').mouseover(function (event) {
		$('.ibanner').unbind();
		$('.cursor').fadeOut();
		// console.log("移上了");
	}).mouseleave(function (event) {
		bannerClick();
		bannerMouse();
		$('.cursor').fadeIn();
	});

	$('.ibanner').find('.cover_box').mouseover(function (event) {
		$('.ibanner').unbind();
		$('.cursor').fadeOut();
		// console.log("移上了");
	}).mouseleave(function (event) {
		bannerClick();
		bannerMouse();
		$('.cursor').fadeIn();
	});

	//  Banner适应窗口大小
	bannerResize = function () {
		// 首页banner
		var winH = $(window).outerHeight();
		var winW = $(window).outerWidth();
		var imgscale = winW / (winH)

		var imgHeight = $('.ibanner .swiper-container .iban_img').outerHeight()
		// $('.ibanner').width(winW);
		console.log(imgHeight)
		$('.ibanner').height(imgHeight);
		$('.ibanner .swiper-container').height(imgHeight);
		//$('.ibanner .swiper img').height(winH);
		if (base.getType() == 'Mobile') {
			$('.ibanner').css('height', 'auto');
			$('.ibanner .swiper-container').css('height', 'auto');
		}

	}

	bannerResize();
	$(window).on('resize', bannerResize);

	// ipart01
	var ipartSwiper = new Swiper('.ipart01 .new_top .swiper-container', {
		loop: false,
		slidesPerView: 6,
		spaceBetween: 30,
		scrollbar: {
			el: '.swiper-scrollbar',
			draggable: true,
		},
		breakpoints: {
			1440: {
				slidesPerView: 5,
			},
			1240: {
				slidesPerView: 4,
			},
			780: {
				slidesPerView: 3,
			},
			480: {
				slidesPerView: 'auto',
			},
		}
	})


	$('.ipart01 .new_top .click_btns').click(function (e) {
		ipartSwiper.slideNext();
	});
	$('.ipart01 .new_top .click_btns2').click(function (e) {
		ipartSwiper.slidePrev();
	});

	$.post("/ext/ajax_index.jsp", { flag: "proList" }, function (data) {
		$('.ipart01 .bott .cont ul').html(data);
	});

	// $.post("/ext/ajax_index.jsp", { flag: "newsList" }, function (data) {
	// 	$('.ipart05 .left .bott ul').html(data);
	// });
	var newsId1 = $('.ipart05 .left .bott li .key01').data('id');
	$.post("/ext/ajax_index.jsp", { flag: "newsKeyList", data: newsId1 }, function (data) {
		$('.ipart05 .left .bott li .key01').html(data);
	});

	var newsId2 = $('.ipart05 .left .bott li .key02').data('id');
	$.post("/ext/ajax_index.jsp", { flag: "newsKeyList", data: newsId2 }, function (data) {
		$('.ipart05 .left .bott li .key02').html(data);
	});

	var newsId3 = $('.ipart05 .left .bott li .key03').data('id');
	$.post("/ext/ajax_index.jsp", { flag: "newsKeyList", data: newsId3 }, function (data) {
		$('.ipart05 .left .bott li .key03').html(data);
	});

	// $.post("/ext/ajax_index.jsp", { flag: "caseList" }, function (data) {
	// 	$('.ipart03 .bott ul').html(data);
	// });

	// 产品按钮触控效果遍历
	$('.ipart01 .bott li .words_box .btns_ a').on('mouseenter', function () {
		$(this).addClass('cur').siblings().removeClass('cur')
	}).eq(0).trigger('mouseenter')


	require('box');
	// 新闻订阅提交
	$('#emailInput2')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			var input = $('#emailInput2')[0];
			if (input.value === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
				return false; // 阻止提交
			}
		}
	}
	$('#emailsubmit2').click(function () {
		var email = $('#emailInput2').val();
		$.post("/ext/from_dingyue.jsp", { email: email }, function (data) {
			if ($.trim(data) == 'ok') {
				$.box.alert("Successfully submitted, thank you for your subscription!", null, {
					title: "Successfully submitted"
				})
				$('#emailInput2').val("");
			} else if ($.trim(data) == 'notemail') {
				$.box.alert("Incorrect email format!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'exit') {
				$.box.alert("The email has already submitted a subscription!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'outsize') {
				$.box.alert("The number of submissions today has exceeded the limit!", null, {
					title: "Verification Failed"
				})
			}
		})
	})

	//数字滚动效果
	require('animate-number');
	var numberBox = $('.ipart04 .big_num '),//获取父元素
		scrollHeight = numberBox.offset().top - $(window).height() + 160;//距文档顶部距离-屏幕高度+自身高度=滚动条滚去这个高度正好出现在屏幕中


	var _num01 = $('.ipart04 .big_num .num01 ').text();//获取number1里面的数值
	var _num02 = $('.ipart04 .big_num .num02 ').text();
	var _num03 = $('.ipart04 .big_num .num03 ').text();


	//主变化函数changeGo
	var changeGo = function () {
		if ($(window).scrollTop() - $(window).height() / 4 > scrollHeight) {
			$('.ipart04 .big_num .num01 ').stop().prop('number', 0).animateNumber({ number: _num01 }, 1000);
			$('.ipart04 .big_num .num02 ').stop().prop('number', 0).animateNumber({ number: _num02 }, 1000);
			$('.ipart04 .big_num .num03 ').stop().prop('number', 0).animateNumber({ number: _num03 }, 1000);
			$(window).off('scroll', changeGo);//解除事件绑定    
		}
	}
	$(window).on('scroll', changeGo);

})
