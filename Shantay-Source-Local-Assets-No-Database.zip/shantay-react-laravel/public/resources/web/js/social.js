/**
 * blank
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  
	if(window.swiper){
		swiper.on('slideChange', function() {
			this.snapGrid = this.slidesGrid.slice(0);
		});
		swiper.update();
	}

  //侧边导航
	function asideNav() {
		if ($(".aside_navline").length < 1) {
			$('<span class="aside_navline"><span>').appendTo(".aside_nav")
		}
		var topArr = [];
		var navHeight = $(".header").height();
		var start = $(".social_item.social01").offset().top - navHeight + $('.social_item.social01').innerHeight();
		var parH = $(".social").innerHeight() - navHeight + parseInt($(".social_item").css('marginTop'));
		$(".social_item").each(function () {
			var top = $(this).offset().top - parseInt($(this).find('.img_').css('marginTop'));
			topArr.push(top);
			console.log(topArr)
		});
		$(window).resize(function () {
			getPara();
		})
		// 进入页面初始化


		// 滚动事件监听
		$(window).scroll(function () {
			// 导航位置
			asideNavTb()
		});
		function getPara() {
			$(".social_item").each(function () {
				var top = $(this).offset().top - parseInt($(this).find('.top_').css('marginTop'));
				topArr.push(top);
			});
			navHeight = $(".header").height();
			start = $(".item_list").offset().top - navHeight;
			var parH = $(".social").innerHeight() - navHeight + parseInt($(".social_item").css('marginTop'));
		}

		//左侧样式同步
		function asideNavTb() {
			for (var i = 0; i < topArr.length; i++) {
				if ($(window).scrollTop() > topArr[i] - $(window).height() / 1.5) {
					// var img_width = $('.social_item .img_').width();
			
					sr.reveal('.social_item .content', srobj.right);
				} 
			}
		}

	}
	asideNav();


  
});