/**
 * 关于山推
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  
  
  
});