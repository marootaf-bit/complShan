/**
 * blank
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  

	// 视频弹窗
	require('box');
	require('video');
	// 变量定义
	var video_width,video_height;
  
	// 屏幕类型改变后执行的代码
	$('body').on("screenChanged",function(){
		multiScreenJs(base.getType());
	});
	multiScreenJs(base.getType());
	function multiScreenJs(tempType){
		if (tempType == 'Pc') {
			// 56.25%
			video_width = 960;
			video_height = 540;
		}else if(tempType == "Pad" || tempType == "Padp"){
			video_width = 760;
			video_height = 427;
		}else {
			video_width = '100%';
			video_height = 300;
		}
	}
	// 屏幕类型改变后执行的代码 end
  
	$('.strength01 .bott .btns').each(function(){
	  $(this).data('v').length > 0 ? $(this).addClass('hasVideo') : false;
	});
  
	var videoControl;
	  if (base.browser.ie > 8 || base.browser.ie == 0) {
		  videoControl = true
	  }else{
		  videoControl = false
	  }
	$('body').on('click','.hasVideo',function(){
	  if($.trim($(this).data('v'))){
		  //e.preventDefault();
		  var tmp=$(this).data('v');
		  var videoId='video'+Math.floor(Math.random()*100000);
		  if(tmp.indexOf(".mp4")!=-1){
			//console.log('本地视频')
			// 本地视频dom
			var _dom ='<a id="about-close" class="about-video-close" '
			+ 'style="position: absolute; top: 5px; right: 5px; background: url(/resources/web/img/about_close.png); display: block; width: 22px; height: 22px; z-index: 5; cursor: pointer;">'
			+ '</a>'
			+ '<video id='+videoId+' class="video-js vjs-default-skin" oncontextmenu="return false;" loop>'
			+ '<source src='+tmp+' type="video/mp4">'
			+ '</video>';
  
			var player;
			$.box( _dom,{
			  width:video_width != '100%' ? video_width : $(window).width(),
			  height:video_height+40,
			  hook:'i_video_box',
			  layout:false,
			  // 本地视频回调
			  onshow:function(){
				player = videojs(videoId, {
				  width: video_width != '100%' ? video_width : $(window).width(),
				  height: video_height,
				  poster: '',
				  controls: videoControl,
				  autoplay:true,
				  preload:'auto',
				  bar:false
				});
				$('.vjs-big-play-button').trigger('click');
				$('.i_video_box').find('#about-close').click(function(){
					$.box.hide();
				})
			  }
			});
  
		  }else{
			//console.log('第三方视频')
			// 第三方视频dom
			var _dom ='<a id="about-close" class="about-video-close" '
			+ 'style="position: absolute; top: 5px; right: 5px; background: url(/resources/web/img/about_close.png); display: block; width: 22px; height: 22px; z-index: 5; cursor: pointer;">'
			+ '</a>'
			+ '<iframe height="100%" width="100%" frameborder="0" allowfullscreen="true"'
			+ ' src="' + tmp + '"></iframe>';
  
			var player;
			$.box( _dom,{
			  width:video_width != '100%' ? video_width : $(window).width(),
			  height:video_height+40,
			  hook:'i_video_box',
			  layout:false,
  
			  // 第三方视频回调
			  onshow:function(){
				$('.i_video_box').find('#about-close').click(function(){
					$.box.hide();
				})
			  }
			});
		  }
		}
	});


	$('.strength02 .content .right li').on('mouseenter',function(){
		$(this).addClass('no')
		$(this).find('video')[0].play()
	})
	$('.strength02 .content .right li').on('mouseleave',function(){
		$(this).removeClass('no')
		// $(this).find('video')[0].load();
		$(this).find('video')[0].pause()
	})

	var Swiper01 = new Swiper('.strength03 .bott .swiper-container', {
        slidesPerView: 3,
        // init: false,
        spaceBetween: 10,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
	});
	// 判断swiper-slide的数量
	if ($('.strength03 .bott .swiper-slide').length < 4) {
		$('.strength03 .bott .swiper-button-next').hide()
		$('.strength03 .bott .swiper-button-prev').hide()
	}

  
});