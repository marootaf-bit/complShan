/**
* name: common
* version: v3.0.1
* update: 去掉console报错处理，在base.js有新的处理代码，因为base.js中也有console并在common.js之前执行
* date: 2017-08-11
*/
define(function (require, exports, module) {
    var $ = require('jquery');
    var base = require('base');
    var typeCatch = base.getType();
    //产品下拉
    var pid = '', cid = "";

    if (base.browser.ie < 7) {
        alert('您的浏览器版本过低，请升级或使用chrome、Firefox等高级浏览器！');
    }

    $('body').attr('data-w', $('body').outerWidth());
    // var throttleResize = base.throttle(function(){
    //     // if(base.getType()!=='Pc'){
    //     var new_width = $('body').outerWidth();
    //     if(new_width !== $('body').data('w')){
    //     document.location.reload()
    //     }
    //     //}
    // });
    // $(window).on('resize',function(){
    //     throttleResize();
    // });

    //字号调节
    var $speech = $('.myart:visible'),
        defaultsize = parseFloat($speech.css('font-size'));
    if ($speech.length) {
        //window.localStorage &&  localStorage.getItem('fz') && $speech.css('font-size', localStorage.getItem('fz')+'px');
        $('body').on('click', '#switcher a', function () {
            var num = parseFloat($speech.css('font-size'));
            switch (this.id) {
                case 'small': num /= 1.4
                    break
                case 'big': num *= 1.4
                    break
                default: num = defaultsize
            }
            $speech.css('font-size', num + 'px');
            //window.localStorage && localStorage.setItem('fz',num);
        });
    }

    //页面平滑滚动
    if (base.getType() == 'Pc') {
        if (base.browser.ie > 8) {
            require('smoothscroll');
        }
    }

    //图片懒加载
    require('scroll-loading');
    $("img").scrollLoading({
        attr: "data-url"
    });

    /*
    * 常用工具
    */
    //返回顶部
    $('body').on('click', '.gotop', function () { $('html,body').stop(1).animate({ scrollTop: '0' }, 300); return false });
    //关闭当前页
    $('body').on('click', '.closewin', function () { window.opener = null; window.open("", "_self"); window.close() });
    //打印当前页
    $('body').on('click', '.print', function () { window.print() });
    //加入收藏
    $('body').on('click', '.favorite', function () { var sURL = "http:&#47;&#47;" + document.domain + "&#47;", sTitle = document.title; try { window.external.addFavorite(sURL, sTitle) } catch (e) { try { window.sidebar.addPanel(sTitle, sURL, "") } catch (e) { alert("加入收藏失败，请使用Ctrl+D进行添加") } } });
    //设为首页
    $('body').on('click', '.sethome', function () { var vrl = "http:&#47;&#47;" + document.domain + "&#47;"; if (window.netscape) { try { netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect") } catch (e) { alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。") } var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch); prefs.setCharPref('browser.startup.homepage', vrl) } else { alert("您的浏览器不支持自动设为首页，请您手动进行设置！") } });
    //屏蔽ie78 console未定义错误
    // if (typeof console === void(0)) {
    //     console = { log: function() {}, warn: function() {} };
    // };
    //textarea扩展max-length
    $('textarea[max-length]').on('change blur keyup', function () {
        var _val = $(this).val(), _max = $(this).attr('max-length');
        if (_val.length > _max) {
            $(this).val(_val.substr(0, _max));
        };
    });
    //延时显示
    $('.opc0').animate({ 'opacity': '1' }, 160);
    // placeholder
    $('input, textarea').placeholder();

    /*
    * 输出
    */
    module.exports = {
        demo: function () {
            console.log('hello ' + base.getType());
        }
    }

    /*
    * 站内公用
    */

    //导航当前状态 2.0后台需要使用
    //var jrChannelArr=jrChannel.split('#');
    //$('.nav').children('li').eq(jrChannelArr[0]).addClass('cur').find('li').eq(jrChannelArr[1]).addClass('cur');
    //分享
    //分享更多
    //   require('sharemore');
    // $('').sharemore({
    //  	type:'en'
    // });

    require.async('jrshare/jrshare', function () {
        $.jrshare.bshare();
    });
    //分享结束

    require('offcanvas');

    var $inav = $('.inav_wrapper').html();

    // 屏幕类型改变后执行的代码
    $('body').on("screenChanged", function () {
        multiScreenJs(base.getType());
    });
    multiScreenJs(base.getType());
    function multiScreenJs(tempType) {
        //按需渲染
        base.scanpush();
        //响应图片
        base.resImg();

        if (tempType == "Pc") {
            // 主导航
            if ($('.inav').length < 1) {
                $('.inav_wrapper').find('#menu').remove().end().append($inav);
                $('html').removeClass('mm-opened mm-opening');
            }
            $('.header .inav_wrapper').on('mouseenter', '.nav_li', function () {
                $(this).addClass('active').siblings().removeClass('active');
                $(this).find('.nav_down').addClass('nav_show');
                $(this).find('.nav_bg').stop().slideDown(500);
                $('.header_bg').stop().fadeIn();
                $(this).siblings().find('.nav_down').removeClass('nav_show');
                $(this).find('.pro_down').find('.pro_top').find('.pnav_li').eq(0).click();
                // ProDownSwiper01.update()
                // bgHeight()
            })
            $('.header .inav_wrapper').on('mouseleave', '.nav_li', function () {
                // $('.nav_bg').height(0);
                $('.header_bg').stop().fadeOut();
                $(this).find('.nav_down').removeClass('nav_show');
                $(this).find('.inav_a').removeClass('active');

            })
        } else {
            // 主导航 非Pc端
            $('.inav').offcanvas();
        }

        // 产品导航
        $(".header .nav_li.pro_nav .nav_down .pro_top .pnav_li").click(function (event) {
            $('.header .nav_li .nav_down.pro_down .pro_center .right ul').html('');
            event.stopPropagation();
            $(this).addClass("cur").parents('.swiper-slide').siblings().find('.pnav_li').removeClass("cur");
            pid = $(this).data('id');
            cid = '';
            getCat();
        })
    }

    // 产品导航第一部分
    var ProDownSwiper01 = new Swiper('.header .nav_li .nav_down.pro_down .pro_top .swiper-container', {
        slidesPerView: 'auto',
        init: false,
        spaceBetween: 10,
        freeMode: true,
        scrollbar: {
            el: '.swiper-scrollbar',
            draggable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });

    // 导航背景高度
    // function bgHeight() {
    //     var height = $('.header .nav_li.active').find('.nav_ul').outerHeight();
    //     var left01 = $('.header .h_tools').outerWidth() + rem(0.1);
    //     var width01 = $('.header .inav_wrapper').outerWidth();
    //     $('.nav_bg').height(height);
    //     $('.nav_bg').width(width01);
    //     // $('.nav_bg').css('right','calc(' +left01 + 'px'+'8.075%');
    // }

    // function rem(count) {
    //     var unit = $('html').css('font-size');

    //     if (typeof count !== 'undefined' && count > 0) {
    //         return (parseInt(unit) * count);
    //     }
    //     else {
    //         return parseInt(unit);
    //     }
    // };

    // 手机端下拉
    var topHeight = $('.location_choose').outerHeight() + $('.header').outerHeight()
    $('.header .mobile_key').on('click', function (event) {
        $('.location_choose').hide()
        $('.header .m_nav').stop().slideToggle(300);
        // $('.header').toggleClass('menu-open');  //控制三条线的变化
        if ($('.header').hasClass('menu-open')) {
            $('.header').removeClass('menu-open');
            $('body').height('auto');
            $('body').css('overflow', 'auto');
            $('body').css({ position: 'static' });

        } else {
            var topHeight2 = $('.header').outerHeight() - 1;
            $('.header').addClass('menu-open');
            $('body').height($(window).height());
            $('body').css('overflow', 'hidden');
            $('body').css({
                position: 'relative',
                right: '0',
                top: '0'
            });
            $('.header .m_nav').css('top', topHeight2 + 'px')
            // if ($('.location_choose').hasClass('up')) {
            //     $('.header .m_nav').css('top', topHeight2 + 'px')
            // } else {
            //     $('.header .m_nav').css('top', topHeight + 'px')
            // }
            if ($('.header .h_tools .h_sear').hasClass('on')) {
                $('.header .h_tools .h_sear').removeClass('on')
                $(".header .search_box").stop().slideUp();
            }
        }
    });

    // 手机端二级下拉
    $('.m_nav .mnav_bott').on('click', '.mnav_li', function (event) {
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $(this).find('.m_secNav').stop().slideUp();
        } else {
            $(this).addClass('active').siblings().removeClass('active');
            $('.m_nav .mnav_bott .mnav_li .m_secNav').slideUp();
            $(this).find('.m_secNav').stop().slideDown();
        }
    });


    // Bind once, not on every scroll event. The drawer follows page direction.
    var fixedNav = $(".right_nav"), fixedInSpan = fixedNav.find(".span-in");
    var fixedEdge = document.documentElement.dir === 'rtl' ? 'left' : 'right';
    function moveFixedNav(value, done) {
        var position = {}; position[fixedEdge] = value;
        fixedNav.stop(true, false).animate(position, 400, done);
    }
    fixedNav.off('click.dealerFixedNav').on('click.dealerFixedNav', '.top-li', function () {
        fixedNav.addClass('cur'); moveFixedNav('0', function () { fixedInSpan.show(); });
    }).on('click.dealerFixedNav', '.span-in', function () {
        fixedNav.removeClass('cur'); moveFixedNav('0.85rem', function () { fixedInSpan.hide(); });
    });
    function updateFixedNav() { fixedNav.toggleClass('fixed', $(window).scrollTop() > 200); }
    $(window).off('scroll.dealerFixedNav').on('scroll.dealerFixedNav', updateFixedNav);
    updateFixedNav();

    // 搜索
    $('.header .h_tools .h_sear').on('click', function () {
        if ($(this).hasClass('on')) {
            $(this).removeClass('on')
            $(".header .search_box").stop().slideUp();
        } else {
            $(".header .search_box").stop().slideDown();
            $('.header .h_tools .h_sear').addClass('on')
            if ($('.header').hasClass('menu-open')) {
                $('.header .m_nav').stop().slideUp(300);
                $('.header').removeClass('menu-open');
                $('body').height('auto');
                $('body').css('overflow', 'auto');
                $('body').css({ position: 'static' });

            }
        }
    });
    // $('.header').on('mouseleave', function () {
    //     $(".header .search_box").stop().slideUp();
    //     $('.header .h_tools .h_sear').removeClass('on')
    // });
    // Touch search stays click-controlled; hover handlers are bound once and
    // do not bubble between the input, form and suggested-search children.
    function searchHasHover() {
        return window.matchMedia('(min-width:1241px) and (hover:hover) and (pointer:fine)').matches;
    }
    $('.header .h_tools .h_sear').on('mouseleave', function () {
        if (!searchHasHover()) return;
        $(".header .search_box").stop().slideUp(300);
        $('.header .h_tools .h_sear').removeClass('on');
    });
    $('.header .search_box').on('mouseenter', function () {
        if (!searchHasHover()) return;
        $('.header .h_tools .h_sear').addClass('on');
        $(this).stop().slideDown();
    }).on('mouseleave', function () {
        if (!searchHasHover()) return;
        $('.header .h_tools .h_sear').removeClass('on');
        $(this).stop().slideUp(300);
    });

    // 语言版本下拉pc
    $('.header .h_tools .h_lan').on('click', function () {
        if ($(this).hasClass('cur')) {
            $(this).removeClass('cur');
            $('.header .lan_down.pc').stop().slideUp(0);
        } else {
            $(this).addClass('cur');
            if (base.getType() == 'Pc') {
                $('.header .lan_down.pc').stop().slideDown();
                $('.header .lan_down.pc .top .item').on('mouseenter', function () {
                    $(this).addClass('cur').siblings().removeClass('cur');
                    var i = $(this).index();
                    $('.header .lan_down.pc .center .cont01').eq(i).show().siblings().hide()
                    $('.header .lan_down.pc .bott .points li').eq(i).trigger('mouseenter')
                }).eq(0).trigger('mouseenter')
            } else {
                $('.header .lan_down.mobile').stop().slideDown();
                if ($('.header .h_tools .h_sear').hasClass('on')) {
                    $('.header .h_tools .h_sear').removeClass('on')
                    $(".header .search_box").stop().slideUp();
                }
                if ($('.header').hasClass('menu-open')) {
                    $('.header .m_nav').stop().slideUp(300);
                    $('.header').removeClass('menu-open');
                    $('body').height('auto');
                    $('body').css('overflow', 'auto');
                    $('body').css({ position: 'static' });
    
                }
            }
        }
        
    })


    $('.header .lan_down.mobile .content li').on('click', function () {
        if ($(this).hasClass('open')) {
            $(this).removeClass('open')
            $(this).find('dl').stop().slideUp();
        } else {
            $(this).addClass('open').siblings().removeClass('open')
            $(this).find('dl').stop().slideDown();
            $(this).siblings().find('dl').stop().slideUp();
        }
    }).eq(0).trigger('click');


    // 地图上点的触控事件
    var firstLink;
    $('.header .lan_down.pc .bott .points li').on('mouseenter',function () {
        var name1 = $(this).data('name');
        var i2;
        $(this).addClass('cur').siblings().removeClass('cur');
        var _index = $(this).index();
        $('.header .lan_down.pc .bott .map').eq(_index).addClass('cur').siblings().removeClass('cur');
        $('.header .lan_down.pc .top .item').each(function (e) {
            var name2 = $(this).data('name');
            if (name1 == name2) {
                $(this).addClass('cur').siblings().removeClass('cur');
                i2 = $(this).index();
            }
            $('.header .lan_down.pc .center .cont01').eq(i2).show().siblings().hide();
            var linkFa = $('.header .lan_down.pc .center .cont01').eq(i2);
            firstLink = linkFa.find('li').eq(0).find('a').attr('href');
        })
    })

    // pc地图上点的点击事件
    $('.header .lan_down.pc .bott .points li').on('click', function () {
        window.location.href = firstLink;
    })

    // 手机端点击关闭
    $('.header .lan_down.mobile .close_btn').on('click', function () {
        $('.header .h_tools .h_lan').removeClass('cur');
        $('.header .lan_down.mobile').stop().slideUp();
    })

    // 导航吸顶
    $(window).scroll(function () {
        if ($(window).scrollTop() > 0) {
            $('.header').addClass('fixed');
        } else {
            $('.header').removeClass('fixed');
        }
    })

    //点击显示右侧导航
    $('.header .h_tools .h_menu').on('click', function () {
        $('.lnb').addClass('on')
    })
    $('.lnb .lnb_bg').on('click', function () {
        $('.lnb').removeClass('on')
    })
    $('.btn_lnb_close').on('click', function () {
        $('.lnb').removeClass('on')
    })

    // 底部子公司
    $('.footer .f_top .t_right .company .box').on('click', function () {
        $('.f_company_xiala').stop().slideDown()
    })
    $('.f_company_xiala .content .colse_btn').on('click', function () {
        $('.f_company_xiala').stop().slideUp()
    })

    var lnbTopHeight = $('.lnb .lnb_top').outerHeight() + $('.lnb .lnb_bott .tit').outerHeight();
    $('.lnb .lnb_bott .con').css('height', 'calc(100vh - ' + lnbTopHeight + 'px)')


    function getCat() {
        $.post("/ext/ajax.jsp", { flag: "getCat", channelId: pid }, function (data) {
            if ($.trim(data)) {
                $('.header .nav_li .nav_down.pro_down .pro_center').removeClass('no_cat');
                $('.header .nav_li .nav_down.pro_down .pro_center .left').html(data);
                $(".header .nav_li.pro_nav .nav_down .pro_center .left .cnav_li .c_li_box").mouseenter(function (event) {
                    event.stopPropagation();
                    $(this).parents('.cnav_li').addClass("cur").siblings().removeClass("cur")
                    cid = $(this).parents('.cnav_li').data('id');
                    getPro();
                })
                $(".header .nav_li.pro_nav .nav_down .pro_center .left .cnav_li").eq(0).find('.c_li_box').trigger('mouseenter')
                // var pCHeight = $('.header .nav_li .nav_down.pro_down .pro_center').height();
                // console.log(pCHeight)
                return false;
            } else {
                $('.header .nav_li .nav_down.pro_down .pro_center').addClass('no_cat');
                $('.header .nav_li .nav_down.pro_down .pro_center .left').html('');
                getPro();
            }
        });
    }

    function getPro() {
        $.post("/ext/ajax.jsp", { flag: "getPro", channelId: pid, catId: cid }, function (data) {
            $('.header .nav_li .nav_down.pro_down .pro_center .right').html(data);
            // var heightOne = $('.header .nav_li .nav_down.pro_down .pro_center .rnav_li').outerHeight() * 2 + 1;
            // console.log(heightOne)
            // $('.header .nav_li .nav_down.pro_down .pro_center .right ul').css('max-height',heightOne+'px')

        });
    }

    require('box');
    try {
        document.getElementsByClassName('sear_inp')[0].onkeydown = function (event) {
            if (event.keyCode === 13) { // 如果按下的是回车键
                var input = document.getElementsByName("keywords")[0];
                if (input.value === "") {
                    $.box.alert("Information cannot be empty!", null, {
                        title: "Hint"
                    })
                    return false; // 阻止提交
                }
            }
        }
    } catch (err) { }

})