/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var channelId = $('#channelId').val();
	var catId = '';
	var pendingRequest, firstRequest=true;
window.addEventListener('popstate',function(){location.reload();});

	// 判断竖线
	$('.pro_list01 .top li').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index();
		$('.pro_list01 .top li').eq(i - 1).addClass('prev').siblings().removeClass('prev');
		catId = $(this).data('id');
		getData();
	});

	var url = window.location;
	var urlParams = new URLSearchParams(url.search);
	var cid = urlParams.get('cid');
	if (cid != '' && cid != undefined) {
		var selectedCategory = $('.pro_list01 .top li').filter(function () { return String($(this).data('id')) === cid; });
		(selectedCategory.length ? selectedCategory.eq(0) : $('.pro_list01 .top li').eq(0)).trigger('click');
	} else {
		$('.pro_list01 .top li').eq(0).trigger('click');
	}

    $('.pro_list01').on('click','.widgets_common_pages_4 [page]',function(e){e.preventDefault();getData($(this).attr('page'));});

	function getData(page) {
 var u=new URL(location.href);if(firstRequest)page=u.searchParams.get('page')||page;
 var next=String(catId||'');if(next)u.searchParams.set('cid',next);else u.searchParams.delete('cid');if(page)u.searchParams.set('page',page);else u.searchParams.delete('page');
 if(!firstRequest&&u.href!==location.href)history.pushState(null,'',u);firstRequest=false;
 if(parent!==window)parent.postMessage({type:'site-route-change',path:u.searchParams.get('path')||u.pathname,query:u.searchParams.toString(),hash:u.hash},location.origin);
		if (pendingRequest) pendingRequest.abort();
		pendingRequest = $.post("/ext/ajax_partsList.jsp", { flag: "getData", channelId: channelId, catId: catId, nowPage:page||'', q:u.searchParams.get('q')||'',sort:u.searchParams.get('sort')||'' }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
			} else {
				$("#container").html('No Data!');
			}
		});
	}

});