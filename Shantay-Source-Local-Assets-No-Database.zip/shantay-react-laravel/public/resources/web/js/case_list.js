/**
 * 工程案例
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var channelId = $('#channelId').val();
	var pro = "", solu = "", key = "";

	//getData();

	if (base.getType() == 'Mobile') {
		$('.case_list01 .content .filters .line').each(function () {
			$(this).on('click', '.btns', function () {
				if ($(this).parents('.right').find('ul').hasClass('more')) {
					console.log(1)
					$(this).parents('.right').find('ul').removeClass('more');
					$(this).parents('.right').find('.btns').removeClass('more')
					$(this).parents('.right').find('.more_btn span').html('Expand More');
				} else {
					console.log(2)
					$(this).parents('.right').find('ul').addClass('more');
					$(this).parents('.right').find('.btns').addClass('more')
					$(this).parents('.right').find('.more_btn span').html('Collapse List');
				}
			})
		})

	}

	require('box');
	$('.case_list01 .infor .search_box input')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			key = $('.case_list01 .infor .search_box input').val();
			if (key === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
			} else {
				getData();
			}
		}
	}

	$('.case_list01 .infor .search_box .search_btn').on('click', '', function (event) {
		key = $('.case_list01 .infor .search_box input').val();
		if (key === "") {
			$.box.alert("Information cannot be empty!", null, {
				title: "Hint"
			})
		} else {
			getData();
		}
	});

	// $.post("/ext/ajax_case.jsp", { flag: "getPro", channelId: channelId }, function (data) {
	// 	$('.case_list01 .content .filters .line .right ul.pro').html(data)
	// 	pro = $('.case_list01 .content .filters .line .right .pro .item.cur').data('id');
	// 	getData();
	// 	$('.case_list01 .content .filters .line .pro .item').on('click', function () {
	// 		$(this).addClass('cur').siblings().removeClass('cur');
	// 		pro = $(this).data('id');
	// 		getData();
	// 	})
	// });

	pro = $('.case_list01 .content .filters .line .right .pro .item.cur').data('id');
	getData();
	$('.case_list01 .content .filters .line .pro .item').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		pro = $(this).data('id');
		getData();
	})

	// $.post("/ext/ajax_case.jsp", { flag: "getSolu", channelId: channelId }, function (data) {
	// 	$('.case_list01 .content .filters .line .right ul.solu').html(data)
	// 	solu = $('.case_list01 .content .filters .line .right .solu .item.cur').data('id');
	// 	getData();
	// 	$('.case_list01 .content .filters .line .solu .item').on('click', function () {
	// 		$(this).addClass('cur').siblings().removeClass('cur');
	// 		solu = $(this).data('id');
	// 		getData();
	// 	})
	// });

	solu = $('.case_list01 .content .filters .line .right .solu .item.cur').data('id');
	getData();
	$('.case_list01 .content .filters .line .solu .item').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		solu = $(this).data('id');
		getData();
	})

	function getData() {
		$.post("/ext/ajax_case.jsp", { flag: "getData", pro: pro, solu: solu, key: key }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
			} else {
				$("#container").html('No Data!');
			}
			// 判断高度
			widthResize = function () {
				var height01 = 0;
				$('.case_list01 .content .list .item .intro_box').attr('style', '');
				$('.case_list01 .content .list .item').each(function () {
					var inforHeight = $(this).find('.intro_box').height();
					if (inforHeight > height01) {
						height01 = inforHeight
					}
					console.log(1)
				})
				$('.case_list01 .content .list .item .intro_box').height(height01)

			}
			if (base.getType() != 'Mobile') {
				widthResize();
				$(window).on('resize', widthResize);
			}
		});
	}

});
