/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var indexArr = [];
	var docCount = $('#docCount').val();

	$('.pro_detail01 .left .btns_box .btns').on('mouseenter', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
	}).eq(0).trigger('mouseenter');

	$('.pro_detail02 .btns_box .btns').on('mouseenter', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
	}).eq(0).trigger('mouseenter');

	//pro_detail02 滚动监听
	require('on-scroll');
	$('.section').onScroll({
		offset: 100,
		targetFix: '.pro_detail02 .hd .list',
		target: '.pro_detail02 .hd .list ul',
		targetCell: 'li',
	});

	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);
	// var goHeight01 = $('.pro_detail02 .bd .bd01').css('padding-bottom');
	// var headerHeight = $('.header').outerHeight()
	// if (window.matchMedia('(min-width: 1101px) and (hover: hover)').matches) {
	// 	new ScrollTrigger({
	// 		trigger: '.pro_detail01',
	// 		start: 'top top+=' + headerHeight + 'px',
	// 		pin: '.pro_detail01 .right',
	// 		endTrigger: '.pro_detail02 .bd .bd01',
	// 		end: 'center center-=40px',
	// 		pinSpacing: false
	// 	});
	// }

	// The dealership hero deliberately keeps its machine image inside the hero.
	// The inherited pin + forced hero positioning compounded widths and left a
	// vacant desktop feature column. Use normal document flow at every size.

	// 滚动判断
	// var lastScrollTop = 0;
	// $(window).scroll(function () {
	// 	var height01 = $('.pro_detail01').outerHeight()
	// 	var st = $(this).scrollTop();
	// 	if (st <= lastScrollTop) {// 向上.
	// 		$('.header').removeClass('gout');
	// 		if ($('.pro_detail02 .hd').hasClass('fixed')) {
	// 			// $('.pro_detail02 .hd').css('top', $('.header').outerHeight())
	// 			// $('.pro_detail02 .bd').css('top',$('.pro_detail02 .hd').outerHeight())
	// 			// $('.pro_detail02 .bd').css('padding-bottom',$('.pro_detail02 .hd').outerHeight())
	// 		} else {
	// 			// $('.pro_detail02 .hd').css('top', '0')
	// 			// $('.pro_detail02 .bd').css('top',0)
	// 			// $('.pro_detail02 .bd').css('padding-bottom',0)
	// 		}
	// 	} else {
	// 		$('.header').addClass('gout')
	// 		if ($('.header').hasClass('gout')) {
	// 			// $('.pro_detail02 .hd').css('top', '0')
	// 		}
	// 	}

	// 	lastScrollTop = st;
	// })
	var height01 = $('.pro_detail01').outerHeight()
	$(window).scroll(function () {
		if ($(window).scrollTop() > height01) {
			$('.header').addClass('gout');
		} else {
			$('.header').removeClass('gout');
		}
	})

	$('.pro_detail02 .bd .bd05 .right .agree_btn').click(function () {
		//选中时值改成1
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur');
			$(this).find('.allow').val(0);
		} else {
			$(this).find('.allow').val(1);
			$(this).addClass('cur')
		}
	})

	$('.tc2 .box form .agree_btn').click(function () {
		//选中时值改成1
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur');
			$(this).find('.allow').val(0);
		} else {
			$(this).find('.allow').val(1);
			$(this).addClass('cur')
		}
	})

	// 图片视频切换
	$('.pro_detail02 .bd .bd04 .tab_t_box .tab_t').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index();
		$('.pro_detail02 .bd .bd04 .tab_c_box .tab_c').eq(i).show().siblings().hide()
	}).eq(0).trigger('click')

	// 没有验证码
	require('validform');
	require('box');
	//验证码	
	$('#changeImage1').on('click', function () {
		this.src = $(this).attr('src') + '?now=' + new Date();
	})
	$('.pro_detail02 .bd .bd05 .right #theForm').Validform({
		btnSubmit: "sub_btn",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.pro_detail02 .bd .bd05 .right .agree_btn .allow').val();
			if (agreeChkBoxes != 1) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () { window.location.reload(); }, {
					title: "Submitted successfully"
				})
			} else if (data == 'countMore') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});

	// 下载选中
	$('.tc_down .choose li').click(function () {
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur')
		} else {
			$(this).addClass('cur')
		}
	})

	// 关闭弹窗
	$('.tc_down .close_btn').on('click', function () {
		$('.tc_down').hide()
		$('.tc_bg').hide()
		// indexArr = [];
	})

	$('.tc_down .btns').click(function () {
		var formatList = [];
		$('.tc_down .choose li.cur').each(function () {
			thisId = $(this).attr('data-id');
			var item = {
				id: thisId,
			}
			formatList.push(item);
		})
		downLoadBatch(formatList);
	})

	// 点开弹窗2
	$('.pro_detail .btns_box .btns.docDown').on('click', function () {
		$('.tc2').show()
		$('.tc_bg2').show()
	})
	$('.pro_detail02 .bd .bd02 .top_box .right').on('click', function () {
		$('.tc2').show()
		$('.tc_bg2').show()
	})
	// 关闭弹窗
	$('.tc2 .close_btn').on('click', function () {
		$('.tc2').hide()
		$('.tc_bg2').hide()
	})
	// 弹窗电话
	$('.tc2 .content .form_box .inp_wrap.inp_num .icon').click(function () {
		if ($(this).parents('.inp_num').hasClass('on')) {
			$(this).parents('.inp_num').removeClass('on');
			$(this).parents('.inp_num').find('ul').stop().slideUp();
		} else {
			$(this).parents('.inp_num').addClass('on');
			$(this).parents('.inp_num').find('ul').stop().slideDown();
		}
	})
	$('.tc2 .content .form_box .inp_wrap.inp_num .input_ ul li').click(function () {
		$(this).parents('.inp_num').removeClass('on');
		$(this).parents('.inp_num').find('ul').stop().slideUp();
		$('.tc2 .content .form_box .inp_wrap.inp_num .input_ input').attr('placeholder', `${$(this).find('span').html()}`);
		$('.tc2 .content .form_box .inp_wrap.inp_num .input_ .icon img').eq(0).attr('src', `${$(this).find('.icon img').attr('src')}`);
	})

	$('.tc2 .content .box #downForm').Validform({
		btnSubmit: "form_btns",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.tc2 .box .agree_btn .allow').val();
			if (agreeChkBoxes != 1) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () {
					$('.tc2').hide()
					$('.tc_bg2').hide()
					if (docCount == '1') {
						window.location.href = $('.tc_down .downUrl').attr('href');
						$('.tc2 .form_box .inp_wrap .inp_t').val('');
					} else {
						$('.tc_down').show();
						$('.tc_bg').show();
					}
				}, {
					title: "Submitted successfully"
				})
			} else if (data == 'noTimes') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});

	//批量下载
	function downLoadBatch(formatList) {
		$.post("/ext/ajax_downLoad.jsp", { flag: 'downList', formatList: JSON.stringify(formatList) }, function (data) {
			if ($.trim(data)) {
				newData = $.parseJSON(data);
				if (newData.length == 0) {
					$.box.alert("Please select the materials to download!", function () { }, {
						title: "Tip"
					})
				}
				$.each(newData, function (index, value) {
					var thisUrl = value.url;
					console.log(thisUrl);
					window.open(thisUrl, "_blank");
					// window.open(thisUrl);
				})
			}
		});
	}

	// 不同国家电话
	require('intlTelInput')
	$('.tc2 .content .form_box .inp_wrap.inp_num .input_ input').intlTelInput({
		preferredCountries: ['af'],
		allowDropdown: true,
		autoHideDialCode: true,
		autoPlaceholder: "polite",
		customPlaceholder: null,
		dropdownContainer: "",
		excludeCountries: [],
		formatOnDisplay: true,
		geoIpLookup: null,
		initialCountry: "af",
		nationalMode: true,
		placeholderNumberType: "MOBILE",
		onlyCountries: [],
		separateDialCode: false,
		utilsScript: "/resources/web/lib/intl/utils.js"
	});

});