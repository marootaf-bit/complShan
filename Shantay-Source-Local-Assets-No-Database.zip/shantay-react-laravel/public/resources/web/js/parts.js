/**
 * blank
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  
	$(".parts1 .li_:odd").addClass("even");
  
});