/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');

	// The language/API-path query is not a form name. Preserve original bare ?product links.
	var formParams = new URLSearchParams(window.location.search);
	var formTabs = $('.inquiry2 .content .checkbox .item');
	var selectedTab = formTabs.filter(function () {
		var mode = $(this).data('name');
		return mode && (formParams.has(mode) || formParams.get('form') === mode);
	}).first();
	if (!selectedTab.length) selectedTab = formTabs.eq(0);
	selectedTab.addClass('on').siblings().removeClass('on');
	var formMap={product:'.form1',part:'.form2',distributor:'.form4',contact:'.form5'};
	function showInquiryForm(tab){var forms=$('.inquiry2 .content .form');forms.hide();forms.filter(formMap[tab.data('name')]||'.form1').show();}
	showInquiryForm(selectedTab);

	$('.inquiry').css('margin-top', $('.header').height() + 'px');
	$(window).resize(function () {
		$('.inquiry').css('margin-top', $('.header').height() + 'px');
	})

	$('.inquiry2 .content .checkbox .item').click(function () {
		$(this).addClass('on').siblings().removeClass('on');
		showInquiryForm($(this));
	})

	$('.inquiry2 .content .infor .tip').click(function () {
		$(this).addClass('on').siblings('.tip').removeClass('on');
	})

	$('.inquiry2 .content .form .infor .tip2').click(function () {
		//选中时值改成1
		if ($(this).hasClass('on')) {
			$(this).removeClass('on');
			//$(this).find('.allow').val(0);
		} else {
			//$(this).find('.allow').val(1);
			$(this).addClass('on')
		}
	})

	$('.inquiry2 .content .form  .item.phone .icon').click(function () {
		if ($(this).parents('.item').hasClass('on')) {
			$(this).parents('.item').removeClass('on');
			$(this).parents('.item').find('ul').stop().slideUp();
		} else {
			$(this).parents('.item').addClass('on');
			$(this).parents('.item').find('ul').stop().slideDown();
		}
	})

	$('.inquiry2 .content .form  .item.phone .input_ ul li').click(function () {
		$(this).parents('.item').removeClass('on');
		$(this).parents('.item').find('ul').stop().slideUp();
		$(this).parents('.item').find('.input_').find('input').attr('placeholder', $(this).find('span').html());
		$(this).parents('.item').find('.input_').find('.icon').find('img').eq(0).attr('src', $(this).find('.icon img').attr('src'));
	})

	$('.inquiry2 .content .form .item.data .input_ input').eq(0).focus(function () {
		if(this.type==='date')return;
		laydate.skin('molv');
		laydate({ elem: '#itemTime1' });
	})
	$('.inquiry2 .content .form .item.data .input_ input').eq(1).focus(function () {
		if(this.type==='date')return;
		laydate.skin('molv');
		laydate({ elem: '#itemTime2' });
	})
	$('.inquiry2 .content .form .item.data .input_ input').eq(2).focus(function () {
		if(this.type==='date')return;
		laydate.skin('molv');
		laydate({ elem: '#itemTime3' });
	})
	$('.inquiry2 .content .form .item.data .input_ input').eq(3).focus(function () {
		if(this.type==='date')return;
		laydate.skin('molv');
		laydate({ elem: '#itemTime4' });
	})

	// 下拉效果
	$('.inquiry2 .content .form1 .item .input_.form_item .sel_span').on('click', function () {
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur').siblings('.sel_down').stop().slideUp();
		} else {
			$(this).addClass('cur').siblings('.sel_down').stop().slideDown();
			$(this).parent().siblings().find('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
		}
	})
	$('.inquiry2 .content .form1 .item .input_.form_item .sel_down li').on('click', function () {
		var thisVal = $(this).html();
		$('#proCat').val(thisVal);
		$(this).parent().parent().siblings('.sel_span').html(thisVal);
		$(this).parent().parent().siblings('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
	})

	//区号
	$('.inquiry2 .content .form .item.phone .input_ input').on("countrychange", function (e, countryData) {
		var dialCode = countryData.dialCode;
		$('#phoneEmail').val(dialCode);
	});
	// 没有验证码
	require('validform');
	require('box');
	//验证码	
	$('#changeImage1').on('click', function () {
		this.src = $(this).attr('src') + '?now=' + new Date();
	})
	$('.inquiry2 .content .form.form1 form').Validform({
		btnSubmit: "btn_",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form1 .infor .tip');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form1 .infor .tip2');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () { window.location.reload(); }, {
					title: "Submitted successfully"
				})
			} else if (data == 'noTimes') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'notemail') {
				$.box.alert("Please fill in the correct email address!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});
	
	//验证码	
	$('#changeImage2').on('click', function () {
		this.src = $(this).attr('src') + '?now=' + new Date();
	})
	$('.inquiry2 .content .form2 form').Validform({
		btnSubmit: "btn_",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form2 .infor .tip');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form2 .infor .tip2');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () { window.location.reload(); }, {
					title: "Submitted successfully"
				})
			} else if (data == 'noTimes') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'notemail') {
				$.box.alert("Please fill in the correct email address!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});
	
	//验证码	
	$('#changeImage4').on('click', function () {
		this.src = $(this).attr('src') + '?now=' + new Date();
	})
	$('.inquiry2 .content .form4 form').Validform({
		btnSubmit: "btn_",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form4 .infor .tip');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form4 .infor .tip2');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () { window.location.reload(); }, {
					title: "Submitted successfully"
				})
			} else if (data == 'noTimes') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'notemail') {
				$.box.alert("Please fill in the correct email address!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});
	
	//验证码	
	$('#changeImage5').on('click', function () {
		this.src = $(this).attr('src') + '?now=' + new Date();
	})
	$('.inquiry2 .content .form5 form').Validform({
		btnSubmit: "btn_",
		tiptype: 3,
		ajaxPost: true,
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form5 .infor .tip');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		beforeSubmit: function () {
			var agreeChkBoxes = $('.inquiry2 .content .form5 .infor .tip2');
			if (!agreeChkBoxes.eq(0).hasClass('on')) {
				$.box.alert("Please confirm the registration agreement!", function () { }, {
					title: "Validation failed"
				});
				return false;
			}
		},
		callback: function (rs) {
			var data = $.trim(rs.responseText);
			if (data == 'ok') {
				$.box.alert("Information submitted successfully, thank you!", function () { window.location.reload(); }, {
					title: "Submitted successfully"
				})
			} else if (data == 'noTimes') {
				$.box.alert("Your submission limit has been reached!", null, {
					title: "Submission failed"
				})
			} else if (data == 'rand_wrong') {
				$.box.alert("Verification code error!", null, {
					title: "Validation failed"
				})
			} else {
				$.box.alert("Submission failed!", null, {
					title: "Validation failed"
				})
			}
		}
	});

	// 不同国家电话
	require('intlTelInput')
	$('.inquiry2 .content .form .item.phone .input_ input').intlTelInput({
		preferredCountries: ['af'],
		allowDropdown: true,
		autoHideDialCode: true,
		autoPlaceholder: "polite",
		customPlaceholder: null,
		dropdownContainer: "",
		excludeCountries: [],
		formatOnDisplay: true,
		geoIpLookup: null,
		initialCountry: "af",
		nationalMode: true,
		placeholderNumberType: "MOBILE",
		onlyCountries: [],
		separateDialCode: false,
		utilsScript: "/resources/web/lib/intl/utils.js"
	});

});