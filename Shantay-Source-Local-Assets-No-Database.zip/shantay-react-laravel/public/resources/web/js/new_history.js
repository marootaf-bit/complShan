/**
 * blank
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	
  
	// pc
	require('gsap/gsap');
	require('gsap/scrolltrigger');
	require('gsap/scrolltoplugin');
	gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);  

	var headerHeight1 = $('.header').height() + rem(0.2);
	var screenHeight = window.screen.height/2;
	console.log(screenHeight)
	var scrollDistance = function () {
		return $('.new_history01 .cont_box').get(0).scrollHeight - screenHeight;
	}
	var scrollTween = gsap.to($('.new_history01'), {
		ease: "none",
		scrollTrigger: {
			trigger: '.new_history01 .content .year_box',
			pin: true,
			scrub: 0.1,
			invalidateOnRefresh: true,
			start: function () {
				return 'top top+=' + headerHeight1 + 'px';
			},
			end: function () {
				return "+=" + scrollDistance();
			}
		}
	});

	
	$('.new_history01 .content .cont_box .stage_item').each(function () {
		var $stage = $(this);
		var $year = $('.new_history01 .content .year_box .year').eq($stage.index());
		var stageLength = $('.new_history01 .stage_item').length;
		var endOffset = $('.new_history01 .content').height()
		gsap.fromTo($year.find('.progress'), { height: 0 }, {
			height: '110%',
			ease: "none",
			scrollTrigger: {
				trigger: $stage,
				scrub: 0.1,
				start: function () {
					return 'top top+=' + headerHeight1 + 'px';
				},
				end: 'bottom top',
				// end: 'bottom-=' + endOffset + 'px top',
				onEnter: function () {
					$year.addClass('cur').siblings().removeClass('cur');
				},
				onEnterBack: function () {
					$year.addClass('cur').siblings().removeClass('cur');
				}
			},

		});
	})
	$('.new_history01 .content .year_box .year').eq(0).addClass('cur');

	$('.new_history01 .content .year_box .year').on('click', function () {
		enterStage($(this).index());
	});
	
	function enterStage(index) {
		var offsetIdx = Math.abs($('.new_history01 .content .year_box .year.cur').index() - index);
		var duration = (offsetIdx + 1) * 0.8;
		gsap.to(window, { duration: duration, scrollTo: function () { return $('.new_history01 .content .cont_box .stage_item').eq(index).offset().top - headerHeight1 + rem(0.1) }, ease: "power2" });
	};

	function rem(count) {
		var unit = $('html').css('font-size');

		if (typeof count !== 'undefined' && count > 0) {
			return (parseInt(unit) * count);
		}
		else {
			return parseInt(unit);
		}
	};
  
  
});