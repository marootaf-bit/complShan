/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var data = '';

	$('.contact_us02 .bott .bg .dots_box .dot').on('mouseenter', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index()
		$('.contact_us02 .bott .words_box .box').eq(i).show().siblings().hide()
	}).eq(0).trigger('mouseenter')

	// 下拉效果
	$('.new_contact_us01 .right .form_item .sel_span').on('click', function () {
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur').siblings('.sel_down').stop().slideUp();
		} else {
			$(this).addClass('cur').siblings('.sel_down').stop().slideDown();
			$(this).parent().siblings().find('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
		}
	})

	$('.new_contact_us01 .right .form_item .sel_down li').click(function () {
		data = $(this).data('id');
		getData();
		$(this).parents('.form_item').find('.sel_span').html($(this).html());
		$(this).parents('.form_item').find('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
	})

	// getData();
	// function getData() {
	// 	$.post("/ext/ajax_index.jsp", { flag: "contact", data: data }, function (data) {
	// 		if ($.trim(data)) {
	// 			$('.new_contact_us01 .right .bott_box ul').html(data);
	// 		} else {
	// 			$('.new_contact_us01 .right .bott_box ul').html('No Data!');
	// 		}
	// 	});
	// }

	// 点开弹窗3
	$('.new_contact_us01 .left .top .more_btn').on('click', function () {
		$('.tc3').show()
		$('.tc_bg3').show()
	})

	// 关闭弹窗
	$('.tc3 .close_btn').on('click', function () {
		$('.tc3').hide()
		$('.tc_bg3').hide()
	})

});