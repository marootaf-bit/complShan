/**
 * 案例详细
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  
	// TODO: 视频控件修复
	
	// 视频iframe禁用鼠标
	$('.case_detail .content .swiper-slide iframe').css('pointer-events', 'none');
	// $('.case_detail .content .swiper-slide iframe').on('click', function(e) {
	// 	e.stopPropagation();
	// });
	// $('.case_detail .content .swiper-slide').on('click', function(e) {
	// 	debugger;
	// 	var evt = new $.Event("click");
	// 	evt.pageX = e.pageX;
	// 	evt.pageY = e.pageY;
		
	// 	var $iframe = $(this).find('iframe');
	// 	$iframe.css('pointer-events', 'all').trigger('click', evt);
	// 	setTimeout(function(){
	// 		$iframe.css('pointer-events', 'none');
	// 	}, 100);
	// });
	// $('.case_detail .content .swiper-slide').on('mousemove', function(e) {
	// 	debugger;
	// 	var evt = new $.Event("mousemove");
	// 	evt.pageX = e.pageX;
	// 	evt.pageY = e.pageY;
		
	// 	$(this).find('iframe').css('pointer-events', 'all').trigger('mousemove', evt);
	// 	$(this).find('iframe').css('pointer-events', 'none');
	// });




	// 鼠标
	var circle_cursor = $('.circle_cursor');
	var case01 = document.querySelector('.case_detail01 .content');
	var timeout = null;
	// 让.circle_cursor跟随鼠标移动，在swiper左半边时加上cursor_left类，右半边时加上cursor_right类
	$('body').on('mousemove', function(e) {
		// 先隐藏图标
		circle_cursor.removeClass('cursor_right').removeClass('cursor_left');
		// 判断是否在case01区域内，给视频控件留出100px的空间
		if((e.pageX > $(case01).offset().left && e.pageX < $(case01).offset().left + $(case01).width() * 0.4
			|| e.pageX > $(case01).offset().left + $(case01).width() * 0.6 && e.pageX < $(case01).offset().left + $(case01).width())
			&& e.pageY > $(case01).offset().top + 100 && e.pageY < $(case01).offset().top + $(case01).height() - 100){
			// 设置图标位置
			circle_cursor.css({
				left: e.pageX,
				top: e.pageY
			});

			// 还可以用transform来设置位置
			// circle_cursor.attr('style', 'transform: translate(' + e.pageX + 'px, ' + e.pageY + 'px)')

			// 判断鼠标在左半边还是右半边
			if (e.pageX - $(case01).offset().left < $(case01).width() / 2) {
				circle_cursor.addClass('cursor_left');
			} else {
				circle_cursor.addClass('cursor_right');
			}
		} else {
			$('.case_detail .content .swiper-slide iframe').css('pointer-events', 'all');
			if(timeout) clearTimeout(timeout);
			timeout = setTimeout(function(){
				$('.case_detail .content .swiper-slide iframe').css('pointer-events', 'none');
			}, 500);
		}
		
	});



	var caseSwiper01 = $('.case_detail .content .swiper-container')[0].swiper;
	$('  .circle_cursor').on('click', function(e) {
		if($(this).hasClass('cursor_left')){
			caseSwiper01.slidePrev();
		}else if($(this).hasClass('cursor_right')){
			caseSwiper01.slideNext();
		}

	})
});