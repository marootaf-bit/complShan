/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var channelId = $('#channelId').val();
	var catId = "", work = "", type = "", key = "";



	var mySwiper = new Swiper('.recruit1 .content .right .swiper', {
		loop: true,
		init: false,
		effect: 'fade',
		speed: 800,
		autoplay: {
		  delay: 3000,
		  stopOnLastSlide: false,
		  disableOnInteraction:false,
		},
		fadeEffect: {
		  crossFade: true,
		},
		pagination: {
		  el: '.recruit1 .content .right .swiper-pagination',
		  clickable: true,
		},
	}) 

	// 判断swiper-slide的数量
	if ($('.recruit1 .content .right .swiper-slide').length > 1) {
		mySwiper.init(); 
	}

	$('.recruit2 .search .item .word').click(function (e) {
		if ($(this).parents('.item').hasClass('on')) {
			$(this).parents('.item').removeClass('on');
			$(this).parents('.item').find('ul').stop().slideUp();
		} else {
			$(this).parents('.item').addClass('on').siblings().removeClass('on');
			$(this).parents('.item').find('ul').stop().slideDown();
			$(this).parents('.item').siblings().find('ul').stop().slideUp();
		}
	})
	//catId
	$('.recruit2 .search ul.cate li').click(function () {
		catId = $(this).data('id');
		$(this).parents('.item').find('span').html($(this).html());
		$(this).parents('.item').find('ul').stop().slideUp();
		$('.recruit2 .search .item').removeClass('on');
		getData();
	})
	//work
	$('.recruit2 .search ul.work li').click(function () {
		work = $(this).data('id');
		$(this).parents('.item').find('span').html($(this).html());
		$(this).parents('.item').find('ul').stop().slideUp();
		$('.recruit2 .search .item').removeClass('on');
		getData();
	})
	//type
	$('.recruit2 .search ul.type li').click(function () {
		type = $(this).data('id');
		$(this).parents('.item').find('span').html($(this).html());
		$(this).parents('.item').find('ul').stop().slideUp();
		$('.recruit2 .search .item').removeClass('on');
		getData();
	})

	$('.recruit2 .search .item2 input')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			key = $('.recruit2 .search .item2 input').val();
			if (key === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
			} else {
				getData();
			}
		}
	}

	$('.recruit2 .search .item2 .word').on('click', '.icon', function (event) {
		key = $('.recruit2 .search .item2 input').val();
		if (key === "") {
			$.box.alert("Information cannot be empty!", null, {
				title: "Hint"
			})
		} else {
			getData();
		}
	});

	$('.recruit1 .content .right img').height($('.recruit1 .content .left').height());
	$(window).resize(function () {
		$('.recruit1 .content .right img').height($('.recruit1 .content .left').height());
	})

	getData();
	function getData() {
		$.post("/ext/ajax_job.jsp", { flag: "getData", channelId: channelId, catId: catId, work: work, type: type, key: key }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
				$(".recruit2 .content .tips span").html(count);
			} else {
				$("#container").addClass('no').html('No Data!');
				$(".recruit2 .content .tips span").html('0');
			}
		});
	}

});