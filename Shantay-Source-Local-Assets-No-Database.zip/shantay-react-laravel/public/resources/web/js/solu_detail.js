/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var data = '';

	var swiper1 = new Swiper('.solu_detail02 .bg-container', {
		loop: true,
		slidesPerView: 1,
		spaceBetween: 0,
	})

	var swiper2 = new Swiper('.solu_detail02 .infor-container', {
		loop: true,
		effect: 'fade',
		slidesPerView: 1,
		spaceBetween: 0,
		pagination: {
			el: '.swiper-pagination',
			clickable: true,
		}
	})

	var swiper3 = new Swiper('.solu_detail02 .img-container', {
		loop: true,
		slidesPerView: 1,
		spaceBetween: 0,
	})

	// swiper1.controller.control = swiper2;
	swiper2.controller.control = swiper1;

	$('.solu_detail03 .content .hd a').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		data = $(this).data('id');
		getData();
	});

	$('.solu_detail03').on('click', '[data-related-page]', function () {
		getData(Number($(this).attr('data-related-page')));
	});
	var pendingRequest;
	function getData(page) {
		if (pendingRequest) pendingRequest.abort();
		pendingRequest = $.post("/ext/ajax_solution.jsp", { flag: "getData", data: data, page: page || 1, lang: document.documentElement.lang }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
			} else {
				$("#container").html('No Data!');
			}
		});
	}

	var proId = new URLSearchParams(window.location.search).get('proId');
	var tabs = $('.solu_detail03 .content .hd a');
	var initial = tabs.filter(function () { return String($(this).data('id')) === proId; });
	(initial.length ? initial : tabs.eq(0)).trigger('click');

});
