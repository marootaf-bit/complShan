/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var channelId = $('#channelId').val();
	var parentId = $('#parentId').val();
	var catId = '', attr01='', attr02='', attr03='';
	var productsRequest, paramsRequest;
	// Captured pagination-only modules are not page initializers, and their
	// direct handlers cannot re-bind reliably when a previous page is revisited.
	$('#container .widgets_common_pages_4 [page]').off('click');
	$('.pro_list01').on('click', '.widgets_common_pages_4 [page]', function (event) {
		event.preventDefault();
		var page = $(this).attr('page');
		if (/^[0-9]+$/.test(page)) getData(page);
	});
	var xzArray01 = [], xzArray02 = [], xzArray03 = [];
	var xz01='', xz02='', xz03='';
	var url = window.location;
	var urlParams = new URLSearchParams(url.search);
	var threeId = urlParams.get('threeId');
 var restoredState=null, firstRequest=true, lastState='';
 try { restoredState=JSON.parse(urlParams.get('catalogue')||'null'); } catch(e) {}
 window.addEventListener('popstate',function(){location.reload();});
 function recordState(state){
  var encoded=JSON.stringify(state); if(encoded===lastState)return;
  var u=new URL(location.href),active=Object.keys(state).some(function(k){return state[k]!==''&&state[k]!=null;});
  if(active)u.searchParams.set('catalogue',encoded);else u.searchParams.delete('catalogue');
  var selected=$('.pro_list01 .new_top .swiper-slide.cur').data('id');
  if(selected)u.searchParams.set('cid',selected);else u.searchParams.delete('cid');
  if(!firstRequest&&encoded!==lastState)history.pushState(null,'',u);else if(restoredState)history.replaceState(null,'',u);
  lastState=encoded;
  if(parent!==window)parent.postMessage({type:'site-route-change',path:u.searchParams.get('path')||u.pathname,query:u.searchParams.toString(),hash:u.hash},location.origin);
 }


	// 手机端筛选
	$('.pro_list01 .new_top .m_top').click(function () {
		$('.m_select3').addClass('active');
	})

	$('.m_select3 .close img').click(function () {
		$('.m_select3').removeClass('active');
	})

	// 判断竖线
	$('.pro_list01 .new_top .swiper-slide').on('click', function () {
		$(this).addClass('cur').siblings().removeClass('cur');
		var i = $(this).index();
		catId = $(this).data('id');
		attr01='',attr02='',attr03='';xzArray01=[];xzArray02=[];xzArray03=[];
		xz01='',xz02='',xz03='';
		$('.pro_list01 .bott .right .top_ .choose_box').html('')
		$('.pro_list01 .bott .right .top_ .goBack_btn').removeClass('cur');
		getParam();
		getData();
	})

	// 判断是否有swiper-slide
	if ($('.pro_list01 .new_top .swiper-slide').length == 0) {
		$('.pro_list01 .new_top').hide()
		if (catId == '' || catId == undefined) {
			getParam();
			getData();
		}
	} else {
		var cid = urlParams.get('cid');
		if (cid != '' && cid != undefined) {
			var selectedCategory = $('.pro_list01 .new_top .swiper-slide').filter(function () { return String($(this).data('id')) === cid; });
			if (selectedCategory.length) selectedCategory.eq(0).trigger('click');
			else { getParam(); getData(); }
		} else {
			getParam();
			getData();
		}
	}

	var listSwiper = new Swiper('.pro_list01 .new_top .swiper-container', {
		slidesPerView: 'auto',
		navigation: {
			nextEl: '.top_box .swiper-button-next',
			prevEl: '.top_box .swiper-button-prev',
		},
		// breakpoints: {
		// 	1240: {
		// 		slidesPerView: 5,
		// 	},
		// 	992: {
		// 		slidesPerView: 4,
		// 	},
		// 	780: {
		// 		slidesPerView: 3,
		// 	},
		// 	480: {
		// 		slidesPerView: 2,
		// 	}
		// }
		on: {
			init: function () {
				setTimeout(function () {
					sizeBH();
				}, 300)
			},
			resize: function () {
				sizeBH();
			},
		}
	});

	function sizeBH() {
		if ($('.top_box .swiper-button-disabled').length == 2) {
			$('.pro_list01 .new_top .top_box').addClass('noshow')
			$('.pro_list01 .new_top .swiper-container').addClass('noLeft')
		} else {
			$('.pro_list01 .new_top .top_box').removeClass('noshow')
			$('.pro_list01 .new_top .swiper-container').removeClass('noLeft')
		}
	}

	$(window).resize(function (event) {
		bianhua();
	});

	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);

	var st = null;
	function isIE() {
		return window.document.documentMode ? true : false;
	}
	function bianhua() {
		if (st) {
			st.kill();
			st = null;
		}
		if (base.getType() == "Pc" && !isIE()) {
			var gap = 20;
			var startOffset = $('.header').height() + gap;
			var endOffset = $('.pro_list01 .bott .left').height() + startOffset;
			st = ScrollTrigger.create({
				trigger: '.pro_list01 .bott .right',
				start: 'top-=' + startOffset + 'px top',
				endTrigger: '.pro_list01 .bott .right',
				end: 'bottom-=' + endOffset + 'px top',
				pin: '.pro_list01 .bott .left',
				onUpdate: function (self) {
					if ($('.header').hasClass('fixed')) {
						$('.pro_list01 .bott .left').css({ 'margin-top': '0' });
					} else {
						$('.pro_list01 .bott .left').css({ 'margin-top': '0' });
					}
				},
				onLeaveBack: function () {
					$('.pro_list01 .bott .left').css({ 'margin-top': '0' });
				}
			});
		} else {
			$('.pro_list01 .bott .left').css({ 'margin-top': '0' });
		}
	}

	$('body').on('click', '.pro_list01 .bott .right .top_ .choose_box .list_a .close_btn', function () {
		var dataIndex = $(this).parent('.list_a').data('index');
		var itemIndex = $(this).parent('.list_a').data('filter');
		console.log(dataIndex)
		$(this).parents('.list_a').remove();
		if ($(window).width() <= 780) {
			$('.m_select3 .box_ .bott .box .item[data-index="'+itemIndex+'"] .cont li[data-index="' + dataIndex + '"]').click();
		} else {
			$('.pro_list01 .bott .left .box .item[data-index="'+itemIndex+'"] .cont li[data-index="' + dataIndex + '"]').click();
		}
	})

	$('body').on('click', '.pro_list01 .bott .left .box .btns', function () {
		$('.pro_list01 .bott .right .top_ .choose_box').html('')
		$('.pro_list01 .bott .left .box .item .cont li').removeClass('cur');
		$('.pro_list01 .bott .right .top_ .goBack_btn').removeClass('cur');
		attr01 = '', attr02 = '', attr03 = '';xzArray01=[];xzArray02=[];xzArray03=[];
		xz01 = '', xz02 = '', xz03 = '';
		getData();
	})

	$('body').on('click', '.m_select3 .box_ .bott .box .btns', function () {
		$('.pro_list01 .bott .right .top_ .choose_box').html('')
		$('.m_select3 .box_ .bott .box .item .cont li').removeClass('cur');
		$('.pro_list01 .bott .right .top_ .goBack_btn').removeClass('cur');
		catId = $('.pro_list01 .new_top .swiper-container .swiper-slide.cur').data('id');
		attr01 = '', attr02 = '', attr03 = '';xzArray01=[];xzArray02=[];xzArray03=[];
		xz01 = '', xz02 = '', xz03 = '';
		getData();
	})

	$('body').on('click', '.pro_list01 .bott .right .top_ .goBack_btn', function () {
		$(this).removeClass('cur');
		catId = $('.pro_list01 .new_top .swiper-container .swiper-slide.cur').data('id');
		threeId = '';
		attr01 = '', attr02 = '', attr03 = '';xzArray01=[];xzArray02=[];xzArray03=[];
		xz01 = '', xz02 = '', xz03 = '';
		getData();
	})

	function getParam() {
		if (paramsRequest) paramsRequest.abort();
		paramsRequest = $.post("/ext/ajax_proList.jsp", { flag: "param", channelId: channelId, parentId: parentId, catId: catId }, function (data) {
            $('.pro_list01 .bott .left .box,.m_select3 .box_ .bott .box').empty();$('.pro_list01 .bott').toggleClass('no_left',!$('<div>').html(data).find('.item').length);
			if ($.trim(data)) {
				$('.pro_list01 .bott .left .box').html(data);
				$('.pro_list01 .bott .left .box .item .cont li').each(function () {
					var count = $(this).data('count');
					$(this).find('.num').html(' (' + count + ')');
				})
				$('.m_select3 .box_ .bott .box').html(data);
				$('.m_select3 .box_ .bott .box .item .cont li').each(function () {
					var count = $(this).data('count');
					$(this).find('.num').html(' (' + count + ')');
				})
				if ($(window).width() <= 780) {
					$('.m_select3 .box_ .bott .box .item .intro').on('click', function () {
						if ($(this).parents('.item').hasClass('cur')) {
							$(this).parents('.item').removeClass('cur')
						} else {
							$(this).parents('.item').addClass('cur')
						}
					})
					$('.m_select3 .box_ .bott .box .item .cont li').on('click', function () {
						$('.pro_list01 .bott .right .top_ .goBack_btn').removeClass('cur');
						catId = $('.pro_list01 .new_top .swiper-container .swiper-slide.cur').data('id');
						var indexI = $(this).data('index');var selectedRange=String($(this).data('id'));
						var text = $(this).find('.text').text();
						var status = $(this).parents('.item').data('index');
						if ($(this).hasClass('cur')) {
							$(this).removeClass('cur');
							$('.pro_list01 .bott .right .list_a').each(function () {
								var atext = $(this).find('span').text();
								if (atext == text) {
									var i = $(this).index()
									$('.pro_list01 .bott .right .list_a').eq(i).remove()
								}
							})
							if (status == '1') {
								if (xzArray01.indexOf(selectedRange) !== -1) {
									xzArray01.splice(xzArray01.indexOf(selectedRange), 1);
								}
								if (xzArray01.length == 0) {
									attr01 = '';
								}
							}
							if (status == '2') {
								if (xzArray02.indexOf(selectedRange) !== -1) {
									xzArray02.splice(xzArray02.indexOf(selectedRange), 1);
								}
								if (xzArray02.length == 0) {
									attr02 = '';
								}
							}
							if (status == '3') {
								if (xzArray03.indexOf(selectedRange) !== -1) {
									xzArray03.splice(xzArray03.indexOf(selectedRange), 1);
								}
								if (xzArray03.length == 0) {
									attr03 = '';
								}
							}
						} else {
							$(this).addClass('cur');
							$('.pro_list01 .bott .right .top_ .choose_box').append('<a href="javascript:;" class="list_a" data-filter="'+status+'" data-index="' + indexI + '"><i class="iconfont close_btn" data-code="xe641;">&#xe641;</i><span>' + text + '</span></a>');
							if (status == '1') { xzArray01.push($(this).data('id').toString()); attr01 = $(this).parents('.cont').data('name'); }
							if (status == '2') { xzArray02.push($(this).data('id').toString()); attr02 = $(this).parents('.cont').data('name'); }
							if (status == '3') { xzArray03.push($(this).data('id').toString()); attr03 = $(this).parents('.cont').data('name'); }
						}
						xz01 = xzArray01.join("|");
						xz02 = xzArray02.join("|");
						xz03 = xzArray03.join("|");
						getData();
					})
				} else {
					if ($('.pro_list01 .bott .left .box .item').length == 0) {
						$('.pro_list01 .bott').addClass('no_left')
					}
					$('.pro_list01 .bott .left .box .item .intro').on('click', function () {
						if ($(this).parents('.item').hasClass('cur')) {
							$(this).parents('.item').removeClass('cur')
						} else {
							$(this).parents('.item').addClass('cur')
						}
						bianhua();
					}).eq(0).trigger('click');
					$('.pro_list01 .bott .left .box .item .cont li').on('click', function () {
						$('.pro_list01 .bott .right .top_ .goBack_btn').removeClass('cur');
						catId = $('.pro_list01 .new_top .swiper-container .swiper-slide.cur').data('id');
						var indexI = $(this).data('index');var selectedRange=String($(this).data('id'));
						var text = $(this).find('.text').text();
						var status = $(this).parents('.item').data('index');
						if ($(this).hasClass('cur')) {
							$(this).removeClass('cur');
							$('.pro_list01 .bott .right .list_a').each(function () {
								var atext = $(this).find('span').text();
								if (atext == text) {
									var i = $(this).index()
									$('.pro_list01 .bott .right .list_a').eq(i).remove()
								}
							})
							if (status == '1') {
								if (xzArray01.indexOf(selectedRange) !== -1) {
									xzArray01.splice(xzArray01.indexOf(selectedRange), 1);
								}
								if (xzArray01.length == 0) {
									attr01 = '';
								}
							}
							if (status == '2') {
								if (xzArray02.indexOf(selectedRange) !== -1) {
									xzArray02.splice(xzArray02.indexOf(selectedRange), 1);
								}
								if (xzArray02.length == 0) {
									attr02 = '';
								}
							}
							if (status == '3') {
								if (xzArray03.indexOf(selectedRange) !== -1) {
									xzArray03.splice(xzArray03.indexOf(selectedRange), 1);
								}
								if (xzArray03.length == 0) {
									attr03 = '';
								}
							}
						} else {
							$(this).addClass('cur');
							$('.pro_list01 .bott .right .top_ .choose_box').append('<a href="javascript:;" class="list_a" data-filter="'+status+'" data-index="' + indexI + '"><i class="iconfont close_btn" data-code="xe641;">&#xe641;</i><span>' + text + '</span></a>');
							if (status == '1') { xzArray01.push($(this).data('id').toString()); attr01 = $(this).parents('.cont').data('name'); }
							if (status == '2') { xzArray02.push($(this).data('id').toString()); attr02 = $(this).parents('.cont').data('name'); }
							if (status == '3') { xzArray03.push($(this).data('id').toString()); attr03 = $(this).parents('.cont').data('name'); }
						}
						xz01 = xzArray01.join("|");
						xz02 = xzArray02.join("|");
						xz03 = xzArray03.join("|");
						getData();

					})
				}
			}
            if(restoredState){$('.pro_list01 .bott .left .box .item .cont li,.m_select3 .box_ .bott .box .item .cont li').each(function(){var id=String($(this).data('id')),ix=$(this).closest('.item').data('index'),selected=ix==1?xzArray01:ix==2?xzArray02:xzArray03;$(this).toggleClass('cur',selected.indexOf(id)!==-1);});}
            if(restoredState){$('.pro_list01 .bott .right .top_ .choose_box').empty();$('.pro_list01 .bott .left .box .item .cont li.cur').each(function(){var ix=$(this).closest('.item').data('index'),chip=$('<a href="javascript:;" class="list_a"><i class="iconfont close_btn" data-code="xe641;">&#xe641;</i><span></span></a>');chip.attr('data-filter',ix).attr('data-index',$(this).data('index')).find('span').text($(this).find('.text').text());$('.pro_list01 .bott .right .top_ .choose_box').append(chip);});}
            bianhua()
        });
	}

	function getData(page) {
		if (productsRequest) productsRequest.abort();
        if(firstRequest&&restoredState){catId=String(restoredState.catId||'');attr01=String(restoredState.attr01||'');attr02=String(restoredState.attr02||'');attr03=String(restoredState.attr03||'');xz01=String(restoredState.xz01||'');xz02=String(restoredState.xz02||'');xz03=String(restoredState.xz03||'');page=restoredState.nowPage||page;xzArray01=xz01?xz01.split('|'):[];xzArray02=xz02?xz02.split('|'):[];xzArray03=xz03?xz03.split('|'):[];}
        var state={catId:String(catId||''),attr01:attr01,attr02:attr02,attr03:attr03,xz01:xz01,xz02:xz02,xz03:xz03,nowPage:page||'',q:urlParams.get('q')||'',sort:urlParams.get('sort')||''};
        recordState(state);firstRequest=false;
        productsRequest = $.post("/ext/ajax_proList.jsp", $.extend({flag:'getData',channelId:channelId,parentId:parentId},state), function (data) {
			if ($.trim(data)) {
				$('#container').html(data);
				$('#container .widgets_common_pages_4 [page]').off('click');
				setTimeout(function () {
					bianhua();
				}, 200)
				if (count != null && count != undefined) {
					$('.pro_list01 .bott .right .top_ .com_tit').text(document.documentElement.lang.toLowerCase().indexOf('fa') === 0 ? 'مجموع ' + count + ' محصول' : 'Total ' + count + ' results');
				}
				$('.pro_list01 .bott .right .item_list li').on('click', '', function (event) {
					$('.pro_list01 .bott .right .top_ .goBack_btn').addClass('cur');
					catId = $(this).data('id');
					threeId = '';
					getData();
				});
				if (threeId != '' && threeId != undefined) {
					$('.pro_list01 .bott .right .item_list li').each(function (index, el) {
						if (threeId == $(el).data('id')) {
							$(el).trigger('click');
						}
					})
				}
			} else {
				$('#container').html('No Data!');
			}
        }).fail(function(xhr,status){if(status==='abort')return;$('#container').empty().append($('<p role="alert"></p>').text(document.documentElement.lang.toLowerCase().indexOf('fa')===0?'نتایج بارگیری نشد. انتخاب‌های شما حفظ شده است؛ دوباره تلاش کنید.':'Results could not be loaded. Your selections are retained; please retry.'));$('.pro_list01 .com_tit').text('');});
	}

	bianhua();

});