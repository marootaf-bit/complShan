/**
 * 经销商
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var lng = '', lat = '', useMap = '';
	var country = '', distance = 0, key = '';

	lat = '121.416652'; lng = '37.426723';

	//国家
	$.post("/ext/ajax_getIP.jsp", { flag: "map" }, function (data) {
		if ($.trim(data)) {
			useMap = $.trim(data);
		}
		getData();
	});

	function calcHeight() {
		$(".distributor01 .left .content .bott ul").height(
			$(".distributor01 .left").height() -
			$(".distributor01 .left .content .top").outerHeight(true) -
			$(".distributor01 .left .content .midd").outerHeight(true)
		);
	}

	$(window).on('resize', calcHeight);
	calcHeight();

	// 参考中联 http://zoom.icm.com.cn/service/service_network.htm

	$(".distributor01 .left .content .top .line .input_item input").keypress(
		function (event) {
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if (keycode == "13") {
				// 
			}
		}
	);

	$('.distributor01 .left .content .top .line .sel_item').click(function (e) {
		e.stopPropagation();
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur');
			$(this).find('.item_down').stop().slideUp();
		} else {
			$(this).addClass('cur').siblings().removeClass('cur');
			$(this).find('.item_down').stop().slideDown();
			$(this).siblings().find('.item_down').stop().slideUp();
		}
	})

	$('.distributor01 .left .content .top .line .sel_item.sel_item01 .item_down li').click(function () {
		$(this).parents('.sel_item').find('.item_span').html($(this).html());
		country = $(this).data('id');
		getData();
	})

	$('.distributor01 .left .content .top .line .sel_item.sel_item02 .item_down li').click(function () {
		$(this).parents('.sel_item').find('.item_span').html($(this).html());
		distance = $(this).data('id');
		getData();
	})

	// 点击定位
	$('.distributor01 .left .content .top .line .input_item .locate_btn').on('click', function () {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(function (pos) {
				var coord = pos.coords;
				lat = coord.latitude;
				lng = coord.longitude;
				getData();
			}, function (e) { console.log(e) });
		}
	}).eq(0).trigger('click');
	
	// 点击搜索
	$('.distributor01 .left .content .top .line .input_item input')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			key = $('.distributor01 .left .content .top .line .input_item input').val();
			if (key === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
			}else{
				getData();
			}
		}
	}

	$('.distributor01 .left .content .top .line .input_item .search_btn').on('click', function () {
		key = $('.distributor01 .left .content .top .line .input_item input').val();
		if (key === "") {
			$.box.alert("Information cannot be empty!", null, {
				title: "Hint"
			})
		}else{
			getData();
		}
	});

	function getData() {
		$.post("/ext/ajax_network.jsp", { flag: "getData", useMap: useMap, country: country, distance: distance, key: key, lat: lat, lng: lng }, function (data) {
			$('.distributor01 .left .content .bott').html(data);
			initMap();
			$('.distributor01 .left .content .midd .intro .tit span').html(count);
			// if ($.trim(useMap) == 'gaode') {
			// 	initGaoDeMap()
			// } else {
			// 	initMap();
			// }
		});
	}

	function initMap() {//地图初始化函数  
		var map;
		try {
			var markerObject = {};
			var myOptions = {
				zoom: 3,//区域 深度 
				scaleControl: true, //控件
				center: new google.maps.LatLng(centerPoint[1], centerPoint[0]),
				mapTypeId: google.maps.MapTypeId.ROADMAP //返回当前地图类型
			}
			// https://www.runoob.com/googleapi/ref-getmaptypeid.html
			map = new google.maps.Map(document.getElementById('map_box'), myOptions);//创建地图 
			var default_icon = "/resources/web/img/sale01_3.png";
			for (var key in mapData) {
				var item = mapData[key];
				//创建坐标
				var position = new google.maps.LatLng(item.lat, item.lng);
				//创建标记
				var marker_infobox = new google.maps.Marker({ position: position, icon: default_icon });
				marker_infobox.setMap(map);
				//attachSecretMessage(marker_infobox, key)
			}

			var currentMarker
			function attachSecretMessage(marker, i) {
				//创建infowindow
				var infowindow = new google.maps.InfoWindow({ content: mapData[i].con }); //弹窗的内容
				//为标记添加点击事件
				google.maps.event.addListener(marker, 'click', function () {
					if (currentMarker) {
						currentMarker.setMap(null)
					}
					infowindow.open(map, marker);
					currentMarker = marker
				});
				//存储标记和窗口信息
				markerObject[mapData[i].id] = {
					"marker": marker,
					"infowindow": infowindow
				}
			}

			$('.distributor01 .left .content .bott .item').on('click', function () {
				if (currentMarker) {
					currentMarker.setMap(null)
				}
				for (var key in mapData) {
					var item = mapData[key];
					//创建坐标
					var position = new google.maps.LatLng(item.lat, item.lng);
					//创建标记
					var marker_infobox = new google.maps.Marker({ position: position, icon: default_icon });
					marker_infobox.setMap(map);
					attachSecretMessage(marker_infobox, key)
				}

				var aid = $(this).data('id');
				obj = markerObject[aid];
				obj.infowindow.open(map, obj.marker);
				currentMarker = obj.marker;
				map.setZoom(6);
				map.panTo(obj.marker.position);
			}).eq(0).trigger('click');

		} catch (e) { }
	}

	function initGaoDeMap() {
		//初始化
		// AMap.Map(container:String/HTMLDivElement, opts:MapOptions) 构造一个地图对象
		var map = new AMap.Map('map_box', {
			zoom: 3, //级别
			center: [61.73,26.85], //初始地图中心点
			lang: "en", //可选值：en，zh_en, zh_cn
			resizeEnable: true,//是否监控地图容器尺寸变化，默认值为false
			expandZoomRange: true,//是否支持可以扩展最大缩放级别,和zooms属性配合使用,设置为true的时候，zooms的最大级别在PC上可以扩大到20级
			zooms: [3, 8]//地图显示的缩放级别范围,在PC上，默认为[3,18]，取值范围[3-18]；
		});

		var markerArrs = mapData;
		var markers = [];
		for (var i = 0; i < markerArrs.length; i += 1) {
			var marker = new AMap.Marker({
				position: markerArrs[i].point,
				title: markerArrs[i].title,
				icon: markerArrs[i].icon,
				map: map
			});
			marker.con = markerArrs[i].con;
			marker.on('click', markerClick);
			markers.push(marker);
		}

		$('.distributor01 .left .content .bott .item').on('click', function () {
			var aid = $(this).data('id');
			for (var j = 0; j < markerArrs.length; j += 1) {
				var item = markerArrs[j];
				if (item.id == aid) {
					var marker = new AMap.Marker({
						position: item.point,
						title: item.title,
						icon: item.icon,
						map: map
					});
					marker.con = item.con;
					marker.on('click', markerClick);
					marker.emit('click', { target: marker });
				}
			}
		})

		//打开信息窗体
		function markerClick(e) {
			var infoWindow = new AMap.InfoWindow({
				closeWhenClickMap: true,//鼠标点击地图后关闭信息窗体
				offset: new AMap.Pixel(0, -30),
			});
			infoWindow.setContent(e.target.con);
			map.setCenter(e.target.getPosition());
			infoWindow.open(map, e.target.getPosition());
		}

		//地图控件
		AMap.plugin(['AMap.ToolBar', 'AMap.Scale', 'AMap.OverView'], function () {
			map.addControl(new AMap.ToolBar({ position: 'RT' }));
			map.addControl(new AMap.Scale());
			// map.addControl(new AMap.OverView({ isOpen: true }));
		})

		//map.setFitView();//根据地图上添加的覆盖物分布情况，自动缩放地图到合适的视野级别
	}

});