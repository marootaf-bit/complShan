/**
 * 服务
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
	
	(function () {
		//数字滚动效果
		require('animate-number');
		var numberBox = $('.service01 .content'),//获取父元素
			scrollHeight = numberBox.offset().top - $(window).height() + 100;//距文档顶部距离-屏幕高度+自身高度=滚动条滚去这个高度正好出现在屏幕中	

		var _num01 = $('.service01 .content .tit .num.num01 ').text();//获取number1里面的数值
		var _num02 = $('.service01 .content .tit .num.num02 ').text();
		var _num03 = $('.service01 .content .tit .num.num03 ').text();
		var _num04 = $('.service01 .content .tit .num.num04 ').text();

		//主变化函数changeGo
		var changeGo = function () {
			if ($(window).scrollTop() - $(window).height() / 4 > scrollHeight) {
				$('.service01 .content .tit .num.num01 ').stop().prop('number', 0).animateNumber({ number: _num01 }, 1000);
				$('.service01 .content .tit .num.num02 ').stop().prop('number', 0).animateNumber({ number: _num02 }, 1000);
				$('.service01 .content .tit .num.num03 ').stop().prop('number', 0).animateNumber({ number: _num03 }, 1000);
				$('.service01 .content .tit .num.num04 ').stop().prop('number', 0).animateNumber({ number: _num04 }, 1000);

				$(window).off('scroll', changeGo);//解除事件绑定    
			}
		}
		$(window).on('scroll', changeGo);
	})();


	function setSwiperHeight() {
		var introHeight = $('.service03 .content .right .swiper-slide .intro_box').height();
		var imgHeight = $('.service03 .content .right .swiper-slide .img_box').height();
		if($(window).width() < 992) {
			$('.service03 .content .right .swiper-container').height(introHeight + imgHeight);
		} else {
			$('.service03 .content .right .swiper-container').height(imgHeight);
		}
	}

	if(swiper03) {
		setSwiperHeight();
		swiper03.update();

		swiper03.on('slideChange', function() {
			$(".service03 .content .left .icon_box").eq(this.realIndex).addClass("act").siblings().removeClass("act");
		});

		swiper03.on('resize', function() {
			setSwiperHeight();
			swiper03.update();
		});
	}

	$(".service03 .content .left .icon_box").click(function() {
		var index = $(this).index();
		swiper03 && swiper03.slideTo(index+1, 500, false);
	});

});