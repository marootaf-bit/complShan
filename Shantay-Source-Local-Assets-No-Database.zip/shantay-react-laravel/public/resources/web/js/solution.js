/**
 * blank
 */
define(function(require) {
	var $ = require('jquery');
	var base = require('base');
	var com=require('./common');
  

	widthResize = function () {
		var height01 = 0;
		$('.solution02 .li_ .infor').attr('style', '');
		$('.solution02 .li_').each(function () {
			var inforHeight = $(this).find('.infor').outerHeight();
			if (inforHeight > height01) {
				height01 = inforHeight
			}
		})
		$('.solution02 .li_ .infor').height(height01)
		
	}

	if (base.getType() != 'Mobile') {
		widthResize();
		$(window).on('resize', widthResize);
	}
  
});