/**
 * blank
 */
define(function (require) {
	var $ = require('jquery');
	var base = require('base');
	var com = require('./common');
	var channelId = $('#channelId').val();
	var year = "", key = "";

	function GetQueryString(key){
		var reg = new RegExp("(^|&)"+ key +"=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if(r!=null)return  r[2]; return '';
	}
	key = decodeURI(GetQueryString("key"),'utf-8');
	if (key != '' && key != undefined) {
		key = decodeURIComponent(key).replace("+"," ");
		$(".news_list02 .top .right .box .form_item .inp").val(key);
		getData();
	}

	// bianhua();
	$(window).resize(function (event) {
		bianhua();
	});

	require('gsap/gsap');
	require('gsap/scrolltrigger');
	gsap.registerPlugin(ScrollTrigger);

	//推荐新闻
	$.post("/ext/ajax_news.jsp", { flag: "recommend", channelId: channelId }, function (data) {
		$('.news_list01 .content').html(data);
		var Swiper01 = new Swiper('.news_list01 .swiper-container', {
			loop: false,
			autoplay: true,
			slidesPerView: 1,
			speed: 800,
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
		});
		// 鼠标覆盖停止自动切换
		// Swiper01.el.onmouseover = function () {
		// 	Swiper01.autoplay.stop();
		// }

		//鼠标离开开始自动切换
		// Swiper01.el.onmouseout = function () {
		// 	Swiper01.autoplay.start();
		// }
		bianhua();
	});

	// 判断竖线
	var i = $('.news_list02 .top .left .btns.cur').index();
	$('.news_list02 .top .left .btns').eq(i - 1).addClass('prev').siblings().removeClass('prev')

	// 年下拉效果
	$('.news_list02 .top .right .form_item .sel_span').on('click', function () {
		if ($(this).hasClass('cur')) {
			$(this).removeClass('cur').siblings('.sel_down').stop().slideUp();
		} else {
			$(this).addClass('cur').siblings('.sel_down').stop().slideDown();
			$(this).parent().siblings().find('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
		}
	})

	$('.news_list02 .top .right .box .form_item .inp')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			key = $('.news_list02 .top .right .box .form_item .inp').val();
			if (key === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
			} else {
				getData();
			}
		}
	}

	$('.news_list02 .top .right .box .form_item .key_btn').on('click', '', function (event) {
		key = $('.news_list02 .top .right .box .form_item .inp').val();
		if (key === "") {
			$.box.alert("Information cannot be empty!", null, {
				title: "Hint"
			})
		} else {
			getData();
		}
	});

	getYear();
	getkeyWords();
	getData();

	//查询年份
	function getYear() {
		$.post("/ext/ajax_news.jsp", { flag: "getYear", channelId: channelId }, function (data) {
			$('.news_list02 .top .right .box .form_item .sel_down .yearSelect').html(data);
			$('.news_list02 .top .right .form_item .sel_down li').on('click', function () {
				var thisVal = $(this).html();
				year = thisVal;
				getData();
				$(this).parent().parent().siblings('.sel_span').html(thisVal);
				$(this).parent().parent().siblings('.sel_span').removeClass('cur').siblings('.sel_down').stop().slideUp();
			})
		});
	}

	//关键字
	function getkeyWords() {
		$.post("/ext/ajax_news.jsp", { flag: "getKeywords" }, function (data) {
			$(".news_list02 .bott .right .item .item_con.keyList").html(data);
			$('.news_list02 .bott .right .item .item_con.keyList span').click(function () {
				key = $.trim($(this).html());
				$(".news_list02 .top .right .box .form_item .inp").val(key);
				getData();
			})
		});
	}

	function getData() {
		$.post("/ext/ajax_news.jsp", { flag: "getData", channelId: channelId, key: key, year: year }, function (data) {
			if ($.trim(data)) {
				$("#container").html(data);
			} else {
				$("#container").html('No Data!');
			}
			$('.news_list02 .bott li .words .key_words span').click(function () {
				key = $.trim($(this).html());
				$(".news_list02 .top .right .box .form_item .inp").val(key);
				getData();
			})
			bianhua();
		});
	}

	var st = null;
	function isIE() {
		return window.document.documentMode ? true : false;
	}
	function bianhua() {
		if (st) {
			st.kill();
			st = null;
		}
		$('.news_list02 .bott .right .item1').css({ 'transition': 'all .5s ease' });
		$('.news_list02 .bott .right .item2').css({ 'margin-bottom': 0 });
		if (base.getType() == "Pc" && !isIE()) {
			var gap = parseInt($('.news_list02 .bott .right .item').css('marginBottom').replace('px', ''));
			var startOffset = $('.header').height() + gap;
			var endOffset = $('.news_list02 .bott .right').height() + startOffset;
			st = ScrollTrigger.create({
				trigger: '.news_list02 .bott .left',
				start: 'top-=' + startOffset + 'px top',
				endTrigger: '.news_list02 .bott .left',
				end: 'bottom-=' + endOffset + 'px top',
				pin: '.news_list02 .bott .right',
				onUpdate: function (self) {
					if ($('.header').hasClass('fixed')) {
						$('.news_list02 .bott .right .item1').css({ 'margin-top': '0' });
					} else {
						$('.news_list02 .bott .right .item1').css({ 'margin-top': '0' });
					}
				},
				onLeaveBack: function () {
					$('.news_list02 .bott .right .item1').css({ 'margin-top': '0' });
				}
			});
		} else {
			$('.news_list02 .bott .right .item1').css({ 'margin-top': '0' });
		}
	}

	require('box');
	//新闻订阅提交
	$('#emailInput')[0].onkeydown = function (event) {
		if (event.keyCode === 13) { // 如果按下的是回车键
			var input = $('#emailInput')[0];
			if (input.value === "") {
				$.box.alert("Information cannot be empty!", null, {
					title: "Hint"
				})
				return false; // 阻止提交
			}
		}
	}
	$('#emailsubmit').click(function () {
		var email = $('#emailInput').val();
		$.post("/ext/from_dingyue.jsp", { email: email }, function (data) {
			if ($.trim(data) == 'ok') {
				$.box.alert("Successfully submitted, thank you for your subscription!", null, {
					title: "Successfully submitted"
				})
				$('#emailInput').val("");
			} else if ($.trim(data) == 'notemail') {
				$.box.alert("Incorrect email format!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'exit') {
				$.box.alert("The email has already submitted a subscription!", null, {
					title: "Verification Failed"
				})
			} else if ($.trim(data) == 'outsize') {
				$.box.alert("The number of submissions today has exceeded the limit!", null, {
					title: "Verification Failed"
				})
			}
		})
	})

});