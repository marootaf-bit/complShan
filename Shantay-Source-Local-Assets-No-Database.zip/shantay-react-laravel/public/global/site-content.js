(()=>{
 const init=()=>{
  const fa=document.documentElement.lang.startsWith('fa');
  document.querySelector('#cmsBranchPicker')?.addEventListener('change',event=>{document.querySelectorAll('.cms-branch').forEach(branch=>branch.hidden=branch.dataset.branch!==event.target.value);const field=document.querySelector('.cms-contact-form [name=branch_id]');if(field)field.value=event.target.value});
  document.querySelectorAll('[data-news-filter]').forEach(button=>button.addEventListener('click',()=>{
   const filter=button.dataset.newsFilter;document.querySelectorAll('[data-news-filter]').forEach(b=>{b.classList.toggle('is-active',b===button);b.setAttribute('aria-pressed',b===button?'true':'false')});
   document.querySelectorAll('.cms-owned-news').forEach(n=>n.hidden=filter==='manufacturer');document.querySelectorAll('[data-cms-manufacturer]').forEach(n=>n.hidden=filter==='local');
  }));
  const openStory=()=>{if(!/^#local-news-[A-Za-z0-9_-]+$/.test(location.hash))return;const story=document.getElementById(location.hash.slice(1));if(!story)return;document.querySelector('[data-news-filter=local]')?.click();const details=story.querySelector('details');if(details)details.open=true;story.scrollIntoView({block:'start'});};openStory();window.addEventListener('hashchange',openStory);
  for(const form of document.querySelectorAll('.cms-contact-form'))form.addEventListener('submit',async event=>{
   event.preventDefault();if(form.dataset.sending==='1')return;
   const status=form.querySelector('.cms-form-status'),button=form.querySelector('button[type=submit]');const data=Object.fromEntries(new FormData(form));const show=(text,error)=>{status.textContent=text;status.dataset.error=error?'1':'0'};
   const validation=await FormValidation.validate('contact_message',{...data,source_page:form.dataset.origin},form);if(!validation.valid){show(validation.message,true);return;}
   if(!form.reportValidity())return;
   if(!data.phone?.trim()&&!data.email?.trim()){show(fa?'شمارهٔ تماس یا ایمیل معتبر وارد کنید.':'Enter a valid telephone or email.',true);return;}
   if(new URLSearchParams(location.search).has('cms_preview')){show(fa?'این پیش‌نمایش است؛ پیام ارسال نشد.':'Preview only. No message was sent.',true);return;}
   form.dataset.sending='1';button.disabled=true;show(fa?'در حال ارسال…':'Sending…',false);
   try{
    const response=await fetch('/api/requests',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},credentials:'same-origin',body:JSON.stringify({...data,form_type:'contact_message',source_page:form.dataset.origin})});
    const result=await response.json().catch(()=>({}));
    if(!response.ok){if(result.errors){FormValidation.show(result.errors,form,false);throw Error(fa?'لطفاً موارد مشخص‌شده را اصلاح کنید.':'Please correct the highlighted fields.')}const text=response.status===429?(fa?'درخواست‌های زیادی ارسال شده؛ کمی بعد دوباره تلاش کنید.':'Too many requests. Please try again later.'):(fa?'پیام ذخیره نشد؛ نام، متن پیام و معلومات تماس را بررسی کنید.':'Message not saved. Check your name, message and contact details.');throw Error(text)}
    if(!result.stored)throw Error(fa?'ذخیرهٔ پیام تأیید نشد؛ دوباره تلاش کنید.':'Message storage was not confirmed. Please retry.');
    form.reset();if(form.elements.branch_id&&data.branch_id)form.elements.branch_id.value=data.branch_id;show(fa?'پیام شما با شمارهٔ '+result.id+' در سامانهٔ نمایندگی ثبت شد.':'Your message was saved with reference '+result.id+'.',false);
   }catch(error){show(error instanceof TypeError?(fa?'ارتباط برقرار نشد؛ دوباره تلاش کنید.':'Connection failed. Please retry.'):error.message,true)}
   finally{form.dataset.sending='0';button.disabled=false;}
  });
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
