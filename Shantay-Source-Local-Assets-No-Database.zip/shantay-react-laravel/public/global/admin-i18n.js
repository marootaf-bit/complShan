(() => {
  const STORAGE_KEY = 'shantui-lang';
  const COOKIE_KEY = 'shantui_lang';
  const normalize = value => {
    const locale = String(value || '').trim().replaceAll('_', '-').toLowerCase();
    if (locale === 'en' || locale.startsWith('en-')) return 'en';
    if (locale === 'fa' || locale.startsWith('fa-') || locale === 'prs' || locale.startsWith('prs-')) return 'fa-AF';
    return null;
  };
  const fromCookie = () => {
    try {
      const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${COOKIE_KEY}=([^;]+)`));
      return match ? normalize(decodeURIComponent(match[1])) : null;
    } catch { return null; }
  };
  const queryLocale = normalize(new URLSearchParams(location.search).get('lang'));
  let locale = queryLocale;
  if (!locale) {
    try { locale = normalize(localStorage.getItem(STORAGE_KEY)); } catch {}
  }
  locale ||= fromCookie() || normalize(navigator.language) || 'fa-AF';

  let catalog = {};
  let fallbackCatalog = {};
  const get = (object, path) => path.split('.').reduce((value, key) => value && value[key], object);
  const load = async () => {
    const fallbackLocale = locale === 'fa-AF' ? 'en' : 'fa-AF';
    const [primary, fallback] = await Promise.all([
      fetch(`/global/locales/${locale}.json`, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : {}).catch(() => ({})),
      fetch(`/global/locales/${fallbackLocale}.json`, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : {}).catch(() => ({})),
    ]);
    catalog = primary;
    fallbackCatalog = fallback;
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'fa-AF' ? 'rtl' : 'ltr';
  };
  const t = (path, values = {}) => {
    let text = get(catalog, path) ?? get(fallbackCatalog, path) ?? path;
    if (typeof text !== 'string') return path;
    return text.replace(/\{\{(\w+)\}\}/g, (_, key) => String(values[key] ?? ''));
  };
  const switchLanguage = async () => {
    if (!window.confirm(t('admin.unsavedSwitchWarning'))) return;
    const next = locale === 'fa-AF' ? 'en' : 'fa-AF';
    try { localStorage.setItem(STORAGE_KEY, next === 'fa-AF' ? 'fa' : 'en'); } catch {}
    try { document.cookie = `${COOKIE_KEY}=${encodeURIComponent(next)}; Path=/; Max-Age=2592000; SameSite=Lax`; } catch {}
    const url = new URL(location.href);
    url.searchParams.set('lang', next === 'fa-AF' ? 'fa' : 'en');
    location.assign(url.toString());
  };

  window.AdminI18n = { locale, t, switchLanguage, ready: load() };
})();
