/* Shared validation contract; local only. Server validation remains authoritative. */
window.FormValidation=(()=>{
 const nativeFetch=window.fetch.bind(window);let contract;
 const ready=nativeFetch('/global/validation-rules.json',{credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error('Validation rules unavailable');return r.json()}).then(c=>contract=c);
 const fa=()=>document.documentElement.lang.startsWith('fa');
 const messages={required:['این مورد ضروری است.','This field is required.'],type:['نوع مقدار درست نیست.','Invalid value type.'],min:['مقدار از حداقل مجاز کمتر است.','Below the minimum allowed.'],max:['مقدار از حداکثر مجاز بیشتر است.','Above the maximum allowed.'],format:['قالب مقدار درست نیست.','Invalid format.'],enum:['گزینهٔ معتبر انتخاب کنید.','Choose a valid option.'],accepted:['رضایت خود را تأیید کنید.','Please confirm your consent.'],pair:['عرض و طول جغرافیایی را با هم وارد کنید.','Enter latitude and longitude together.'],contact:['تلفن یا ایمیل معتبر لازم است.','A valid phone or email is required.'],distinct:['شناسهٔ تکراری وجود دارد.','Duplicate identifiers.'],unknown:['این فیلد مجاز نیست.','This field is not allowed.']};
 const match=(pattern,value)=>new RegExp('(?:'+pattern+')(?![\\s\\S])','iu').test(value);
 const blank=v=>v===null||v===undefined||(typeof v==='string'&&!v.trim());
 function errors(kind,payload){
  if(!contract)throw Error('Validation rules unavailable');const result={};
  function walk(rule,value,path,exists=true){
   if(rule.ref)rule={...contract.forms[rule.ref],...rule};const fail=code=>(result[path||'_form']??=[]).push(code);
   if(rule.present&&!exists){fail('required');return}
   if(!exists||blank(value)){if(rule.required||(exists&&rule.nonEmpty))fail('required');return}
   if(rule.accepted){if(!['yes','on',1,'1',true,'true'].includes(value))fail('accepted');return}
   const t=rule.type,isObject=value&&typeof value==='object'&&(!Array.isArray(value)||value.length===0);
   const valid=({string:()=>typeof value==='string',number:()=>['string','number'].includes(typeof value)&&Number.isFinite(Number(value)),integer:()=>typeof value==='number'?Number.isInteger(value):typeof value==='string'&&/^\d+$/.test(value),boolean:()=>typeof value==='boolean',array:()=>Array.isArray(value),object:()=>isObject})[t];
   if(valid&&!valid()){fail('type');return}
   const v=typeof value==='string'&&!rule.raw?value.trim():value;
   const size=['number','integer'].includes(t)?Number(v):typeof v==='string'?v.length:v&&typeof v==='object'?Object.keys(v).length:0;
   if(rule.min!==undefined&&size<rule.min)fail('min');if(rule.max!==undefined&&size>rule.max)fail('max');
   if(rule.enum&&!rule.enum.includes(v))fail('enum');if(rule.noTraversal&&v.includes('..'))fail('format');
   if(rule.format&&typeof v==='string'){
    let ok;if(rule.format==='date'){const d=new Date(v+'T00:00:00Z');ok=/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(d.valueOf())&&d.toISOString().slice(0,10)===v}
    else ok=match(contract.formats[rule.format],v);
    if(!ok)fail('format');
   }
   if(t==='object'){
    for(const [key,r]of Object.entries(rule.properties||{}))walk(r,v[key],path?path+'.'+key:key,Object.hasOwn(v,key));
    if(rule.unknown===false)for(const key of Object.keys(v))if(!Object.hasOwn(rule.properties,key))(result[path+'.'+key]??=[]).push('unknown');
    for(const [a,b]of rule.pairs||[])if(!blank(v[a])!==!blank(v[b]))(result[(path?path+'.':'')+a]??=[]).push('pair');
    if(rule.requireAny&&!rule.requireAny.some(k=>!blank(v[k])))(result[(path?path+'.':'')+rule.requireAny[0]]??=[]).push('contact');
   }
   if(t==='array'){
    v.forEach((entry,i)=>rule.items&&walk(rule.items,entry,path+'.'+i));
    if(rule.distinct){const keys=v.filter(x=>x&&typeof x==='object'&&Object.hasOwn(x,rule.distinct)).map(x=>x[rule.distinct]);if(new Set(keys).size!==keys.length)fail('distinct')}
   }
  }
  walk(contract.forms[kind],payload,'');
  if(kind==='setting'&&typeof payload.key==='string'&&payload.key.startsWith('dealer.')){const e=errors('profile_fields',{[payload.key]:payload.value??''});for(const codes of Object.values(e))result.value=codes}
  if(kind==='visual')for(const [i,e]of (Array.isArray(payload.changes)?payload.changes:[]).entries()){
   if(e.reset===true)continue;const v=e.value??'',format=({href:'link',src:'media',background:'image',poster:'image'})[e.kind];
   if(e.kind==='visible'&&!['0','1'].includes(v))(result['changes.'+i+'.value']??=[]).push('enum');
   if(format&&(typeof v!=='string'||!match(contract.formats[format],v)||(['image','media'].includes(format)&&v.includes('..'))))(result['changes.'+i+'.value']??=[]).push('format');
  }
  return result;
 }
 const idMap={email:['login [name=email]'],password:['login [name=password]'],path:['newPath'],title:['title','newTitle'],html:['html','newHtml','fragmentHtml','newFragmentHtml'],fa_title:['faTitle','newFaTitle'],fa_html:['faHtml','newFaHtml','fragmentFaHtml','newFragmentFaHtml'],source:['newSource'],translated:['newTranslation'],key:['settingKey'],value:['settingValue'],flag:['newFragmentFlag'],channel_id:['newFragmentChannel'],filters:['newFragmentFilters']};
 let requestContext=null;
 function field(path,scope=document){
  if(scope!==document)return [...scope.querySelectorAll('[name]')].find(e=>e.name===path)||null;
  if(path==='email'&&document.querySelector('#emailInput'))return document.querySelector('#emailInput');
  const edit=path.match(/^changes\.(\d+)\.value$/);if(edit){const xpath=requestContext?.changes?.[edit[1]]?.xpath;return [...document.querySelectorAll('[data-xpath]')].find(e=>e.dataset.xpath===xpath)||null}
  const collection=path.match(/^items\.(\d+)\.(.+)$/);
  if(collection){const b=document.querySelector('#cmsItems [data-index="'+collection[1]+'"]');if(b&&!b.classList.contains('active'))b.click();return document.querySelector('[data-field="'+CSS.escape(collection[2])+'"]')}
  if(path.startsWith('settings.'))return document.querySelector('[name="'+CSS.escape(path.slice(9))+'"]');
  if(path==='value'&&document.activeElement?.closest('.row'))return document.activeElement.closest('.row').querySelector('input');
  if(path==='translated'&&document.activeElement?.closest('.row'))return document.activeElement.closest('.row').querySelector('input');
  const ids=idMap[path]||[];let nodes=ids.map(id=>document.getElementById(id)||document.querySelector('#'+id)).filter(Boolean);
  if(document.activeElement?.id?.startsWith('create'))nodes.sort((a,b)=>Number(!a.id.startsWith('new'))-Number(!b.id.startsWith('new')));
  return nodes[0]||document.querySelector('[name="'+CSS.escape(path)+'"]');
 }
 function clear(scope=document){scope.querySelectorAll('[data-validation-error]').forEach(e=>e.remove());scope.querySelectorAll('[aria-invalid="true"]').forEach(e=>{e.removeAttribute('aria-invalid');e.removeAttribute('aria-describedby');e.setCustomValidity?.('')})}
 function show(errs,scope=document,codes=true){
  clear(scope);let first=null;const lines=[];const firstItem=Object.keys(errs).find(k=>/^items\.\d+\./.test(k))?.split('.')[1];
  for(const [path,values]of Object.entries(errs)){
   const text=values.map(x=>codes?(messages[x]||[x,x])[fa()?0:1]:x).join(' ');let input=/^items\.\d+\./.test(path)&&path.split('.')[1]!==firstItem?null:field(path,scope);
   const parentLabel=input?.closest('label');let label=parentLabel?.querySelector('span')?.textContent?.trim();if(!label&&parentLabel){const copy=parentLabel.cloneNode(true);copy.querySelectorAll('input,textarea,select,small').forEach(n=>n.remove());label=copy.textContent.trim()}label||=input?.getAttribute('placeholder')?.trim()||input?.closest('.inp_wrap')?.querySelector('label')?.textContent?.trim()||path;lines.push(label+': '+text);
   if(input){const note=document.createElement('small');note.dataset.validationError='1';note.id='validation-'+Math.random().toString(36).slice(2);note.textContent=text;note.style.cssText='display:block;color:#a2222c;font:13px/1.8 Vazirmatn,Arial,sans-serif';if(input.type==='checkbox'){note.style.flexBasis='100%';note.style.gridColumn='2';const label=input.closest('label');if(label){if(!label.classList.contains('form-validation-consent'))label.style.flexWrap='wrap';label.append(note)}else input.insertAdjacentElement('afterend',note)}else input.insertAdjacentElement('afterend',note);input.setAttribute('aria-invalid','true');input.setAttribute('aria-describedby',note.id);first??=input}
  }
  first?.focus();const summary=lines.slice(0,6).join('\n');return summary;
 }
 function validationError(message){const error=Error(message);error.isValidationError=true;return error}
 function parseFilters(value){try{return JSON.parse(value||'{}')}catch{throw validationError(show({filters:[fa()?'JSON معتبر وارد کنید.':'Enter valid JSON.']},document,false))}}
 function serverError(errs){return validationError(show(errs,document,false))}
 async function validate(kind,payload,scope=document){await ready;const e=errors(kind,payload);if(scope!==document)for(const input of scope.querySelectorAll('input[name]'))if(input.validity.badInput)e[input.name]=['format'];if(Object.keys(e).length)return {valid:false,message:show(e,scope),errors:e};clear(scope);return {valid:true,errors:{}}}
 function route(method,path){for(const [key,kind]of Object.entries(contract.routes)){const space=key.indexOf(' '),m=key.slice(0,space),p=key.slice(space+1);if(m===method&&new RegExp('^'+p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/\\\*/g,'[^/]+')+'$').test(path))return kind}return null}
 async function checkRequest(url,opts={}){
  await ready;const method=(opts.method||'GET').toUpperCase(),path=new URL(url,location.origin).pathname,kind=route(method,path);if(!kind||opts.body instanceof FormData||typeof opts.body!=='string')return;
  const data=JSON.parse(opts.body);requestContext=data;const badNumber=[...document.querySelectorAll('#cmsEditor input[type=number]')].find(e=>e.validity.badInput);if(badNumber){const index=document.querySelector('#cmsItems .active')?.dataset.index||'0';throw validationError(show({['items.'+index+'.'+badNumber.dataset.field]:['format']}))}const limit=contract.maxJsonBytes[kind];if(limit&&new TextEncoder().encode(opts.body).length>limit)throw validationError(show({_form:['max']}));const r=await validate(kind,data);if(!r.valid)throw validationError(r.message);
 }
 function apply(form,kind){
  const rules=contract.forms[kind]?.properties||{};
  for(const e of form.querySelectorAll('input,textarea,select')){const r=rules[e.name];if(!r)continue;e.required=!!r.required;if(r.max!==undefined&&r.type==='string')e.maxLength=r.max;if(r.min!==undefined&&r.type==='string')e.minLength=r.min;if(r.format==='email')e.type='email';if(r.format==='date')e.type='date'}
 }
 function hydrate(){
  if(!contract)return;
  for(const form of document.querySelectorAll('form')){if((form.getAttribute('action')||'').endsWith('/site/search.htm')){apply(form,'search');continue;}if(!form.dataset.validationKind){const action=form.getAttribute('action')||'';for(const [suffix,kind]of Object.entries(contract.legacyActions))if(action.endsWith(suffix))form.dataset.validationKind=kind;}if(!form.dataset.validationKind&&!form.matches('.cms-contact-form'))continue;
   const kind=form.dataset.validationKind||'contact_message';apply(form,kind);
   if(form.dataset.validationKind){form.noValidate=true;
    if(!form.querySelector('[name=form_type]')){const input=document.createElement('input');input.type='hidden';input.name='form_type';input.value=kind;form.append(input)}
    if(!form.querySelector('[name=consent]')){form.querySelectorAll('.agree_btn').forEach(e=>{e.style.setProperty('display','none','important')});const label=document.createElement('label');label.className='form-validation-consent';label.style.cssText='display:grid;grid-template-columns:18px minmax(0,1fr);align-items:start;gap:5px 8px;clear:both;margin:16px 0;font:14px/1.9 Vazirmatn,Arial,sans-serif';const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.name='consent';checkbox.required=true;checkbox.style.cssText='width:18px;height:18px;flex:none;margin-top:5px';const text=document.createElement('span');text.style.cssText='grid-column:2;min-width:0';text.textContent=fa()?'با استفاده از معلومات تماس برای پاسخ به این درخواست موافقم.':'I agree to use of my contact details to respond to this request.';const privacy=document.createElement('a');privacy.href='/site/Privacy.htm?lang='+(fa()?'fa':'en');privacy.textContent=fa()?'حریم خصوصی':'Privacy';privacy.style.cssText='grid-column:2;color:#665000;text-decoration:underline';label.append(checkbox,text,privacy);const button=form.querySelector('.sub_btn,.form_btns,.btn_,button:not([type=button]):not([type=reset]),input[type=submit]');if(button)(button.closest('.btns')||button).insertAdjacentElement('beforebegin',label);else form.append(label)}
   }
  }
  const newsletter=document.querySelector('#emailInput');if(newsletter){newsletter.maxLength=180;newsletter.type='email'}
  document.querySelectorAll('#translations input').forEach(e=>e.maxLength=6000);
  document.querySelectorAll('form[data-validation-kind] button:not([type=button]):not([type=reset])').forEach(b=>{const label=fa()?'ارسال درخواست':'Send request';if(b.textContent!==label)b.textContent=label;b.style.fontFamily='inherit'});
  for(const [key,ids]of Object.entries(idMap))for(const id of ids){const e=document.getElementById(id);if(!e)continue;const r=Object.values(contract.forms).map(x=>x.properties?.[key]).find(x=>x?.max!==undefined);if(r&&['INPUT','TEXTAREA'].includes(e.tagName))e.maxLength=r.max}
  for(const e of document.querySelectorAll('[data-field]')){const kind=document.querySelector('[data-tab].active')?.dataset.tab,r=contract.forms[kind]?.properties?.[e.dataset.field];if(r){e.required=!!r.required;if(r.type==='string'&&r.max!==undefined)e.maxLength=r.max;if(r.type==='number'){e.min=r.min;e.max=r.max}}}
  for(const e of document.querySelectorAll('#dealerProfileEditor [name]')){const r=contract.forms.profile_fields.properties[e.name];if(r?.max)e.maxLength=r.max}
 }
 function fileError(file,imagesOnly=false){if(!file)return 'No file';const limit=contract.uploads[file.type];if(!limit||(imagesOnly&&!file.type.startsWith('image/')))return fa()?'نوع فایل مجاز نیست.':'File type is not allowed.';if(file.size>limit)return fa()?'حجم فایل از حد مجاز بیشتر است.':'File exceeds the allowed size.';return null}
 window.addEventListener('unhandledrejection',event=>{if(event.reason?.isValidationError){event.preventDefault();const status=document.querySelector('#status');if(status)status.textContent=event.reason.message}});
 ready.then(()=>{hydrate();const observer=new MutationObserver(()=>hydrate());observer.observe(document.documentElement,{childList:true,subtree:true});document.addEventListener('input',e=>{if(e.target.matches('[aria-invalid=true]')){e.target.removeAttribute('aria-invalid');e.target.setCustomValidity?.('');const next=e.target.nextElementSibling;if(next?.dataset.validationError)next.remove()}})}).catch(()=>{});
 return {ready,errors,validate,checkRequest,serverError,show,apply,fileError,parseFilters,get contract(){return contract}};
})();
