'use strict';
(()=>{
const $=s=>document.querySelector(s), el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
let state,revision,kind='products',view='items',page=1,editing=null,retiring=null,media=[],editorGeneration=0,mediaLimit=60;
const size=25,editor=$('#editor'),form=$('#editForm');
function message(text,bad=false){$('#message').textContent=text;$('#message').className=bad?'error':'';}
async function api(path='',method='GET',data){const r=await fetch('/api/admin/catalogue-editor'+path,{method,credentials:'same-origin',headers:{'Accept':'application/json','Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})});const d=await r.json().catch(()=>({}));if(!r.ok){const e=Error(r.status===401?'ابتدا وارد داشبورد مدیریت شوید؛ در پیش‌نمایش محلی، نشانی آغاز پیش‌نمایش را باز کنید.':r.status===409?'اطلاعات هم‌زمان تغییر کرده است. این پنجره را ببندید و «بارگذاری دوباره» را بزنید؛ ذخیرهٔ شما بازنویسی نشد.':Object.values(d.errors||{}).flat().join('\n')||d.message||'دریافت یا ذخیره انجام نشد.');e.status=r.status;throw e;}return d;}
function accept(r){state=r.data;revision=r.revision;$('#add').disabled=false;render();}
async function load(){try{message('در حال دریافت اطلاعات…');accept(await api());message('فهرست مدیریت آماده است؛ نمایش عمومی هنوز متصل نیست.');}catch(e){message(e.message,true);}}
function groupLabel(id){return state.groups.find(g=>g.id===id)?.name_fa||id;}
function render(){
 if(!state)return;
 $('#heading').textContent=kind==='products'?'محصولات':'قطعات';$('#add').textContent=view==='groups'?'افزودن گروپ':kind==='products'?'افزودن محصول':'افزودن قطعه';
 $('#productCount').textContent=state.items.filter(i=>i.kind==='products').length;$('#partCount').textContent=state.items.filter(i=>i.kind==='parts').length;
 document.querySelectorAll('.kind').forEach(b=>b.classList.toggle('active',b.dataset.kind===kind));$('#itemsTab').classList.toggle('active',view==='items');$('#groupsTab').classList.toggle('active',view==='groups');
 const gf=$('#groupFilter'),selected=gf.value;gf.replaceChildren(new Option('همهٔ گروپ‌ها',''));state.groups.filter(g=>g.kind===kind).forEach(g=>gf.add(new Option(g.name_fa,g.id)));gf.value=selected;gf.hidden=view==='groups';
 const q=$('#search').value.trim().toLocaleLowerCase(),status=$('#statusFilter').value;
 const rows=state[view].filter(r=>r.kind===kind&&(!q||[r.name_fa,r.name_en,r.path].some(v=>(v||'').toLocaleLowerCase().includes(q)))&&(!status||r.published===(status==='active'))&&(view!=='items'||!gf.value||r.group_ids.includes(gf.value)));
 const count=Math.max(1,Math.ceil(rows.length/size));page=Math.min(page,count);$('#pageInfo').textContent=`صفحهٔ ${page} از ${count} — ${rows.length} مورد`;$('#prev').disabled=page<=1;$('#next').disabled=page>=count;
 const list=$('#records');list.replaceChildren();if(!rows.length)list.append(el('p','موردی پیدا نشد.','empty'));
 rows.slice((page-1)*size,page*size).forEach(r=>{
  const card=el('article',undefined,'record'),body=el('div'),title=el('strong',r.name_fa),badge=el('span',r.published?'فعال در مدیریت':'غیرفعال','badge'+(r.published?'':' off'));title.append(badge);body.append(title);
  if(r.name_en&&r.name_en!==r.name_fa)body.append(el('div',r.name_en,'meta'));
  body.append(el('div',view==='items'?r.group_ids.map(groupLabel).join('، '):`${state.items.filter(i=>i.group_ids.includes(r.id)).length} مورد مرتبط`,'meta'));
  body.append(el('div',r.legacy?'موجود در سورس اصلی — نشانی و اطلاعات اصلی حفظ می‌شوند':'مورد تازه — هنوز در سایت عمومی نمایش داده نمی‌شود','meta'));
  const actions=el('div',undefined,'actions'),edit=el('button','ویرایش','secondary');edit.onclick=()=>openEditor(r);actions.append(edit);
  if(view==='groups'&&(r.published||state.items.some(i=>i.group_ids.includes(r.id)))){const retire=el('button','انتقال / غیرفعال‌سازی','secondary');retire.onclick=()=>openRetire(r);actions.append(retire);}
  card.append(body,actions);list.append(card);
 });
}
function specRow(spec={name:'',value:''}){const row=el('div',undefined,'spec-row');for(const [key,label] of [['name','نام مشخصه'],['value','مقدار']]){const input=el('input');input.dataset.spec=key;input.value=spec[key];input.placeholder=label;input.setAttribute('aria-label',label);input.maxLength=key==='name'?160:600;input.required=true;row.append(input);}const remove=el('button','حذف ردیف');remove.type='button';remove.onclick=()=>row.remove();row.append(remove);$('#specs').append(row);}
function openEditor(row){editorGeneration++;editing=row;form.reset();$('#editError').textContent='';$('#save').disabled=false;$('#specs').replaceChildren();$('#mediaPanel').hidden=true;$('#mediaGrid').replaceChildren();
 const item=view==='items';document.querySelectorAll('.item-only').forEach(n=>n.hidden=!item);$('#dialogTitle').textContent=(row?'ویرایش ':'افزودن ')+(item?(kind==='products'?'محصول':'قطعه'):'گروپ');
 for(const key of ['name_fa','name_en','description_fa','description_en','image'])form.elements[key].value=row?.[key]||'';form.elements.published.checked=row?.published??true;
 const choices=$('#groupChoices');choices.replaceChildren();state.groups.filter(g=>g.kind===kind&&(g.published||(row?.group_ids||[]).includes(g.id))).forEach(g=>{const label=el('label'),c=el('input');c.type='checkbox';c.value=g.id;c.name='group_ids';c.checked=row?.group_ids?.includes(g.id)||false;label.append(c,document.createTextNode(g.name_fa+(g.published?'':' (غیرفعال)')));choices.append(label);});
 if(!choices.childElementCount)choices.append(el('p','ابتدا یک گروپ فعال در همین بخش بسازید.','error'));
 (row?.specs||[]).forEach(specRow);editor.showModal();form.elements.name_fa.focus();
}
form.onsubmit=async e=>{e.preventDefault();$('#editError').textContent='';const data={revision,kind,name_fa:form.elements.name_fa.value,name_en:form.elements.name_en.value,published:form.elements.published.checked};
 if(view==='items'){Object.assign(data,{group_ids:[...form.querySelectorAll('[name=group_ids]:checked')].map(i=>i.value),image:form.elements.image.value.trim(),description_fa:form.elements.description_fa.value,description_en:form.elements.description_en.value,specs:[...$('#specs').children].map(r=>({name:r.querySelector('[data-spec=name]').value,value:r.querySelector('[data-spec=value]').value}))});if(!data.group_ids.length){$('#editError').textContent='حداقل یک گروپ انتخاب کنید.';return;}}
 $('#save').disabled=true;try{const result=await api('/'+view+(editing?'/'+encodeURIComponent(editing.id):''),editing?'PATCH':'POST',data);accept(result);editor.close();message('اطلاعات در مدیریت ذخیره شد؛ سایت عمومی تغییر نکرد.');}catch(e){$('#editError').textContent=e.message;}finally{$('#save').disabled=false;}
};
function openRetire(g){retiring=g;const children=state.items.filter(i=>i.group_ids.includes(g.id));$('#retireSummary').textContent=`«${g.name_fa}» دارای ${children.length} مورد است.`;const select=$('#transferTarget');select.replaceChildren(new Option(children.length?'انتخاب مقصد الزامی است':'بدون انتقال — گروپ خالی است',''));state.groups.filter(x=>x.kind===g.kind&&x.id!==g.id&&x.published).forEach(x=>select.add(new Option(x.name_fa,x.id)));select.required=children.length>0;$('#retireError').textContent='';$('#retireDialog').showModal();}
$('#retireForm').onsubmit=async e=>{e.preventDefault();$('#retireSave').disabled=true;try{const result=await api('/groups/'+encodeURIComponent(retiring.id)+'/retire','POST',{revision,target_group_id:$('#transferTarget').value||null});accept(result);$('#retireDialog').close();message(`${result.transferred} مورد منتقل شد؛ گروپ غیرفعال شد. هیچ موردی حذف نشد.`);}catch(e){$('#retireError').textContent=e.message;}finally{$('#retireSave').disabled=false;}};
$('#retireCancel').onclick=()=>$('#retireDialog').close();document.querySelectorAll('.close').forEach(b=>b.onclick=()=>editor.close());$('#addSpec').onclick=()=>specRow();$('#add').onclick=()=>openEditor(null);$('#reload').onclick=()=>load();
document.querySelectorAll('.kind').forEach(b=>b.onclick=()=>{kind=b.dataset.kind;page=1;$('#groupFilter').value='';render();});
for(const [id,value] of [['#itemsTab','items'],['#groupsTab','groups']])$(id).onclick=()=>{view=value;page=1;render();};
for(const id of ['#search','#groupFilter','#statusFilter'])$(id).addEventListener(id==='#search'?'input':'change',()=>{page=1;render();});$('#prev').onclick=()=>{page--;render();};$('#next').onclick=()=>{page++;render();};
function showMedia(){const grid=$('#mediaGrid'),q=$('#mediaSearch').value.toLowerCase(),names=new Map(state.items.filter(i=>i.image).map(i=>[i.image,i.name_fa]));grid.replaceChildren();const filtered=media.filter(m=>(m.path+' '+(names.get(m.path)||'')).toLowerCase().includes(q));filtered.slice(0,mediaLimit).forEach(m=>{const b=el('button',undefined,'media-item');b.type='button';const img=el('img');img.src=m.path;img.alt='';img.loading='lazy';img.onerror=()=>{b.disabled=true;b.title='این فایل در محیط محلی موجود نیست.';img.alt='در محیط محلی موجود نیست';};b.append(img,document.createTextNode(names.get(m.path)||m.path.split('/').pop()));b.onclick=()=>{form.elements.image.value=m.path;$('#mediaPanel').hidden=true;};grid.append(b);});$('#mediaInfo').textContent=`${Math.min(mediaLimit,filtered.length)} از ${filtered.length} عکس` ;$('#moreMedia').hidden=filtered.length<=mediaLimit;if(!grid.childElementCount)grid.append(el('p','عکسی پیدا نشد.'));}
$('#moreMedia').onclick=()=>{mediaLimit+=60;showMedia();};
$('#chooseMedia').onclick=async()=>{try{if(!media.length){const r=await fetch('/api/admin/media?include_catalogue=1&limit=2000',{credentials:'same-origin'});if(!r.ok)throw Error('فهرست عکس‌ها دریافت نشد.');media=(await r.json()).filter(m=>/\.(jpe?g|png|gif|webp|svg)$/i.test(m.path));}mediaLimit=60;$('#mediaPanel').hidden=false;showMedia();}catch(e){$('#editError').textContent=e.message;}};$('#mediaSearch').oninput=()=>{mediaLimit=60;showMedia();};
$('#photoUpload').onchange=async e=>{
 const file=e.target.files[0];if(!file)return;const generation=editorGeneration;
 if(!['image/jpeg','image/png','image/webp','image/gif'].includes(file.type)||file.size>8*1024*1024){$('#editError').textContent='عکس باید JPG، PNG، WebP یا GIF و حداکثر ۸ مگابایت باشد.';e.target.value='';return;}
 $('#save').disabled=true;$('#editError').textContent='در حال آپلود عکس در محیط محلی…';const data=new FormData();data.append('file',file);
 try{const r=await fetch('/api/admin/upload',{method:'POST',credentials:'same-origin',headers:{Accept:'application/json'},body:data});const result=await r.json();if(!r.ok)throw Error('آپلود انجام نشد؛ فرمت و حجم عکس را بررسی کنید.');if(editor.open&&editorGeneration===generation){form.elements.image.value=result.path;$('#editError').textContent='';}media=[];}
 catch(err){if(editorGeneration===generation)$('#editError').textContent=err.message;}
 finally{if(editorGeneration===generation){$('#save').disabled=false;e.target.value='';}}
};
load();
})();
