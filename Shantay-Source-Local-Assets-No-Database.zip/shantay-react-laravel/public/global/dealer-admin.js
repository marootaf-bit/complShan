/* Company fields use the existing authenticated settings dashboard; no public layout builder. */
window.DealerProfile={async mount(settings,api,msg,container){
 const labels=await fetch('/global/dealer-fields.json').then(r=>r.json());
 const title=document.createElement('h3');title.textContent='معلومات '+(settings['dealer.name_fa']??'نمایندگی');container.append(title);
 const note=document.createElement('p');note.className='notice';note.textContent='نام، لوگو، تماس، متن‌های معرفی و لینک‌های اجتماعی از همین بخش در تمام سایت خوانده می‌شوند. متن تاریخچه/خدمات نمونه است؛ لینک‌های example.com دیمو هستند. بخش قطعات فعال است؛ موجودی، قیمت و ضمانت باید برای هر درخواست تأیید شوند. ویرایش این موارد به تغییر HTML نیاز ندارد.';container.append(note);
 const form=document.createElement('form');form.className='grid2';form.noValidate=true;
 for(const [key,label] of Object.entries(labels)){
  if(key==='dealer.enabled')continue;
  const wrap=document.createElement('label');wrap.className='field';const span=document.createElement('span');span.textContent=label;wrap.append(span);
  let input;
  if(/(?:intro|products|process|history|services|privacy|manufacturer_note|parts_intro|parts_identification|parts_terms)_/.test(key)){input=document.createElement('textarea');input.style.minHeight='120px';input.style.font='inherit'}
  else if(key.endsWith('_enabled')){input=document.createElement('select');for(const [v,t] of [['0','غیرفعال'],['1','فعال']]){const o=document.createElement('option');o.value=v;o.textContent=t;input.append(o)}}
  else{input=document.createElement('input');input.type=key==='dealer.email'?'email':'text'}
  input.name=key;input.value=settings[key]??'';input.dir=key.endsWith('_en')||/social|phone|whatsapp|email|logo/.test(key)?'ltr':'rtl';input.style.textAlign='start';wrap.append(input);form.append(wrap);
 }
 const actions=document.createElement('div');actions.className='actions';actions.style.gridColumn='1/-1';
 const save=document.createElement('button');save.type='submit';save.textContent='ذخیرهٔ معلومات نمایندگی';
 const preview=document.createElement('a');preview.href='/global/home.html?lang=fa';preview.target='_blank';preview.rel='noopener';preview.textContent='مشاهدهٔ سایت';actions.append(save,preview);form.append(actions);
 form.addEventListener('submit',async e=>{e.preventDefault();save.disabled=true;try{await api('/api/admin/dealer-profile',{method:'PUT',body:JSON.stringify({settings:Object.fromEntries(new FormData(form))})});msg('معلومات نمایندگی ذخیره شد؛ صفحهٔ سایت را تازه کنید.')}catch(error){msg(error.message)}finally{save.disabled=false}});
 container.append(form);
 const label=document.createElement('label');label.className='field';label.textContent='آپلود لوگوی جدید (یا مسیر تصویر را در کادر لوگو وارد کنید)';const upload=document.createElement('input');upload.type='file';upload.accept='image/png,image/jpeg,image/webp';label.append(upload);container.append(label);
 upload.onchange=async()=>{const file=upload.files[0];if(!file)return;if(FormValidation.fileError(file,true)){msg('اندازهٔ لوگو باید کمتر از ۸ مگابایت باشد.');return}try{const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(file)});const result=await api('/api/admin/upload',{method:'POST',body:JSON.stringify({content_type:file.type,data})});form.elements['dealer.logo'].value=result.path;msg('لوگو آپلود شد؛ برای استفاده، معلومات نمایندگی را ذخیره کنید.')}catch(error){msg(error.message)}};
}};
