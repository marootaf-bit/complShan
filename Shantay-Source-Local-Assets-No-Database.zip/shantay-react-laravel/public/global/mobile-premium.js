/* Mobile progressive enhancement; restore original DOM when leaving mobile. */
(()=>{
 const start=()=>{
  const media=matchMedia('(max-width:780px)'),undo=[];
  const fa=document.documentElement.lang.toLowerCase().startsWith('fa');
  const paths=[
   'M3 10.5 12 3l9 7.5M5 9v12h5v-7h4v7h5V9',
   'm12 3 9 5-9 5-9-5 9-5Zm-9 5v9l9 5 9-5V8M12 13v9',
   'M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1 1-3Zm7 9a4 4 0 1 0-8 0 4 4 0 0 0 8 0Z',
   'm12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5',
   'M4 14v-3a8 8 0 0 1 16 0v3M4 12H2v7h5v-7H4Zm16 0h2v7h-5v-7h3ZM20 19c0 2-3 3-6 3'
  ];
  const apply=()=>{
   if(!media.matches||undo.length)return;
   document.querySelectorAll('.xc_banner.pro .xc_words .con').forEach(con=>{
    const marker=document.createComment('mobile-category-position'),details=document.createElement('details'),summary=document.createElement('summary');
    details.className='mp-category-copy';summary.textContent=fa?'دربارهٔ این دستهٔ محصولات':'About this product category';
    con.before(marker);con.before(details);details.append(summary,con);
    undo.push(()=>{marker.replaceWith(con);details.remove()});
   });
   document.querySelectorAll('.m_footer li .icon').forEach((icon,index)=>{
    if(!paths[index])return;
    const old=document.createDocumentFragment();while(icon.firstChild)old.append(icon.firstChild);
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    for(const [name,value] of Object.entries({viewBox:'0 0 24 24',width:'24',height:'24',fill:'none',stroke:'currentColor','stroke-width':'1.65','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true'}))svg.setAttribute(name,value);
    const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',paths[index]);svg.append(path);icon.append(svg);
    undo.push(()=>{svg.remove();icon.append(old)});
   });
  };
  const update=()=>{if(media.matches)apply();else while(undo.length)undo.pop()()};
  update();media.addEventListener('change',update);
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
