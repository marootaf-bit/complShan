// Hero actions must not bubble to the legacy banner's video-only click handler.
document.addEventListener('click',e=>{if(e.target.closest?.('a.dealer-hero-action'))e.stopPropagation()},true);
(()=>{const s=document.createElement('script');s.src='/global/locale-experience.js?v=20261103-rtl2';s.defer=true;document.head.appendChild(s)})();
(async () => {
  if (window.HTMLCanvasElement?.prototype && !window.HTMLCanvasElement.prototype.toDataurl) {
    window.HTMLCanvasElement.prototype.toDataurl = window.HTMLCanvasElement.prototype.toDataURL;
  }

  const root = document.documentElement;
  const query = new URLSearchParams(location.search);
  const normalize = value => {
    const locale = String(value || '').trim().replaceAll('_', '-').toLowerCase();
    if (locale === 'en' || locale.startsWith('en-')) return 'en';
    if (locale === 'fa' || locale.startsWith('fa-') || locale === 'prs' || locale.startsWith('prs-')) return 'fa-AF';
    return null;
  };
  const cookieValue = name => {
    try {
      const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${name}=([^;]+)`));
      return match ? decodeURIComponent(match[1]) : null;
    } catch { return null; }
  };
  let requestedLocale = normalize(query.get('lang'));
  if (!requestedLocale) {
    try { requestedLocale = normalize(localStorage.getItem('shantui-lang')); } catch {}
  }
  requestedLocale ||= normalize(cookieValue('shantui_lang')) || normalize(navigator.language) || 'fa-AF';
  const contentLocale = normalize(root.dataset.contentLocale || root.lang) || 'en';
  const translationStatus = root.dataset.translationStatus || 'source';
  const requestedCode = requestedLocale === 'fa-AF' ? 'fa' : 'en';
  const contentCode = contentLocale === 'fa-AF' ? 'fa' : 'en';
  const catalog = await fetch(`/global/locales/${requestedLocale}.json`, { credentials: 'same-origin' })
    .then(response => response.ok ? response.json() : {})
    .catch(() => ({}));
  const message = key => key.split('.').reduce((value, part) => value && value[part], catalog) || key;

  // Direction is tied to the language actually delivered, not a requested translation.
  root.lang = contentLocale;
  root.dir = contentCode === 'fa' ? 'rtl' : 'ltr';
  document.body.classList.add('af-global-copy', contentCode);

  const announceFallback = (status = translationStatus) => {
    if (requestedLocale !== 'fa-AF' || status === 'approved' || status === 'source') return;
    if (window.parent !== window) {
      window.parent.postMessage({ type: 'site-translation-status', requestedLocale, contentLocale, status }, location.origin);
      return;
    }
    if (contentCode === 'fa') { root.dataset.translationPreview = 'true'; return; }
    if (document.querySelector('.af-translation-notice')) return;
    const notice = document.createElement('div');
    notice.className = 'af-translation-notice';
    notice.setAttribute('role', 'status');
    notice.textContent = message('app.translationFallback');
    document.body.appendChild(notice);
  };
  announceFallback();

  // Preserve the chosen locale in requests for separately stored dynamic fragments.
  const originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...args) {
    try {
      const target = new URL(url, location.href);
      if (target.origin === location.origin && target.pathname.startsWith('/ext/')) {
        target.searchParams.set('lang', requestedCode);
        this.__shantuiLocaleRequest = true;
        url = target.pathname + target.search + target.hash;
      }
    } catch {}
    return originalOpen.call(this, method, url, ...args);
  };
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    if (this.__shantuiLocaleRequest) {
      this.addEventListener('loadend', () => {
        try {
          const status = this.getResponseHeader('X-Translation-Status');
          const content = this.getResponseHeader('X-Content-Locale');
          if (requestedLocale === 'fa-AF' && status && status !== 'approved' && status !== 'source') {
            if (window.parent !== window) window.parent.postMessage({ type: 'site-fragment-translation-status', requestedLocale, contentLocale: content || 'en', status }, location.origin);
            else if(contentCode!=='fa') announceFallback(status);
          }
        } catch {}
      }, { once: true });
    }
    return originalSend.apply(this, args);
  };

  // Replace broken source images with a neutral, accessible placeholder only; no image text is translated.
  const failedImage = image => {
    if (!(image instanceof HTMLImageElement) || image.dataset.afPlaceholder === '1') return;
    const source = image.currentSrc || image.src;
    if (!source || source.endsWith('/global/af-image-unavailable.svg')) return;
    image.dataset.afOriginalSrc = source;
    image.dataset.afPlaceholder = '1';
    image.classList.add('af-missing-image');
    image.alt = message('app.imageUnavailable');
    image.removeAttribute('srcset');
    image.closest('picture')?.querySelectorAll('source').forEach(item => { item.removeAttribute('srcset'); item.removeAttribute('src'); });
    image.src = '/global/af-image-unavailable.svg';
  };
  document.addEventListener('error', event => failedImage(event.target), true);
  document.querySelectorAll('img').forEach(image => { if (image.complete && image.naturalWidth === 0) failedImage(image); });

  const localizeLinks = container => {
    const links = container.matches?.('a[href]') ? [container] : [];
    links.push(...(container.querySelectorAll?.('a[href]') || []));
    for (const link of links) {
      try {
        const target = new URL(link.getAttribute('href'), location.href);
        if (target.origin !== location.origin || !/\.(?:html?|htm)$/i.test(target.pathname)) continue;
        target.searchParams.set('lang', requestedCode);
        link.setAttribute('href', target.pathname + target.search + target.hash);
      } catch {}
    }
  };
  localizeLinks(document.body);
  new MutationObserver(records => {
    for (const record of records) for (const node of record.addedNodes) {
      if (node.nodeType === Node.ELEMENT_NODE) localizeLinks(node);
    }
  }).observe(document.body, { childList: true, subtree: true });

  // Search results come from the local Laravel database, not legacy JSP AJAX.
  if (location.pathname === '/site/search.htm' || query.get('path') === '/site/search.htm') {
    const input = document.querySelector('section.channel_content .searchQuestion');
    if (input) {
      input.value = query.get('keywords') || '';
      input.maxLength=120;
      const search = async event => { event?.preventDefault(); event?.stopImmediatePropagation(); const value=input.value.trim(); if(!value)return;const result=await FormValidation.validate('search',{keywords:value});if(!result.valid){window.alert(result.message);return;}location.assign('/site/search.htm?'+new URLSearchParams({keywords:value,lang:requestedCode})); };
      document.querySelector('section.channel_content button.btns_box')?.addEventListener('click',search,true);
      input.addEventListener('keydown',event=>{if(event.key==='Enter')search(event);},true);
      document.querySelector('section.channel_content .textDelBtn')?.addEventListener('click',event=>{event.preventDefault();input.value='';input.focus();});
    }
  }

  document.addEventListener('click',async event=>{
    const button=event.target.closest('#emailsubmit');if(!button)return;
    event.preventDefault();event.stopImmediatePropagation();if(button.dataset.sending==='1')return;
    const input=document.querySelector('#emailInput');const validation=await FormValidation.validate('newsletter',{email:input?.value||''});
    if(!validation.valid){window.alert(validation.message);return;}button.dataset.sending='1';
    try{const response=await fetch('/ext/from_dingyue.jsp',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({email:input.value})});if(!response.ok)throw Error();const text=(await response.text()).trim();if(text==='ok'){input.value='';window.alert(requestedCode==='fa'?'عضویت شما ثبت شد.':'Subscription saved.')}else window.alert(text==='exit'?(requestedCode==='fa'?'این ایمیل قبلاً ثبت شده است.':'This email is already subscribed.'):(requestedCode==='fa'?'ایمیل معتبر وارد کنید.':'Enter a valid email.'))}catch{window.alert(message('app.requestFailed'))}finally{button.dataset.sending='0'}
  },true);

  for(const searchForm of document.querySelectorAll('form[action="/site/search.htm"]')){
    searchForm.addEventListener('submit',async event=>{event.preventDefault();event.stopImmediatePropagation();const data=Object.fromEntries(new FormData(searchForm));const validation=await FormValidation.validate('search',data,searchForm);if(!validation.valid)return;location.assign('/site/search.htm?'+new URLSearchParams({keywords:data.keywords||'',lang:requestedCode}))},true);
  }

  // Preserve the inquiry form endpoint and stored data behaviour.
  for (const form of document.querySelectorAll('form')) {
    if (!form.matches('[data-local-inquiry]') && !(form.getAttribute('action') || '').includes('/core/control/')) continue;
    const trap = document.createElement('input');trap.name='website';trap.type='text';trap.tabIndex=-1;trap.autocomplete='off';trap.hidden=true;trap.style.display='none';form.appendChild(trap);
    for(const input of form.querySelectorAll('[datatype]')) {if(input.type==='hidden')continue;const rule=input.getAttribute('datatype')||'';if(rule.startsWith('*')||rule==='e')input.required=true;if(rule==='e'&&input.tagName==='INPUT')input.type='email';}
    form.addEventListener('click', event=>{const button=event.target.closest('.btn_,.sub_btn,.form_btns,button:not([type=button]):not([type=reset]),input[type=submit]');if(!button)return;event.preventDefault();event.stopImmediatePropagation();form.requestSubmit();},true);
    form.addEventListener('submit', async event => {
      event.preventDefault();event.stopImmediatePropagation();
      if(form.dataset.sending==='1')return;
      try{await FormValidation.ready}catch{window.alert(message('app.requestFailed'));return;}
      const payload = Object.fromEntries(new FormData(form).entries());
      const kind=form.dataset.validationKind||'generic_inquiry';
      const validation=await FormValidation.validate(kind,payload,form);
      if(!validation.valid){window.alert(validation.message);return;}
      form.dataset.sending='1';
      payload.product = payload['obj.name'] || document.querySelector('h1')?.textContent || location.pathname;
      payload.language = requestedCode;
      try {
        const response = await fetch('/api/requests', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept':'application/json' }, body: JSON.stringify(payload) });
        if (!response.ok){const result=await response.json().catch(()=>({}));if(result.errors){FormValidation.show(result.errors,form,false);throw Error(Object.values(result.errors).flat().join(' '));}throw new Error();}
        form.reset();
        window.alert(message('app.requestStored'));
      } catch(error) {
        window.alert(error.message||message('app.requestFailed'));
      } finally {form.dataset.sending='0';}
    },true);
  }

  const toolbar = document.querySelector('.h_tools') || document.querySelector('.header .wrap');
  if (toolbar && !toolbar.querySelector('.af-language-toggle')) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'af-language-toggle';
    button.textContent = message(requestedCode === 'fa' ? 'app.languageSwitchTargetEnglish' : 'app.languageSwitchTargetDari');
    button.dir = 'auto';
    button.setAttribute('aria-label', message(requestedCode === 'fa' ? 'app.languageSwitchToEnglish' : 'app.languageSwitchToDari'));
    button.onclick = () => {
      const hasUnsavedData = [...document.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit]), textarea, select')].some(field => {
        if (!field.closest('form')) return false;
        if (field.type === 'checkbox' || field.type === 'radio') return field.checked !== field.defaultChecked;
        if (field instanceof HTMLSelectElement) return [...field.options].some(option => option.selected !== option.defaultSelected && (option.defaultSelected || field.selectedIndex !== 0));
        return String(field.value || '') !== String(field.defaultValue || '');
      });
      if (hasUnsavedData && !window.confirm(message('app.unsavedFormSwitch'))) return;
      const next = requestedLocale === 'fa-AF' ? 'en' : 'fa-AF';
      const nextCode = next === 'fa-AF' ? 'fa' : 'en';
      try { localStorage.setItem('shantui-lang', nextCode); } catch {}
      try { document.cookie = `shantui_lang=${encodeURIComponent(next)}; Path=/; Max-Age=2592000; SameSite=Lax`; } catch {}
      if (window.parent !== window) {
        window.parent.postMessage({ type: 'site-locale-change', locale: next, path: query.get('path') || location.pathname, query: location.search, hash: location.hash }, location.origin);
      } else {
        const target = new URL(location.href);
        target.searchParams.set('lang', nextCode);
        location.assign(target.pathname + target.search + target.hash);
      }
    };
    toolbar.insertBefore(button, toolbar.firstChild);
  }
})();

// Source rem offsets did not track the actual translated brand/header height.
(()=>{
 const start=()=>{
  const header=document.querySelector('.header');if(!header)return;
  const sync=()=>{
   const height=Math.ceil(header.getBoundingClientRect().height);
   const wrapper=header.closest('body>header');
   const reserved=wrapper ? wrapper.getBoundingClientRect().height : 0;
   document.documentElement.style.setProperty('--dealer-header-height',height+'px');
   document.documentElement.style.setProperty('--dealer-header-offset',Math.max(0,height-reserved)+'px');
  };
  sync();if(window.ResizeObserver)new ResizeObserver(sync).observe(header);
  window.addEventListener('resize',sync,{passive:true});
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
