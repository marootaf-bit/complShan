/* Explicit sandbox demo. No auth cookie is created; no admin request reaches the server. */
(()=>{
 const enabled=new URLSearchParams(location.search).get('demo')==='1';window.AdminDemo={enabled};if(!enabled)return;
 const nativeFetch=window.fetch.bind(window),copy=o=>JSON.parse(JSON.stringify(o)),rev=()=>String(++counter).padStart(64,'0');let counter=0;
 const collections={news:[],branches:[{id:'mazar-office',name_fa:'دفتر مزار شریف',name_en:'Mazar-e-Sharif office',address_fa:'افغانستان، بلخ، شهر مزار شریف',address_en:'Mazar-e-Sharif, Balkh, Afghanistan',phone:'0705078335',email:'alisinarajabi08@gmail.com',whatsapp:'93705078335',latitude:null,longitude:null,published:true}],navigation:[['home','/global/home.html','خانه','Home'],['products','/product/excavator.htm','محصولات','Products'],['parts','/product/parts.htm','قطعات','Parts'],['news','/news/news-center.htm','اخبار و رویدادها','News'],['about','/about/about-us.htm','دربارهٔ ما','About us'],['contact','/about/contact-us.htm','تماس با ما','Contact us']].map(r=>({id:r[0],path:r[1],label_fa:r[2],label_en:r[3],published:true}))};
 const revisions={};for(const k of Object.keys(collections))revisions[k]=rev();let routes=null;const pageEdits={},visualEdits={};let settings={'dealer.enabled':'1','dealer.name_fa':'شانتای افغانستان','dealer.name_en':'Shantay Afghanistan','dealer.phone':'0705078335','dealer.whatsapp':'93705078335','dealer.email':'alisinarajabi08@gmail.com','dealer.logo':'/global/dealer/company-logo.png','dealer.address_fa':'افغانستان، بلخ، شهر مزار شریف','dealer.address_en':'Mazar-e-Sharif, Balkh, Afghanistan','dealer.tagline_fa':'نمایندگی رسمی شانتای در افغانستان','dealer.tagline_en':'Official Shantui dealership in Afghanistan','dealer.parts_enabled':'1','dealer.news_enabled':'1','dealer.manufacturer_enabled':'1'};
 const pages=async()=>routes??=(await nativeFetch('/api/site/routes').then(r=>r.json())).map(p=>({...p,translation_status:'draft',has_fa:true,updated_at:'نمایش آزمایشی'}));
 async function handle(url,opts){
  const path=url.pathname,method=(opts.method||'GET').toUpperCase();let data={};if(typeof opts.body==='string')try{data=JSON.parse(opts.body)}catch{}
  if(path.endsWith('/session'))return {authenticated:true,email:'نمایش آزمایشی — بدون دسترسی واقعی'};
  if(path.endsWith('/logout'))return {authenticated:false};if(path.endsWith('/login'))return {authenticated:true};
  if(path.includes('/content/')){const kind=path.split('/').pop();if(!(kind in collections))throw Error('Unknown demo collection');if(method==='PUT'){collections[kind]=copy(data.items);revisions[kind]=rev()}return {items:copy(collections[kind]),revision:revisions[kind],saved:method==='PUT'}}
  if(path.endsWith('/pages'))return await pages();
  if(path.endsWith('/page')){const route=url.searchParams.get('path')||data.path;if(method==='GET'){if(pageEdits[route])return pageEdits[route];const [en,fa]=await Promise.all(['en','fa'].map(lang=>nativeFetch('/api/site/render?'+new URLSearchParams({path:route,lang})).then(r=>r.text())));return {path:route,title:(await pages()).find(p=>p.path===route)?.title||route,html:en,fa_title:route,fa_html:fa,fa_status:'draft',updated_at:'نمایش آزمایشی'}}pageEdits[route]=data;return {saved:true,path:route}}
  if(path.endsWith('/settings'))return copy(settings);
  if(path.endsWith('/dealer-profile')){Object.assign(settings,data.settings);return {saved:true}}
  if(path.endsWith('/setting')){if(method==='DELETE')delete settings[url.searchParams.get('key')];else settings[data.key]=data.value;return {saved:true}}
  if(path.endsWith('/media'))return [{path:'/global/dealer/company-logo.png',bytes:1000,modified:'demo',read_only:true}];
  if(path.endsWith('/upload'))return {path:'/global/dealer/company-logo.png',demo:true};
  if(path.endsWith('/requests')||path.includes('/requests/'))return method==='GET'?[]:{saved:true};
  if(path.endsWith('/translations'))return {items:[],total:0};
  if(path.endsWith('/fragments'))return [];
  if(path.endsWith('/visual-page')){if(method==='PUT'){const key=data.path+'|'+data.locale;visualEdits[key]??={};for(const e of data.changes){if(e.reset)delete visualEdits[key][e.xpath];else visualEdits[key][e.xpath]=e.value;}return {saved:true,demo:true}}const route=url.searchParams.get('path'),locale=url.searchParams.get('locale');const html=await nativeFetch('/api/site/render?'+new URLSearchParams({path:route,lang:locale})).then(r=>r.text());const d=new DOMParser().parseFromString(html,'text/html'),nodes=[];const walker=d.createTreeWalker(d.body,NodeFilter.SHOW_TEXT);let n;while((n=walker.nextNode())&&nodes.length<120){if(n.parentElement.closest('script,style,.iconfont')||n.textContent.trim().length<2)continue;nodes.push({xpath:'/demo/text/'+nodes.length,kind:'text',value:n.textContent,label:n.textContent.trim().slice(0,80)})}for(const n of nodes){const value=visualEdits[route+'|'+locale]?.[n.xpath];if(value!==undefined){n.value=value;n.label=value.trim().slice(0,80)}}return {nodes,revision:rev(),base_hash:rev(),path:route,locale,overrides:0}}
  return {saved:true,demo:true};
 }
 window.AdminDemo.applyPreview=(d,path,locale)=>{const edits=visualEdits[path+'|'+locale]||{};const walker=d.createTreeWalker(d.body,NodeFilter.SHOW_TEXT);let node,index=0;while((node=walker.nextNode())&&index<120){if(node.parentElement.closest('script,style,.iconfont')||node.textContent.trim().length<2)continue;const value=edits['/demo/text/'+index++];if(value!==undefined)node.textContent=value;}};
 window.fetch=async(input,options={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.href);
  if(url.origin===location.origin&&url.pathname.startsWith('/api/admin/')){
   try{return new Response(JSON.stringify(await handle(url,options)),{status:200,headers:{'Content-Type':'application/json'}})}catch(error){return new Response(JSON.stringify({message:error.message}),{status:422,headers:{'Content-Type':'application/json'}})}
  }
  return nativeFetch(input,options);
 };
})();
