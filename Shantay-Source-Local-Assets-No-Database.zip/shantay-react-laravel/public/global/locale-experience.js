/* Faithful legacy-site integration: language-safe routes, responsive media and keyboard controls. */
(()=>{
 const ready=()=>{
  const root=document.documentElement,fa=root.lang.toLowerCase().startsWith('fa');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let runtimeCopy={};const normalized=s=>String(s).replace(/\s+/g,' ').trim();
  const translateGenerated=container=>{
   if(!fa)return;
   const walker=document.createTreeWalker(container,NodeFilter.SHOW_TEXT);const nodes=[];let node;
   while(node=walker.nextNode())nodes.push(node);
   for(const n of nodes){
    if(n.parentElement?.closest('script,style,noscript,textarea,code,pre,.af-language-toggle'))continue;
    const old=normalized(n.textContent),replacement=runtimeCopy[old];
    if(replacement&&replacement!==old){
     if(n.parentElement?.tagName==='OPTION'&&!n.parentElement.hasAttribute('value'))n.parentElement.value=n.parentElement.textContent;
     n.textContent=n.textContent.replace(old,replacement);
    }
   }
   const shareName=s=>s.replace('微信','WeChat').replace('QQ空间','Qzone').replace('新浪微博','Weibo');
   for(const el of container.querySelectorAll?.('.jrshare_box [title],.jrshare_qrbox img[alt],.jrshare_qrbox .qrbox_title')||[]){
    for(const attr of ['title','alt']){const v=el.getAttribute(attr);if(v?.startsWith('分享到'))el.setAttribute(attr,'اشتراک‌گذاری در '+shareName(v.slice(3)));else if(v==='关闭')el.setAttribute(attr,'بستن')}
    if(el.classList.contains('qrbox_title')&&el.textContent.startsWith('分享到'))el.textContent='اشتراک‌گذاری در '+shareName(el.textContent.slice(3));
   }
   if(Intl.DisplayNames){const names=new Intl.DisplayNames(['fa-AF'],{type:'region'});for(const name of container.querySelectorAll?.('.country-list [data-country-code] .country-name')||[]){const code=name.closest('[data-country-code]').dataset.countryCode;if(code&&/^[a-z]{2}$/i.test(code))name.textContent=names.of(code.toUpperCase())}}
  };
  const validationCopy=()=>{
   if(!fa||!window.jQuery?.Tipmsg)return;
   const walk=object=>{for(const key in object){if(typeof object[key]==='string'&&runtimeCopy[normalized(object[key])])object[key]=runtimeCopy[normalized(object[key])];else if(object[key]&&typeof object[key]==='object')walk(object[key])}};walk(window.jQuery.Tipmsg);
  };
  if(fa){
   const nativeAlert=window.alert.bind(window);window.alert=message=>nativeAlert(runtimeCopy[normalized(message)]||message);
   fetch('/global/runtime-copy.fa.json').then(r=>r.ok?r.json():{}).then(copy=>{runtimeCopy=copy;translateGenerated(document.body);validationCopy()}).catch(()=>{});
   document.addEventListener('focusin',validationCopy,true);document.addEventListener('click',validationCopy,true);
  }

  const responsive=()=>document.querySelectorAll('img[data-src][data-smalsrc]').forEach(img=>{
   const src=matchMedia('(max-width:780px)').matches?img.getAttribute('data-smalsrc'):img.getAttribute('data-src');
   if(src&&src!=='undefined'&&img.dataset.afPlaceholder!=='1')img.srcset=src;
  });
  responsive();matchMedia('(max-width:780px)').addEventListener('change',responsive);
  // A real campaign still from this page is the poster, never a generated replacement.
  const heroImage=document.querySelector('.ibanner img.iban_img');
  for(const video of document.querySelectorAll('video')){
   video.preload='metadata';
   if(!video.poster&&heroImage&&video.closest('.ibanner'))video.poster=heroImage.getAttribute('data-src')||heroImage.src;
   if(reduced.matches){video.autoplay=false;video.removeAttribute('autoplay');video.pause()}
  }
  const sourcePath=()=>new URLSearchParams(location.search).get('path')|| (location.pathname==='/'?'/global/home.html':location.pathname);
  // The outer React shell must follow the visited document, not reset language switches to home.
  if(parent!==window){const q=new URLSearchParams(location.search);q.delete('path');q.delete('lang');parent.postMessage({type:'site-route-change',path:sourcePath(),query:q.toString(),hash:location.hash},location.origin)}
  const repairLinks=container=>{
   const links=[...(container.matches?.('a[href]')?[container]:[]),...(container.querySelectorAll?.('a[href]')||[])];
   for(const a of links){
    const href=a.getAttribute('href');
    if(href==='/'||(!href&&a.closest('.h_logo'))){a.href='/global/home.html?lang='+(fa?'fa':'en')}
    // Source campaign slides without a target are not meaningful "read more" links.
    if(!href&&a.classList.contains('more_btn')){a.hidden=true;a.setAttribute('aria-hidden','true')}
   }
  };
  repairLinks(document.body);
  const enhance=container=>{
   for(const e of container.querySelectorAll?.('.swiper-button-next,.swiper-button-prev,.click_btns,.click_btns2,.h_menu,.mobile_key,.h_sear,.inquiry2 .checkbox .item,.infor .tip,.infor .tip2,.sel_span')||[]){
    if(e.dataset.afControl)return;e.dataset.afControl='1';e.tabIndex=0;e.setAttribute('role','button');
    const prev=e.matches('.swiper-button-prev,.click_btns2');
    if(e.matches('.infor .tip,.infor .tip2')){e.setAttribute('role','checkbox');const state=()=>e.setAttribute('aria-checked',String(e.classList.contains('on')));state();e.addEventListener('click',()=>setTimeout(state,0))}
    if(!e.matches('.inquiry2 .checkbox .item,.infor .tip,.infor .tip2,.sel_span'))e.setAttribute('aria-label',e.matches('.h_menu,.mobile_key')?(fa?'باز کردن منو':'Open navigation'):e.matches('.h_sear')?(fa?'باز کردن جست‌وجو':'Open search'):(prev?(fa?'قبلی':'Previous'):(fa?'بعدی':'Next')));
    e.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();e.click()}});
   }
   for(const field of container.querySelectorAll?.('input,textarea,select')||[]){
    if(field.type==='email'||field.type==='tel'||field.getAttribute('datatype')==='e'||/email|phone|mobile|tel|code/i.test(field.name)){field.dir='ltr';field.style.textAlign='start'}
    if(!field.getAttribute('aria-label')&&!field.id){const label=field.closest('.form_item,.item,.box')?.querySelector('.tit,.label,.name');if(label?.textContent.trim())field.setAttribute('aria-label',label.textContent.trim())}
   }
   for(const e of container.querySelectorAll?.('.parameter .value,.parameter .v,[data-model]')||[]){e.dir='ltr';e.style.unicodeBidi='isolate'}
  };
  // Keep the existing hero actions together on narrow screens.
  for(const wrap of document.querySelectorAll('.ibanner .cover .wrap')){
   const actions=[...wrap.querySelectorAll('a.dealer-hero-action')];
   if(actions.length&&!wrap.querySelector('.dealer-hero-actions')){const group=document.createElement('div');group.className='dealer-hero-actions';actions[0].before(group);actions.forEach(a=>group.appendChild(a))}
  }
  for(const box of document.querySelectorAll('.cookie_box .cook_words')){
   if(box.querySelector('.cookie-details'))continue;
   const button=document.createElement('button');button.type='button';button.className='cookie-details';button.textContent=fa?'جزئیات کوکی‌ها':'Cookie details';button.setAttribute('aria-expanded','false');
   button.addEventListener('click',()=>{const open=box.classList.toggle('is-expanded');button.setAttribute('aria-expanded',String(open));button.textContent=fa?(open?'بستن جزئیات':'جزئیات کوکی‌ها'):(open?'Hide details':'Cookie details')});box.appendChild(button);
  }
  enhance(document.body);
  for(const a of document.querySelectorAll('.infor .tip2 a')){a.target='_blank';a.rel='noopener';a.addEventListener('click',e=>e.stopPropagation())}
  for(const box of document.querySelectorAll('.cookie_box .cook_words')){box.tabIndex=0;box.setAttribute('aria-label',fa?'معلومات کوکی‌ها':'Cookie information')}
  new MutationObserver(records=>{for(const r of records){for(const n of r.addedNodes)if(n.nodeType===1){repairLinks(n);enhance(n);translateGenerated(n)}if([...r.addedNodes].some(n=>n.nodeType===3))translateGenerated(r.target)}}).observe(document.body,{subtree:true,childList:true});
  document.addEventListener('keydown',e=>{
   if(e.key!=='Escape')return;
   const menu=document.querySelector('.m_nav');const trigger=document.querySelector('.mobile_key');
   if(menu&&getComputedStyle(menu).display!=='none'&&trigger){trigger.click();trigger.focus()}
  });
  // Make sliders non-autoplay when reduced motion is requested, after legacy initialization.
  if(reduced.matches)setTimeout(()=>{document.querySelectorAll('.swiper-container').forEach(e=>{e.swiper?.autoplay?.stop?.()});document.querySelectorAll('video').forEach(v=>v.pause())},500);
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
